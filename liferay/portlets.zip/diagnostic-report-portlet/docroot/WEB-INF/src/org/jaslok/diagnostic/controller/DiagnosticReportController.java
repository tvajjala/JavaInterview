package org.jaslok.diagnostic.controller;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.log4j.Logger;
import org.jaslok.diagnostic.service.DiagnosticReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.napier.portal.db.NoSuchNapierUserException;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */
@Controller
public class DiagnosticReportController {
    private static Logger logger = Logger.getLogger(DiagnosticReportController.class.getSimpleName());

    @Autowired
    DiagnosticReportService diagnosticReportService;

    @RenderMapping
    public String defaultView(RenderRequest renderRequest, RenderResponse renderResponse, Model model) {

        logger.info("	rendering defaultView of DiagnosticReport ");
        try {
            String mrNumber = "MR0002992392";
            // use this logic in all the reports to retrieve mrNumber
            // dynamically
            try {
                User user = (User) renderRequest.getAttribute(WebKeys.USER);
                NapierUser napierUser = NapierUserLocalServiceUtil.getByportalUserId(user.getUserId());
                mrNumber = napierUser.getMrNumber();
            } catch (NoSuchNapierUserException e) {
                logger.error(e.getMessage());
            }

            diagnosticReportService.populateDummyData(mrNumber);
            diagnosticReportService.prepareResults(renderRequest, renderResponse, model, mrNumber);

        } catch (SystemException e) {

            logger.error(e.getMessage());
        }

        return "patient/view";

    }

}
