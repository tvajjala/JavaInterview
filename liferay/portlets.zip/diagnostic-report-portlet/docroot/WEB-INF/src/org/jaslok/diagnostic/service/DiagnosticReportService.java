package org.jaslok.diagnostic.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.log4j.Logger;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.napier.portal.db.model.DiagnosticReport;
import com.napier.portal.db.service.DiagnosticReportLocalServiceUtil;

public class DiagnosticReportService {

    private static Logger logger = Logger.getLogger(DiagnosticReportService.class.getSimpleName());

    /**
     * populates dummy data
     * 
     * @param mrNumber
     * @throws SystemException
     */
    public void populateDummyData(String mrNumber) throws SystemException {
        List<DiagnosticReport> diagnosticReports = DiagnosticReportLocalServiceUtil.getBymrNumber(mrNumber);

        if (diagnosticReports.isEmpty()) {

            for (int i = 0; i < 100; i++) {

                long diagnosticId = CounterLocalServiceUtil.increment(DiagnosticReport.class.getSimpleName());

                DiagnosticReport diagnosticReport = DiagnosticReportLocalServiceUtil.createDiagnosticReport(diagnosticId);
                diagnosticReport.setDepartmentName("MRI");
                diagnosticReport.setDocPath("ftp://shared/folder" + diagnosticId);
                diagnosticReport.setIpNumber("IPC1." + diagnosticId);
                diagnosticReport.setMrNumber(mrNumber);
                diagnosticReport.setTestName("X-Ray " + i);
                diagnosticReport.setStatus((i % 3 == 0));
                diagnosticReport.setOrderDate(new Date());
                diagnosticReport.setOrderNumber("ORD " + i);
                diagnosticReport.setReportedOn(new Date());
                DiagnosticReportLocalServiceUtil.updateDiagnosticReport(diagnosticReport);
            }

        }

    }

    /**
     * 
     * @param renderRequest
     * @param renderResponse
     * @param model
     * @param mrNumber
     * @throws SystemException
     */
    public void prepareResults(RenderRequest renderRequest, RenderResponse renderResponse, Model model, String mrNumber) throws SystemException {
        List<String> headerNames = new ArrayList<String>();

        headerNames.add("Order Number");
        headerNames.add("Order Date");
        headerNames.add("Reported On");
        headerNames.add("IP Number");
        headerNames.add("Test Name");
        headerNames.add("Department Name");
        headerNames.add(" View ");

        PortletURL portletURL = renderResponse.createRenderURL();
        try {
            portletURL.setWindowState(WindowState.MAXIMIZED);
        } catch (WindowStateException e) {
            logger.error(e.getMessage());
        }
        SearchContainer<DiagnosticReport> searchContainer = new SearchContainer<DiagnosticReport>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM,
                5, portletURL, headerNames, "DiagnosticReports not available");

        portletURL.setParameter(searchContainer.getCurParam(), String.valueOf(searchContainer.getCur()));

        List<DiagnosticReport> diagnosticReports = DiagnosticReportLocalServiceUtil.getBymrNumber(mrNumber, searchContainer.getStart(),
                searchContainer.getEnd());

        int total = DiagnosticReportLocalServiceUtil.getBymrNumber(mrNumber).size();
        searchContainer.setTotal(total);
        searchContainer.setResults(diagnosticReports);// ?
        searchContainer.setDeltaConfigurable(true);

        List<ResultRow> resultRows = searchContainer.getResultRows();

        int i = 0;
        for (DiagnosticReport report : diagnosticReports) {
            ResultRow row = new ResultRow(report, report.getDiagnosticId(), i++);
            row.addText(report.getOrderNumber());
            row.addText(report.getOrderDate().toString());
            row.addText(report.getReportedOn().toString());
            row.addText(report.getIpNumber());
            row.addText(report.getTestName());
            row.addText(report.getDepartmentName());
            if (report.getStatus()) {
                row.addText("Viewed", report.getDocPath());
            } else {
                row.addText("View", report.getDocPath());
            }

            resultRows.add(row);
        }

        logger.info("DiagnosticReport  " + resultRows.size());

        model.addAttribute("searchContainer", searchContainer);
    }

}
