var reserve = function() {
	$("#bedAllocationForm").submit(); // Submit  the FORM

};

var closePopup = function() {
	$("#modal").css("opacity", "0");
	$("#modal").css("visibility", "hidden");
};

var passFunc = function(bedClass, bedReservationId) {
	$("#bedCL").val(bedClass);
	$("#modal").css("opacity", "1");
	$("#modal").css("visibility", "visible");
	$("#HreservationId").val(bedReservationId);
};

var setValue = function() {
	$("#bedDD").val($("#bedVal").val());
	$("#gender").val($("#Hgender").val());
	$("#mrNumber").attr('disabled', 'disabled');
	
	$("#fullName").attr('disabled', 'disabled');
	$("#gender").attr('disabled', 'disabled');
	$("#age").attr('disabled', 'disabled');
};

setValue();

$(function() {
	$("#admissionDate").datepicker();
});

$("input[name=reg]:radio").change(function() {
	if ($(this).val() == 'rp') {
		$("#mrNumber").val($("#HmrNumber").val());
		$("#fullName").val($("#HfullName").val());
		$("#gender").val($("#Hgender").val());
		$("#age").val($("#Hage").val());
		
		$("#fullName").attr('disabled', 'disabled');
		$("#gender").attr('disabled', 'disabled');
		$("#age").attr('disabled', 'disabled');

	}

	if ($(this).val() == 'nrp') {
		$("#mrNumber").val("");
		$("#fullName").val("");
		$("#gender").val("");
		$("#age").val("");
		
		$("#fullName").removeAttr('disabled');
		$("#gender").removeAttr('disabled');
		$("#age").removeAttr('disabled');	
	}
	
	
	
});

// callback handler for form submit
$("#bedAllocationForm").submit(function(e) {
	var postData = $(this).serializeArray();
	var formURL = $(this).attr("action");
	$.ajax({
		url : formURL,
		type : "GET",
		contentType : 'application/json; charset=utf-8',
		data : postData,
		success : function(data) {
			alert(data.status +" : "+data.message);
		},
		error : function(jqXHR, textStatus, errorThrown) {
			// if fails
			alert("error " + textStatus);
		}
	});
	e.preventDefault(); // STOP default action
	e.unbind(); // unbind. to stop multiple form submit.
});
