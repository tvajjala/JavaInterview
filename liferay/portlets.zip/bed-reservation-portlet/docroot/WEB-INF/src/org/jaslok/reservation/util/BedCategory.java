package org.jaslok.reservation.util;

/**
 * 
 * @author tvajjala
 * 
 */
public enum BedCategory {

	MASTER("Master"), SINGLE("Single"), DOUBLE("Double"), DELUXE("Deluxe");

	private String title;

	BedCategory(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}
}
