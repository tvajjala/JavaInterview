package org.jaslok.reservation.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.jaslok.reservation.service.BedReservationService;
import org.jaslok.reservation.util.BedCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.util.PortalUtil;
import com.napier.portal.db.NoSuchNapierUserException;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */
@Controller
public class BedReservationController {
    private static Logger logger = Logger.getLogger(BedReservationController.class.getSimpleName());

    @Autowired
    BedReservationService bedReservationService;

    @RenderMapping
    public String defaultView(RenderRequest renderRequest, RenderResponse renderResponse, PortletSession session, Model model) {

        logger.info("rendering defaultView of  BedReservationController ");

        try {

            String mrNumber = "MR0002992392";

            // use this logic in all the reports to retrieve mrNumber
            // dynamically
            try {
                User user = (User) renderRequest.getAttribute(WebKeys.USER);
                NapierUser napierUser = NapierUserLocalServiceUtil.getByportalUserId(user.getUserId());
                mrNumber = napierUser.getMrNumber();

                model.addAttribute("fullName", user.getFullName());
                model.addAttribute("age", napierUser.getAge());
                model.addAttribute("gender", napierUser.getGender());
            } catch (NoSuchNapierUserException e) {
                logger.error(e.getMessage());
            }

            String bedClass = (String) session.getAttribute("bedCategory");
            logger.info("bedClass " + bedClass);

            if (bedClass == null) {
                bedClass = BedCategory.MASTER.getTitle();
            }

            bedReservationService.populateDummyData();
            bedReservationService.prepareResults(renderRequest, renderResponse, model, bedClass);

            model.addAttribute("selectedValue", bedClass);
            model.addAttribute("mrNumber", mrNumber);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }

        return "patient/view";
    }

    @ActionMapping(params = "action=bedSearch")
    public void bedSearch(ActionRequest actionRequest, ActionResponse actionResponse, PortletSession session, Model model) throws IOException, PortletException {
        logger.info(" processing bedSearch action request  ");

        String bedCategory = ParamUtil.getString(actionRequest, "bedCategory");

        session.setAttribute("bedCategory", bedCategory);

        logger.info("bedCategory : " + session.getAttribute("bedCategory"));
    }

    @ResourceMapping(value = "reservedBed")
    public void allocateBed(ResourceRequest request, ResourceResponse response) throws IOException, PortletException {
        logger.info(" bedAllocation  ");
        response.setContentType("application/json");

        JSONObject object = JSONFactoryUtil.createJSONObject();

        try {
            bedReservationService.allocateBed(request);
            object.put("message", "bed registration successful");
            object.put("status", "success");
        } catch (SystemException e) {
            object.put("status", "fail");
            object.put("message", "bed reservation failed. please try again after sometime.");
            e.printStackTrace();
        }
        logger.info("object.toString() : " + object.toString());
        PrintWriter out = response.getWriter();
        out.write(object.toString());
        // out.flush();
        // out.close();

        // return;
    }

}
