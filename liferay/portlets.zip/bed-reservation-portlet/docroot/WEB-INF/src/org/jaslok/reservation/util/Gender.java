package org.jaslok.reservation.util;

public enum Gender {

	MALE("Male"), FEMALE("Female");
	private String title;

	private Gender(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}
}
