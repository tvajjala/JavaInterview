package org.jaslok.reservation.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.log4j.Logger;
import org.jaslok.reservation.util.BedCategory;
import org.jaslok.reservation.util.Gender;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.napier.portal.db.model.BedAllocation;
import com.napier.portal.db.model.BedReservation;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.BedAllocationLocalServiceUtil;
import com.napier.portal.db.service.BedReservationLocalServiceUtil;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */
public class BedReservationService {

    private static Logger logger = Logger.getLogger(BedReservationService.class.getSimpleName());

    public void populateDummyData() throws SystemException {

        List<BedReservation> list = BedReservationLocalServiceUtil.getAll();

        if (list.isEmpty()) {

            for (BedCategory bedCategory : BedCategory.values()) {
                for (int i = 1; i < 50; i++) {

                    long bedReservationId = CounterLocalServiceUtil.increment(BedReservation.class.getSimpleName());
                    BedReservation bedReservation = BedReservationLocalServiceUtil.createBedReservation(bedReservationId);
                    bedReservation.setBedClass(bedCategory.getTitle());

                    if ((i % 2) == 0) {
                        bedReservation.setGender(Gender.MALE.getTitle());
                    } else {
                        bedReservation.setGender(Gender.FEMALE.getTitle());
                    }

                    bedReservation.setHospitalTariff(250.00 * i);
                    bedReservation.setTotalBedCount(50 * i);
                    bedReservation.setVacantBedCount(25 * i);
                    bedReservation.setWard("Ward No" + i);
                    BedReservationLocalServiceUtil.updateBedReservation(bedReservation);
                }

            }

        }
    }

    public void prepareResults(RenderRequest renderRequest, RenderResponse renderResponse, Model model, String bedClass) throws SystemException {
        List<String> headerNames = new ArrayList<String>();

        headerNames.add("Bed Class");
        headerNames.add("Ward");
        headerNames.add("Total Number of beds");
        headerNames.add("Vacant Beds");
        headerNames.add("Hospital Tariff");
        headerNames.add("Gender");
        headerNames.add(" Book ");

        PortletURL portletURL = renderResponse.createRenderURL();

        String orderByCol = ParamUtil.get(renderRequest, "orderByCol", "ward");

        model.addAttribute("orderByCol", orderByCol);

        logger.info(" orderByCol " + orderByCol);

        String orderByType = ParamUtil.get(renderRequest, "orderByType", "asc");

        model.addAttribute("orderByType", orderByType);

        logger.info(" orderByType " + orderByType);

        try {
            portletURL.setWindowState(WindowState.MAXIMIZED);
        } catch (WindowStateException e) {
            logger.error(e.getMessage());
        }
        SearchContainer<BedReservation> searchContainer = new SearchContainer<BedReservation>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM, 5,
                portletURL, headerNames, "BedReservation details for the bedClass '" + bedClass + "' not available, Please search with different BedClass");

        portletURL.setParameter(searchContainer.getCurParam(), String.valueOf(searchContainer.getCur()));

        logger.info("searching valuess ...." + searchContainer.getOrderByComparator());
        logger.info(searchContainer.getCurParam() + searchContainer.getCur());

        // searchContainer.setOrderByComparator(new BedOrderComparator());

        List<BedReservation> list = BedReservationLocalServiceUtil.getBybedClass(bedClass, searchContainer.getStart(), searchContainer.getEnd());

        int total = BedReservationLocalServiceUtil.getBybedClass(bedClass).size();
        searchContainer.setTotal(total);
        searchContainer.setResults(list);
        searchContainer.setDeltaConfigurable(true);

        logger.info("bedReservation " + list.size());

        model.addAttribute("searchContainer", searchContainer);
    }

    class BedOrderComparator extends OrderByComparator {

        private static final long serialVersionUID = -2135019836213649526L;

        @Override
        public int compare(Object arg0, Object arg1) {

            logger.info(arg0 + " :  " + arg1);
            return 0;
        }

    }

    @SuppressWarnings("all")
    public String allocateBed(ResourceRequest actionRequest) {
        JSONObject object = JSONFactoryUtil.createJSONObject();

        try {

            String bedCL = ParamUtil.getString(actionRequest, "bedCL");

            logger.info("bedCL " + bedCL);
            String reg = ParamUtil.getString(actionRequest, "reg");
            User user = (User) actionRequest.getAttribute(WebKeys.USER);

            NapierUser napierUser = NapierUserLocalServiceUtil.getByportalUserId(user.getUserId());

            DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            String mrNumber = ParamUtil.getString(actionRequest, "FmrNumber");
            String fullName = ParamUtil.getString(actionRequest, "FfullName");

            String gender = ParamUtil.getString(actionRequest, "Fgender").toUpperCase();
            long HreservationId = ParamUtil.getLong(actionRequest, "HreservationId");

            BedReservation bedReservation;
            try {
                bedReservation = BedReservationLocalServiceUtil.getBedReservation(HreservationId);
                int vacantBedCount = bedReservation.getVacantBedCount();
                if (vacantBedCount <= 0) {
                    object.put("status", "fail");
                    object.put("message", "No wards for the selected bed class.");
                    return object.toString();
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            // String admissionDate=ParamUtil.getString(actionRequest, "datepicker");

            int age = ParamUtil.getInteger(actionRequest, "Fage");

            Date admissionDate = ParamUtil.getDate(actionRequest, "admissionDate", dateFormat, null);

            if (admissionDate == null) {
                object.put("status", "fail");
                object.put("message", "Please enter expected date and time of admission");
                return object.toString();
            }

            int hh = ParamUtil.getInteger(actionRequest, "hh");
            int mm = ParamUtil.getInteger(actionRequest, "mm");

            logger.info("admissionDate  " + admissionDate + ": " + hh + ": " + mm);

            Calendar cal = Calendar.getInstance();
            cal.setTime(admissionDate);
            cal.set(Calendar.HOUR_OF_DAY, hh);
            cal.set(Calendar.MINUTE, mm);
            admissionDate = cal.getTime();

            logger.info(bedCL + "  :  " + reg + admissionDate);

            long bedAllocationId = CounterLocalServiceUtil.increment(BedAllocation.class.getSimpleName());

            BedAllocation bedAllocation = BedAllocationLocalServiceUtil.createBedAllocation(bedAllocationId);
            bedAllocation.setAdmissionDate(admissionDate);
            bedAllocation.setBedNumber(bedCL);
            bedAllocation.setCreatedUserId(user.getUserId());// createdBy UserId portalUserTable
            bedAllocation.setStatus("Requested");// initial status should be requested
            bedAllocation.setBedReservationNumber(String.valueOf(HreservationId));
            bedAllocation.setEmail(user.getEmailAddress());

            bedAllocation.setMobile(napierUser.getMobile());// to call requested user

            if ("rp".equalsIgnoreCase(reg)) {
                bedAllocation.setMrNumber(napierUser.getMrNumber());
            } 

            //auto populated data for the registered patient 
            bedAllocation.setAge(age);
            bedAllocation.setPatientName(fullName);
            bedAllocation.setGender(gender);

            BedAllocationLocalServiceUtil.updateBedAllocation(bedAllocation);

            object.put("status", "success");
            object.put("message", "Bed Reservation Request raised successfully");
            return object.toString();

        } catch (Exception e) {
            logger.error(e.getMessage());
            object.put("status", "fail");
            object.put("message", "bed reservation failed. please try again after sometime.");
            return object.toString();
        }

    }
}
