package org.jaslok.registration.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jaslok.registration.util.UserType;

public class UserRegistration {

	private String firstName;

	private String middleName;

	private String lastName;

	private String password;

	private String email;

	private String mobile;

	private UserType userType;

	private String screenName;

	private String dob;

	// at a time one amonth below three available
	private String mrNumber;//for patients

	private String tpaNumber;//for TPA insurance

	private String corporateNumber;//  for doctors
	

	public String getCorporateNumber() {
		return corporateNumber;
	}

	public void setCorporateNumber(String corporateNumber) {
		this.corporateNumber = corporateNumber;
	}

	public String getMrNumber() {
		return mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		this.mrNumber = mrNumber;
	}

	public String getTpaNumber() {
		return tpaNumber;
	}

	public void setTpaNumber(String tpaNumber) {
		this.tpaNumber = tpaNumber;
	}

	private Integer birthMonth;
	private Integer birthYear;
	private Integer birthDate;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getBirthMonth() {
		return birthMonth;
	}

	public Integer getBirthYear() {
		return birthYear;
	}

	public Integer getBirthDate() {
		return birthDate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getDob() {
		return dob;
	}

	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

	@SuppressWarnings("all")
	public void setDob(String dob) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

		try {
			Date date = sdf.parse(dob);
			birthDate = date.getDate();
			birthMonth = date.getMonth();
			birthYear = date.getYear();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		this.dob = dob;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

}
