package org.jaslok.registration.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;

import javax.portlet.ActionRequest;

import org.apache.log4j.Logger;
import org.jaslok.registration.model.PatientProfile;
import org.jaslok.registration.model.UserRegistration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

@Service
@SuppressWarnings("all")
public class RegistrationService {

	String SELECT_BY = "SELECT * FROM NH_GN_PAT_REGISTRATION WHERE RG_INT_MR_NO=?";

	private static Logger logger = Logger.getLogger(RegistrationService.class
			.getSimpleName());

	@Autowired
	JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@SuppressWarnings("all")
	public  NapierUser registerUser(ActionRequest actionRequest,
			UserRegistration registration) throws Exception {

		final ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest
				.getAttribute(WebKeys.THEME_DISPLAY);

		long creatorId = UserLocalServiceUtil.getDefaultUserId(themeDisplay
				.getCompanyId());
		long companyId = themeDisplay.getCompanyId();

		User createdUser = UserLocalServiceUtil.addUser(creatorId, companyId,
				false, registration.getPassword(), registration.getPassword(),
				true, null, registration.getEmail(),
				0L, null, Locale.getDefault(), registration.getFirstName(),
				registration.getMiddleName(), registration.getLastName(), 0, 0,
				true, 1, 1, 1984, "NAPIER_PORTAL_USERS", null, null, null,
				null, false, ServiceContextFactory.getInstance(actionRequest));

		// adding custom role to new user
		Role role = null;
		try {
			role = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),
					registration.getUserType().getTitle());
		} catch (Exception e) {
			// create new role if it is not exist
			role = RoleLocalServiceUtil.addRole(createdUser.getUserId(),
					companyId, registration.getUserType().getTitle(), null,
					null, 0);
		}

		UserLocalServiceUtil.addRoleUser(role.getRoleId(), createdUser);
		createdUser.setAgreedToTermsOfUse(true);

		long napierUserId = CounterLocalServiceUtil.increment(NapierUser.class
				.getName());
		NapierUser napierUser = NapierUserLocalServiceUtil
				.createNapierUser(napierUserId);

		napierUser.setUserType(registration.getUserType().getTitle());
		napierUser.setPortalUserId(createdUser.getUserId());// portal userId
															// as FK in
															// custom table
		napierUser.setMrNumber(registration.getMrNumber());
		napierUser.setMobile(registration.getMobile());

		NapierUserLocalServiceUtil.updateNapierUser(napierUser);

		return napierUser;

	}

	public PatientProfile getProfile(String mrNumber) throws Exception {

		return jdbcTemplate.queryForObject(SELECT_BY,
				new Object[] { mrNumber }, new PatientProfileRowMapper());

	}

	class PatientProfileRowMapper implements RowMapper<PatientProfile> {

		@Override
		public PatientProfile mapRow(ResultSet rs, int arg1)
				throws SQLException {

			PatientProfile patientProfile = new PatientProfile();

			patientProfile.setFirstname(rs.getString("RG_FIRST_NAME"));
			patientProfile.setLastname(rs.getString("RG_LAST_NAME"));

			patientProfile.setAge(rs.getInt("RG_AGE"));
			patientProfile.setDob(rs.getTimestamp("RG_DOB"));
			patientProfile.setExtMR(rs.getString("RG_EXT_MR_NO"));
			patientProfile.setIntMR(rs.getString("RG_INT_MR_NO"));

			return patientProfile;
		}

	}

}
