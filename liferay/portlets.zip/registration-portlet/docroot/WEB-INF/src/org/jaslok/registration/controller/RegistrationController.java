package org.jaslok.registration.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.log4j.Logger;
import org.jaslok.registration.service.RegistrationService;
import org.jaslok.registration.util.UserType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.napier.portal.db.NoSuchNapierUserException;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */
@Controller
public class RegistrationController {

    private static Logger logger = Logger.getLogger(RegistrationController.class.getSimpleName());

    @Autowired
    RegistrationService registrationService;

    @RenderMapping
    public String defaultView(RenderRequest renderRequest, RenderResponse renderResponse, Model model) {

        List<String> list = new ArrayList<String>();
        for (UserType userType : UserType.values()) {
            list.add(userType.getTitle());
        }
        model.addAttribute("userTypes", list);

        logger.info("patient registration page  ");
        return "registration";
    }

    @ActionMapping(params = "action=registerPatient")
    public void registerPatient(ActionRequest actionRequest, ActionResponse actionResponse, Model model) throws IOException, PortletException {

        String userType = ParamUtil.getString(actionRequest, "userType");
        String mrNumber = ParamUtil.getString(actionRequest, "mrnumber");
        String patientName = ParamUtil.getString(actionRequest, "name");
        String phone = ParamUtil.getString(actionRequest, "phone");
        String email = ParamUtil.getString(actionRequest, "email");
        String ageGender = ParamUtil.getString(actionRequest, "ageGender");

        try {
            logger.info("MRNUMBER " + mrNumber);

            NapierUser napierUser = com.napier.portal.db.service.NapierUserLocalServiceUtil.getBymrNumber(mrNumber);
            /* if (napierUser != null) { */
            // SessionErrors.add(actionRequest, "profile.exists");

            ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);

            long companyId = themeDisplay.getCompanyId();
            System.out.println("themeDisplay.getSiteGroupName()");

            Locale locale = themeDisplay.getLocale();
            long userId = UserLocalServiceUtil.getUserByEmailAddress(companyId, "test@liferay.com").getUserId();

            if (userType.equals("Patient")) {
                /*
                 * User portalUser = createPortalUser(patientName, companyId, userId, locale, email); SessionMessages .add(actionRequest,
                 * "registration.success", "registration successful. please login to the application"); updateNapierUser(actionRequest, portalUser.getUserId(),
                 * mrnumber);
                 */
                actionResponse.sendRedirect("/web/napier");
            }

            /*
             * }
             */
        } catch (Exception e) {
            logger.error(e.getMessage());

            if (e instanceof com.liferay.portal.GroupFriendlyURLException) {
                SessionErrors.add(actionRequest, "email.alreadyused");

            } else if (e instanceof NoSuchNapierUserException) {
                SessionErrors.add(actionRequest, "profile.notfound");
            } else {
                SessionErrors.add(actionRequest, "registration.failed");
            }

        }

    }

    private User createPortalUser(String patientName, final long companyId, long createrUserId, final Locale locale, String email) {

        User user = null;

        try {
            user = UserLocalServiceUtil.addUser(createrUserId, companyId, true, "thirupathi", "thirupathi", true, "", email, 0L, "", locale, "firstName",
                    "middleName", "lastName", 0, 0, false, 0, 1, 1970, "Job Title", null, null, null, null, true, new ServiceContext());
            logger.info("UserCreated succesfully");

        } catch (PortalException | SystemException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return user;
    }

    private void updateNapierUser(ActionRequest actionRequest, long portalUserid, String mrNumber) {

        try {

            NapierUser napierUser = com.napier.portal.db.service.NapierUserLocalServiceUtil.getBymrNumber(mrNumber);
            napierUser.setPortalUserId(portalUserid);
            NapierUserLocalServiceUtil.updateNapierUser(napierUser);
        } catch (Exception e) {
            logger.error(e.getMessage());
            if (e instanceof NoSuchNapierUserException) {
                SessionErrors.add(actionRequest, "profile.notfound");
            } else {
                SessionErrors.add(actionRequest, "registration.failed");
            }

        }

    }

    @ResourceMapping(value = "resourceURL")
    public void getInformationForLatest(ResourceRequest request, ResourceResponse response) throws IOException {

        String mrNumber = ParamUtil.getString(request, "mrnumber");
        JSONObject jsonUser = JSONFactoryUtil.createJSONObject();

        NapierUser napierUser;
        try {
            logger.info("entered the resourURL" + mrNumber);

            long napierUserId = CounterLocalServiceUtil.increment(NapierUser.class.getSimpleName());
            NapierUser user1 = NapierUserLocalServiceUtil.createNapierUser(napierUserId);
            user1.setEmail("svelugoti@innominds.com");
            user1.setMrNumber("MR10002");
            user1.setMobile("8886010678");
            user1.setName("UserName");
            NapierUserLocalServiceUtil.updateNapierUser(user1);

            logger.info("retriving patient information from napier database " + mrNumber);

            napierUser = NapierUserLocalServiceUtil.getBymrNumber(mrNumber);
            jsonUser.put("name", napierUser.getName());
            jsonUser.put("email", napierUser.getEmail());
            jsonUser.put("phoneNumber", napierUser.getMobile());
        } catch (NoSuchNapierUserException | SystemException e) {

            logger.error(e.getMessage());
        }
        PrintWriter out = response.getWriter();
        out.println(jsonUser.toString());
    }

}