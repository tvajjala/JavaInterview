package org.jaslok.lab.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.log4j.Logger;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.napier.portal.db.model.LabReport;
import com.napier.portal.db.service.LabReportLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */
public class LabReportService {

    private static Logger logger = Logger.getLogger(LabReportService.class.getSimpleName());

    public void populateDummyData(String mrNumber) throws SystemException {

        List<LabReport> reports = LabReportLocalServiceUtil.getBymrNumber(mrNumber);
        if (reports.isEmpty()) {
            for (int i = 0; i < 100; i++) {

                long labId = CounterLocalServiceUtil.increment(LabReport.class.getSimpleName());
                LabReport labReport = LabReportLocalServiceUtil.createLabReport(labId);
                labReport.setOrderNumber("OD " + i);
                labReport.setOrderDate(new Date());
                labReport.setReportedOn(new Date());
                labReport.setIpNumber("IPC1." + labId);
                labReport.setTestName("X-RAY");
                labReport.setDepartmentName("Biochemistry");
                labReport.setDocPath("ftp://shared/folder" + labId);
                labReport.setMrNumber(mrNumber);
                labReport.setStatus((i % 5) == 0);
                LabReportLocalServiceUtil.updateLabReport(labReport);
            }
        }

    }

    public void prepareResults(RenderRequest renderRequest, RenderResponse renderResponse, Model model, String mrNumber) throws SystemException {
        List<String> headerNames = new ArrayList<String>();

        headerNames.add("Order Number");
        headerNames.add("Order Date");
        headerNames.add("Reported On");
        headerNames.add("IP Number");
        headerNames.add("Test Name");
        headerNames.add("Department Name");
        headerNames.add(" View ");

        PortletURL portletURL = renderResponse.createRenderURL();
        try {
            portletURL.setWindowState(WindowState.MAXIMIZED);
        } catch (WindowStateException e) {
            logger.error(e.getMessage());
        }
        SearchContainer<LabReport> searchContainer = new SearchContainer<LabReport>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM, 5,
                portletURL, headerNames, "LabReports not available");

        portletURL.setParameter(searchContainer.getCurParam(), String.valueOf(searchContainer.getCur()));

        List<LabReport> labReports = LabReportLocalServiceUtil.getBymrNumber(mrNumber, searchContainer.getStart(), searchContainer.getEnd());

        int total = LabReportLocalServiceUtil.getBymrNumber(mrNumber).size();
        searchContainer.setTotal(total);
        searchContainer.setResults(labReports);
        searchContainer.setDeltaConfigurable(true);

        List<ResultRow> resultRows = searchContainer.getResultRows();

        int i = 0;
        for (LabReport labReport : labReports) {
            ResultRow row = new ResultRow(labReport, labReport.getLabId(), i++);
            row.addText(labReport.getOrderNumber());
            row.addText(labReport.getOrderDate().toString());
            row.addText(labReport.getReportedOn().toString());
            row.addText(labReport.getIpNumber());
            row.addText(labReport.getTestName());
            row.addText(labReport.getDepartmentName());
            if (labReport.getStatus()) {
                row.addText("Viewed", labReport.getDocPath());
            } else {
                row.addText("View", labReport.getDocPath());
            }

            resultRows.add(row);
        }

        logger.info("labReports " + labReports.size());

        model.addAttribute("searchContainer", searchContainer);
    }

}
