create index IX_87446011 on NH_PP_BedAllocation (ipNumber);
create index IX_80F3028F on NH_PP_BedAllocation (mrNumber);

create index IX_A8ABD0F6 on NH_PP_BedReservation (bedClass);
create index IX_51045F3B on NH_PP_BedReservation (ward);

create index IX_CE2F0B8D on NH_PP_Deposit (depositNumber);
create index IX_D7E7236E on NH_PP_Deposit (ipNumber);
create index IX_D195C5EC on NH_PP_Deposit (mrNumber);
create index IX_4F42CAED on NH_PP_Deposit (patientBillId);

create index IX_153D553F on NH_PP_DiagnosticReport (ipNumber);
create index IX_EEBF7BD on NH_PP_DiagnosticReport (mrNumber);
create index IX_F9C929A3 on NH_PP_DiagnosticReport (mrNumber, status);
create index IX_474274A1 on NH_PP_DiagnosticReport (status);
create index IX_CF28CCEC on NH_PP_DiagnosticReport (testName);

create index IX_F68FD283 on NH_PP_DischargeSummary (admissionDate);
create index IX_945A04EF on NH_PP_DischargeSummary (bedClass);
create index IX_5EA8107C on NH_PP_DischargeSummary (dischargeDate);
create index IX_AA72888 on NH_PP_DischargeSummary (ipNumber);
create index IX_455CB06 on NH_PP_DischargeSummary (mrNumber);
create index IX_F45577B4 on NH_PP_DischargeSummary (ward);
create index IX_DE1CE55F on NH_PP_DischargeSummary (ward, bedClass);

create index IX_17906BF1 on NH_PP_LabReport (ipNumber);
create index IX_113F0E6F on NH_PP_LabReport (mrNumber);
create index IX_E06F8FD3 on NH_PP_LabReport (status);
create index IX_D17BE39E on NH_PP_LabReport (testName);

create index IX_22164052 on NH_PP_NapierUser (doctorId);
create index IX_20A7DA06 on NH_PP_NapierUser (mrNumber);
create index IX_4741328A on NH_PP_NapierUser (portalUserId);
create index IX_48C4D54C on NH_PP_NapierUser (tpaId);

create index IX_7355CE35 on NH_PP_PatientBill (company);
create index IX_CD64CD7C on NH_PP_PatientBill (ipNumber);
create index IX_C7136FFA on NH_PP_PatientBill (mrNumber);
create index IX_86DA25DC on NH_PP_PatientBill (sponser);
create index IX_C195F211 on NH_PP_PatientBill (sponser, company);