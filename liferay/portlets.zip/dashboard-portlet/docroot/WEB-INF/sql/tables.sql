create table NH_PP_BedAllocation (
	bedAllocationId LONG not null primary key,
	bedReservationNumber VARCHAR(75) null,
	bedReservationDate DATE null,
	mrNumber VARCHAR(75) null,
	ipNumber VARCHAR(75) null,
	bedNumber VARCHAR(75) null,
	joiningDate DATE null,
	admissionDate DATE null,
	patientName VARCHAR(75) null,
	age INTEGER,
	gender VARCHAR(75) null,
	mobile VARCHAR(75) null,
	email VARCHAR(75) null,
	status VARCHAR(75) null,
	createdUserId LONG
);

create table NH_PP_BedReservation (
	bedReservationId LONG not null primary key,
	bedClass VARCHAR(75) null,
	ward VARCHAR(75) null,
	totalBedCount INTEGER,
	vacantBedCount INTEGER,
	hospitalTariff DOUBLE,
	gender VARCHAR(75) null
);

create table NH_PP_Deposit (
	depositId LONG not null primary key,
	mrNumber VARCHAR(75) null,
	ipNumber VARCHAR(75) null,
	depositNumber VARCHAR(75) null,
	depositAmount DOUBLE,
	depositAgainst VARCHAR(75) null,
	patientBillId LONG
);

create table NH_PP_DiagnosticReport (
	diagnosticId LONG not null primary key,
	mrNumber VARCHAR(75) null,
	orderNumber VARCHAR(75) null,
	orderDate DATE null,
	reportedOn DATE null,
	ipNumber VARCHAR(75) null,
	testName VARCHAR(75) null,
	departmentName VARCHAR(75) null,
	status BOOLEAN,
	docPath VARCHAR(75) null
);

create table NH_PP_DischargeSummary (
	dischargeSummaryId LONG not null primary key,
	mrNumber VARCHAR(75) null,
	ipNumber VARCHAR(75) null,
	docPath VARCHAR(75) null,
	departmentName VARCHAR(75) null,
	status BOOLEAN,
	ward VARCHAR(75) null,
	bedClass VARCHAR(75) null,
	dischargeDate DATE null,
	admissionDate DATE null,
	primaryDoctor VARCHAR(75) null,
	chiefComplaint VARCHAR(75) null
);

create table NH_PP_DoctorAppointment (
	appointmentId LONG not null primary key,
	appointmentNumber VARCHAR(75) null,
	appointmentDate DATE null,
	doctorName VARCHAR(75) null,
	specialization VARCHAR(75) null,
	mrNumber VARCHAR(75) null,
	creationDate DATE null,
	fromTime VARCHAR(75) null,
	toTime VARCHAR(75) null,
	status VARCHAR(75) null,
	patientName VARCHAR(75) null,
	age INTEGER,
	gender VARCHAR(75) null,
	mobile VARCHAR(75) null,
	email VARCHAR(75) null,
	complaint VARCHAR(75) null,
	createdByUserId LONG
);

create table NH_PP_DoctorInformation (
	doctorInfoId LONG not null primary key,
	specialization VARCHAR(75) null,
	doctorName VARCHAR(75) null
);

create table NH_PP_LabReport (
	labId LONG not null primary key,
	mrNumber VARCHAR(75) null,
	orderNumber VARCHAR(75) null,
	orderDate DATE null,
	reportedOn DATE null,
	testName VARCHAR(75) null,
	ipNumber VARCHAR(75) null,
	docPath VARCHAR(75) null,
	departmentName VARCHAR(75) null,
	status BOOLEAN
);

create table NH_PP_NapierUser (
	napierUserId LONG not null primary key,
	portalUserId LONG,
	mrNumber VARCHAR(75) null,
	tpaId VARCHAR(75) null,
	coroporateId VARCHAR(75) null,
	doctorId VARCHAR(75) null,
	age INTEGER,
	mobile VARCHAR(75) null,
	gender VARCHAR(75) null,
	specialization VARCHAR(75) null,
	userType VARCHAR(75) null,
	email VARCHAR(75) null,
	name VARCHAR(75) null,
	address VARCHAR(75) null,
	street1 VARCHAR(75) null,
	street2 VARCHAR(75) null,
	postalCode VARCHAR(75) null
);

create table NH_PP_PatientBill (
	patientBillId LONG not null primary key,
	mrNumber VARCHAR(75) null,
	ipNumber VARCHAR(75) null,
	billNumber VARCHAR(75) null,
	company VARCHAR(75) null,
	sponser VARCHAR(75) null,
	planName VARCHAR(75) null,
	planExpiry DATE null,
	admissionDate DATE null,
	isBillgenerated BOOLEAN,
	isBalanceAmount BOOLEAN,
	billAmount DOUBLE,
	paidAmount DOUBLE
);