/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchDoctorAppointmentException;
import com.napier.portal.db.model.DoctorAppointment;
import com.napier.portal.db.model.impl.DoctorAppointmentImpl;
import com.napier.portal.db.model.impl.DoctorAppointmentModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the doctor appointment service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DoctorAppointmentPersistence
 * @see DoctorAppointmentUtil
 * @generated
 */
public class DoctorAppointmentPersistenceImpl extends BasePersistenceImpl<DoctorAppointment>
	implements DoctorAppointmentPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link DoctorAppointmentUtil} to access the doctor appointment persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = DoctorAppointmentImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
			DoctorAppointmentModelImpl.FINDER_CACHE_ENABLED,
			DoctorAppointmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
			DoctorAppointmentModelImpl.FINDER_CACHE_ENABLED,
			DoctorAppointmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
			DoctorAppointmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public DoctorAppointmentPersistenceImpl() {
		setModelClass(DoctorAppointment.class);
	}

	/**
	 * Caches the doctor appointment in the entity cache if it is enabled.
	 *
	 * @param doctorAppointment the doctor appointment
	 */
	@Override
	public void cacheResult(DoctorAppointment doctorAppointment) {
		EntityCacheUtil.putResult(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
			DoctorAppointmentImpl.class, doctorAppointment.getPrimaryKey(),
			doctorAppointment);

		doctorAppointment.resetOriginalValues();
	}

	/**
	 * Caches the doctor appointments in the entity cache if it is enabled.
	 *
	 * @param doctorAppointments the doctor appointments
	 */
	@Override
	public void cacheResult(List<DoctorAppointment> doctorAppointments) {
		for (DoctorAppointment doctorAppointment : doctorAppointments) {
			if (EntityCacheUtil.getResult(
						DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
						DoctorAppointmentImpl.class,
						doctorAppointment.getPrimaryKey()) == null) {
				cacheResult(doctorAppointment);
			}
			else {
				doctorAppointment.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all doctor appointments.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(DoctorAppointmentImpl.class.getName());
		}

		EntityCacheUtil.clearCache(DoctorAppointmentImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the doctor appointment.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(DoctorAppointment doctorAppointment) {
		EntityCacheUtil.removeResult(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
			DoctorAppointmentImpl.class, doctorAppointment.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<DoctorAppointment> doctorAppointments) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (DoctorAppointment doctorAppointment : doctorAppointments) {
			EntityCacheUtil.removeResult(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
				DoctorAppointmentImpl.class, doctorAppointment.getPrimaryKey());
		}
	}

	/**
	 * Creates a new doctor appointment with the primary key. Does not add the doctor appointment to the database.
	 *
	 * @param appointmentId the primary key for the new doctor appointment
	 * @return the new doctor appointment
	 */
	@Override
	public DoctorAppointment create(long appointmentId) {
		DoctorAppointment doctorAppointment = new DoctorAppointmentImpl();

		doctorAppointment.setNew(true);
		doctorAppointment.setPrimaryKey(appointmentId);

		return doctorAppointment;
	}

	/**
	 * Removes the doctor appointment with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param appointmentId the primary key of the doctor appointment
	 * @return the doctor appointment that was removed
	 * @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorAppointment remove(long appointmentId)
		throws NoSuchDoctorAppointmentException, SystemException {
		return remove((Serializable)appointmentId);
	}

	/**
	 * Removes the doctor appointment with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the doctor appointment
	 * @return the doctor appointment that was removed
	 * @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorAppointment remove(Serializable primaryKey)
		throws NoSuchDoctorAppointmentException, SystemException {
		Session session = null;

		try {
			session = openSession();

			DoctorAppointment doctorAppointment = (DoctorAppointment)session.get(DoctorAppointmentImpl.class,
					primaryKey);

			if (doctorAppointment == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDoctorAppointmentException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(doctorAppointment);
		}
		catch (NoSuchDoctorAppointmentException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected DoctorAppointment removeImpl(DoctorAppointment doctorAppointment)
		throws SystemException {
		doctorAppointment = toUnwrappedModel(doctorAppointment);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(doctorAppointment)) {
				doctorAppointment = (DoctorAppointment)session.get(DoctorAppointmentImpl.class,
						doctorAppointment.getPrimaryKeyObj());
			}

			if (doctorAppointment != null) {
				session.delete(doctorAppointment);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (doctorAppointment != null) {
			clearCache(doctorAppointment);
		}

		return doctorAppointment;
	}

	@Override
	public DoctorAppointment updateImpl(
		com.napier.portal.db.model.DoctorAppointment doctorAppointment)
		throws SystemException {
		doctorAppointment = toUnwrappedModel(doctorAppointment);

		boolean isNew = doctorAppointment.isNew();

		Session session = null;

		try {
			session = openSession();

			if (doctorAppointment.isNew()) {
				session.save(doctorAppointment);

				doctorAppointment.setNew(false);
			}
			else {
				session.merge(doctorAppointment);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
			DoctorAppointmentImpl.class, doctorAppointment.getPrimaryKey(),
			doctorAppointment);

		return doctorAppointment;
	}

	protected DoctorAppointment toUnwrappedModel(
		DoctorAppointment doctorAppointment) {
		if (doctorAppointment instanceof DoctorAppointmentImpl) {
			return doctorAppointment;
		}

		DoctorAppointmentImpl doctorAppointmentImpl = new DoctorAppointmentImpl();

		doctorAppointmentImpl.setNew(doctorAppointment.isNew());
		doctorAppointmentImpl.setPrimaryKey(doctorAppointment.getPrimaryKey());

		doctorAppointmentImpl.setAppointmentId(doctorAppointment.getAppointmentId());
		doctorAppointmentImpl.setAppointmentNumber(doctorAppointment.getAppointmentNumber());
		doctorAppointmentImpl.setAppointmentDate(doctorAppointment.getAppointmentDate());
		doctorAppointmentImpl.setDoctorId(doctorAppointment.getDoctorId());
		doctorAppointmentImpl.setMrNumber(doctorAppointment.getMrNumber());
		doctorAppointmentImpl.setCreationDate(doctorAppointment.getCreationDate());
		doctorAppointmentImpl.setFromTime(doctorAppointment.getFromTime());
		doctorAppointmentImpl.setToTime(doctorAppointment.getToTime());
		doctorAppointmentImpl.setStatus(doctorAppointment.getStatus());
		doctorAppointmentImpl.setPatientName(doctorAppointment.getPatientName());
		doctorAppointmentImpl.setAge(doctorAppointment.getAge());
		doctorAppointmentImpl.setGender(doctorAppointment.getGender());
		doctorAppointmentImpl.setMobile(doctorAppointment.getMobile());
		doctorAppointmentImpl.setEmail(doctorAppointment.getEmail());
		doctorAppointmentImpl.setComplaint(doctorAppointment.getComplaint());

		return doctorAppointmentImpl;
	}

	/**
	 * Returns the doctor appointment with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the doctor appointment
	 * @return the doctor appointment
	 * @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorAppointment findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDoctorAppointmentException, SystemException {
		DoctorAppointment doctorAppointment = fetchByPrimaryKey(primaryKey);

		if (doctorAppointment == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDoctorAppointmentException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return doctorAppointment;
	}

	/**
	 * Returns the doctor appointment with the primary key or throws a {@link com.napier.portal.db.NoSuchDoctorAppointmentException} if it could not be found.
	 *
	 * @param appointmentId the primary key of the doctor appointment
	 * @return the doctor appointment
	 * @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorAppointment findByPrimaryKey(long appointmentId)
		throws NoSuchDoctorAppointmentException, SystemException {
		return findByPrimaryKey((Serializable)appointmentId);
	}

	/**
	 * Returns the doctor appointment with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the doctor appointment
	 * @return the doctor appointment, or <code>null</code> if a doctor appointment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorAppointment fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		DoctorAppointment doctorAppointment = (DoctorAppointment)EntityCacheUtil.getResult(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
				DoctorAppointmentImpl.class, primaryKey);

		if (doctorAppointment == _nullDoctorAppointment) {
			return null;
		}

		if (doctorAppointment == null) {
			Session session = null;

			try {
				session = openSession();

				doctorAppointment = (DoctorAppointment)session.get(DoctorAppointmentImpl.class,
						primaryKey);

				if (doctorAppointment != null) {
					cacheResult(doctorAppointment);
				}
				else {
					EntityCacheUtil.putResult(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
						DoctorAppointmentImpl.class, primaryKey,
						_nullDoctorAppointment);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(DoctorAppointmentModelImpl.ENTITY_CACHE_ENABLED,
					DoctorAppointmentImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return doctorAppointment;
	}

	/**
	 * Returns the doctor appointment with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param appointmentId the primary key of the doctor appointment
	 * @return the doctor appointment, or <code>null</code> if a doctor appointment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorAppointment fetchByPrimaryKey(long appointmentId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)appointmentId);
	}

	/**
	 * Returns all the doctor appointments.
	 *
	 * @return the doctor appointments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DoctorAppointment> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the doctor appointments.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of doctor appointments
	 * @param end the upper bound of the range of doctor appointments (not inclusive)
	 * @return the range of doctor appointments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DoctorAppointment> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the doctor appointments.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of doctor appointments
	 * @param end the upper bound of the range of doctor appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of doctor appointments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DoctorAppointment> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<DoctorAppointment> list = (List<DoctorAppointment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_DOCTORAPPOINTMENT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DOCTORAPPOINTMENT;

				if (pagination) {
					sql = sql.concat(DoctorAppointmentModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<DoctorAppointment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DoctorAppointment>(list);
				}
				else {
					list = (List<DoctorAppointment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the doctor appointments from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (DoctorAppointment doctorAppointment : findAll()) {
			remove(doctorAppointment);
		}
	}

	/**
	 * Returns the number of doctor appointments.
	 *
	 * @return the number of doctor appointments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DOCTORAPPOINTMENT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the doctor appointment persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.DoctorAppointment")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<DoctorAppointment>> listenersList = new ArrayList<ModelListener<DoctorAppointment>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<DoctorAppointment>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(DoctorAppointmentImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_DOCTORAPPOINTMENT = "SELECT doctorAppointment FROM DoctorAppointment doctorAppointment";
	private static final String _SQL_COUNT_DOCTORAPPOINTMENT = "SELECT COUNT(doctorAppointment) FROM DoctorAppointment doctorAppointment";
	private static final String _ORDER_BY_ENTITY_ALIAS = "doctorAppointment.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No DoctorAppointment exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(DoctorAppointmentPersistenceImpl.class);
	private static DoctorAppointment _nullDoctorAppointment = new DoctorAppointmentImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<DoctorAppointment> toCacheModel() {
				return _nullDoctorAppointmentCacheModel;
			}
		};

	private static CacheModel<DoctorAppointment> _nullDoctorAppointmentCacheModel =
		new CacheModel<DoctorAppointment>() {
			@Override
			public DoctorAppointment toEntityModel() {
				return _nullDoctorAppointment;
			}
		};
}