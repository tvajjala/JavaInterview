/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchDiagnosticReportException;
import com.napier.portal.db.model.DiagnosticReport;
import com.napier.portal.db.model.impl.DiagnosticReportImpl;
import com.napier.portal.db.model.impl.DiagnosticReportModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the diagnostic report service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DiagnosticReportPersistence
 * @see DiagnosticReportUtil
 * @generated
 */
public class DiagnosticReportPersistenceImpl extends BasePersistenceImpl<DiagnosticReport>
	implements DiagnosticReportPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link DiagnosticReportUtil} to access the diagnostic report persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = DiagnosticReportImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBymrNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER =
		new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBymrNumber",
			new String[] { String.class.getName() },
			DiagnosticReportModelImpl.MRNUMBER_COLUMN_BITMASK |
			DiagnosticReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MRNUMBER = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymrNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the diagnostic reports where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBymrNumber(String mrNumber)
		throws SystemException {
		return findBymrNumber(mrNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the diagnostic reports where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @return the range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBymrNumber(String mrNumber, int start,
		int end) throws SystemException {
		return findBymrNumber(mrNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the diagnostic reports where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBymrNumber(String mrNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber, start, end, orderByComparator };
		}

		List<DiagnosticReport> list = (List<DiagnosticReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DiagnosticReport diagnosticReport : list) {
				if (!Validator.equals(mrNumber, diagnosticReport.getMrNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				if (!pagination) {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DiagnosticReport>(list);
				}
				else {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first diagnostic report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchBymrNumber_First(mrNumber,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the first diagnostic report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<DiagnosticReport> list = findBymrNumber(mrNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last diagnostic report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchBymrNumber_Last(mrNumber,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the last diagnostic report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBymrNumber(mrNumber);

		if (count == 0) {
			return null;
		}

		List<DiagnosticReport> list = findBymrNumber(mrNumber, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the diagnostic reports before and after the current diagnostic report in the ordered set where mrNumber = &#63;.
	 *
	 * @param diagnosticId the primary key of the current diagnostic report
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport[] findBymrNumber_PrevAndNext(long diagnosticId,
		String mrNumber, OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = findByPrimaryKey(diagnosticId);

		Session session = null;

		try {
			session = openSession();

			DiagnosticReport[] array = new DiagnosticReportImpl[3];

			array[0] = getBymrNumber_PrevAndNext(session, diagnosticReport,
					mrNumber, orderByComparator, true);

			array[1] = diagnosticReport;

			array[2] = getBymrNumber_PrevAndNext(session, diagnosticReport,
					mrNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DiagnosticReport getBymrNumber_PrevAndNext(Session session,
		DiagnosticReport diagnosticReport, String mrNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

		boolean bindMrNumber = false;

		if (mrNumber == null) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
		}
		else if (mrNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
		}
		else {
			bindMrNumber = true;

			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMrNumber) {
			qPos.add(mrNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(diagnosticReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DiagnosticReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the diagnostic reports where mrNumber = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBymrNumber(String mrNumber) throws SystemException {
		for (DiagnosticReport diagnosticReport : findBymrNumber(mrNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(diagnosticReport);
		}
	}

	/**
	 * Returns the number of diagnostic reports where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the number of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymrNumber(String mrNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MRNUMBER;

		Object[] finderArgs = new Object[] { mrNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DIAGNOSTICREPORT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_1 = "diagnosticReport.mrNumber IS NULL";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_2 = "diagnosticReport.mrNumber = ?";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_3 = "(diagnosticReport.mrNumber IS NULL OR diagnosticReport.mrNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByipNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER =
		new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByipNumber",
			new String[] { String.class.getName() },
			DiagnosticReportModelImpl.IPNUMBER_COLUMN_BITMASK |
			DiagnosticReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_IPNUMBER = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByipNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the diagnostic reports where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findByipNumber(String ipNumber)
		throws SystemException {
		return findByipNumber(ipNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the diagnostic reports where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @return the range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findByipNumber(String ipNumber, int start,
		int end) throws SystemException {
		return findByipNumber(ipNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the diagnostic reports where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findByipNumber(String ipNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber, start, end, orderByComparator };
		}

		List<DiagnosticReport> list = (List<DiagnosticReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DiagnosticReport diagnosticReport : list) {
				if (!Validator.equals(ipNumber, diagnosticReport.getIpNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				if (!pagination) {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DiagnosticReport>(list);
				}
				else {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first diagnostic report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchByipNumber_First(ipNumber,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the first diagnostic report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<DiagnosticReport> list = findByipNumber(ipNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last diagnostic report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchByipNumber_Last(ipNumber,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the last diagnostic report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByipNumber(ipNumber);

		if (count == 0) {
			return null;
		}

		List<DiagnosticReport> list = findByipNumber(ipNumber, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the diagnostic reports before and after the current diagnostic report in the ordered set where ipNumber = &#63;.
	 *
	 * @param diagnosticId the primary key of the current diagnostic report
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport[] findByipNumber_PrevAndNext(long diagnosticId,
		String ipNumber, OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = findByPrimaryKey(diagnosticId);

		Session session = null;

		try {
			session = openSession();

			DiagnosticReport[] array = new DiagnosticReportImpl[3];

			array[0] = getByipNumber_PrevAndNext(session, diagnosticReport,
					ipNumber, orderByComparator, true);

			array[1] = diagnosticReport;

			array[2] = getByipNumber_PrevAndNext(session, diagnosticReport,
					ipNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DiagnosticReport getByipNumber_PrevAndNext(Session session,
		DiagnosticReport diagnosticReport, String ipNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

		boolean bindIpNumber = false;

		if (ipNumber == null) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
		}
		else if (ipNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
		}
		else {
			bindIpNumber = true;

			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindIpNumber) {
			qPos.add(ipNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(diagnosticReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DiagnosticReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the diagnostic reports where ipNumber = &#63; from the database.
	 *
	 * @param ipNumber the ip number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByipNumber(String ipNumber) throws SystemException {
		for (DiagnosticReport diagnosticReport : findByipNumber(ipNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(diagnosticReport);
		}
	}

	/**
	 * Returns the number of diagnostic reports where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the number of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByipNumber(String ipNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_IPNUMBER;

		Object[] finderArgs = new Object[] { ipNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DIAGNOSTICREPORT_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_1 = "diagnosticReport.ipNumber IS NULL";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_2 = "diagnosticReport.ipNumber = ?";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_3 = "(diagnosticReport.ipNumber IS NULL OR diagnosticReport.ipNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_TESTNAME = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBytestName",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME =
		new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBytestName",
			new String[] { String.class.getName() },
			DiagnosticReportModelImpl.TESTNAME_COLUMN_BITMASK |
			DiagnosticReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TESTNAME = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBytestName",
			new String[] { String.class.getName() });

	/**
	 * Returns all the diagnostic reports where testName = &#63;.
	 *
	 * @param testName the test name
	 * @return the matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBytestName(String testName)
		throws SystemException {
		return findBytestName(testName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the diagnostic reports where testName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param testName the test name
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @return the range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBytestName(String testName, int start,
		int end) throws SystemException {
		return findBytestName(testName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the diagnostic reports where testName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param testName the test name
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBytestName(String testName, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME;
			finderArgs = new Object[] { testName };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_TESTNAME;
			finderArgs = new Object[] { testName, start, end, orderByComparator };
		}

		List<DiagnosticReport> list = (List<DiagnosticReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DiagnosticReport diagnosticReport : list) {
				if (!Validator.equals(testName, diagnosticReport.getTestName())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

			boolean bindTestName = false;

			if (testName == null) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_1);
			}
			else if (testName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_3);
			}
			else {
				bindTestName = true;

				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTestName) {
					qPos.add(testName);
				}

				if (!pagination) {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DiagnosticReport>(list);
				}
				else {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first diagnostic report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findBytestName_First(String testName,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchBytestName_First(testName,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("testName=");
		msg.append(testName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the first diagnostic report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchBytestName_First(String testName,
		OrderByComparator orderByComparator) throws SystemException {
		List<DiagnosticReport> list = findBytestName(testName, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last diagnostic report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findBytestName_Last(String testName,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchBytestName_Last(testName,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("testName=");
		msg.append(testName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the last diagnostic report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchBytestName_Last(String testName,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBytestName(testName);

		if (count == 0) {
			return null;
		}

		List<DiagnosticReport> list = findBytestName(testName, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the diagnostic reports before and after the current diagnostic report in the ordered set where testName = &#63;.
	 *
	 * @param diagnosticId the primary key of the current diagnostic report
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport[] findBytestName_PrevAndNext(long diagnosticId,
		String testName, OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = findByPrimaryKey(diagnosticId);

		Session session = null;

		try {
			session = openSession();

			DiagnosticReport[] array = new DiagnosticReportImpl[3];

			array[0] = getBytestName_PrevAndNext(session, diagnosticReport,
					testName, orderByComparator, true);

			array[1] = diagnosticReport;

			array[2] = getBytestName_PrevAndNext(session, diagnosticReport,
					testName, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DiagnosticReport getBytestName_PrevAndNext(Session session,
		DiagnosticReport diagnosticReport, String testName,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

		boolean bindTestName = false;

		if (testName == null) {
			query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_1);
		}
		else if (testName.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_3);
		}
		else {
			bindTestName = true;

			query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindTestName) {
			qPos.add(testName);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(diagnosticReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DiagnosticReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the diagnostic reports where testName = &#63; from the database.
	 *
	 * @param testName the test name
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBytestName(String testName) throws SystemException {
		for (DiagnosticReport diagnosticReport : findBytestName(testName,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(diagnosticReport);
		}
	}

	/**
	 * Returns the number of diagnostic reports where testName = &#63;.
	 *
	 * @param testName the test name
	 * @return the number of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBytestName(String testName) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TESTNAME;

		Object[] finderArgs = new Object[] { testName };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DIAGNOSTICREPORT_WHERE);

			boolean bindTestName = false;

			if (testName == null) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_1);
			}
			else if (testName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_3);
			}
			else {
				bindTestName = true;

				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTestName) {
					qPos.add(testName);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TESTNAME_TESTNAME_1 = "diagnosticReport.testName IS NULL";
	private static final String _FINDER_COLUMN_TESTNAME_TESTNAME_2 = "diagnosticReport.testName = ?";
	private static final String _FINDER_COLUMN_TESTNAME_TESTNAME_3 = "(diagnosticReport.testName IS NULL OR diagnosticReport.testName = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_STATUS = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBystatus",
			new String[] {
				Boolean.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS =
		new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBystatus",
			new String[] { Boolean.class.getName() },
			DiagnosticReportModelImpl.STATUS_COLUMN_BITMASK |
			DiagnosticReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_STATUS = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBystatus",
			new String[] { Boolean.class.getName() });

	/**
	 * Returns all the diagnostic reports where status = &#63;.
	 *
	 * @param status the status
	 * @return the matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBystatus(boolean status)
		throws SystemException {
		return findBystatus(status, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the diagnostic reports where status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @return the range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBystatus(boolean status, int start,
		int end) throws SystemException {
		return findBystatus(status, start, end, null);
	}

	/**
	 * Returns an ordered range of all the diagnostic reports where status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findBystatus(boolean status, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS;
			finderArgs = new Object[] { status };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_STATUS;
			finderArgs = new Object[] { status, start, end, orderByComparator };
		}

		List<DiagnosticReport> list = (List<DiagnosticReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DiagnosticReport diagnosticReport : list) {
				if ((status != diagnosticReport.getStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

			query.append(_FINDER_COLUMN_STATUS_STATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(status);

				if (!pagination) {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DiagnosticReport>(list);
				}
				else {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first diagnostic report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findBystatus_First(boolean status,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchBystatus_First(status,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the first diagnostic report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchBystatus_First(boolean status,
		OrderByComparator orderByComparator) throws SystemException {
		List<DiagnosticReport> list = findBystatus(status, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last diagnostic report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findBystatus_Last(boolean status,
		OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchBystatus_Last(status,
				orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the last diagnostic report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchBystatus_Last(boolean status,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBystatus(status);

		if (count == 0) {
			return null;
		}

		List<DiagnosticReport> list = findBystatus(status, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the diagnostic reports before and after the current diagnostic report in the ordered set where status = &#63;.
	 *
	 * @param diagnosticId the primary key of the current diagnostic report
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport[] findBystatus_PrevAndNext(long diagnosticId,
		boolean status, OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = findByPrimaryKey(diagnosticId);

		Session session = null;

		try {
			session = openSession();

			DiagnosticReport[] array = new DiagnosticReportImpl[3];

			array[0] = getBystatus_PrevAndNext(session, diagnosticReport,
					status, orderByComparator, true);

			array[1] = diagnosticReport;

			array[2] = getBystatus_PrevAndNext(session, diagnosticReport,
					status, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DiagnosticReport getBystatus_PrevAndNext(Session session,
		DiagnosticReport diagnosticReport, boolean status,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

		query.append(_FINDER_COLUMN_STATUS_STATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(status);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(diagnosticReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DiagnosticReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the diagnostic reports where status = &#63; from the database.
	 *
	 * @param status the status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBystatus(boolean status) throws SystemException {
		for (DiagnosticReport diagnosticReport : findBystatus(status,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(diagnosticReport);
		}
	}

	/**
	 * Returns the number of diagnostic reports where status = &#63;.
	 *
	 * @param status the status
	 * @return the number of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBystatus(boolean status) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_STATUS;

		Object[] finderArgs = new Object[] { status };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DIAGNOSTICREPORT_WHERE);

			query.append(_FINDER_COLUMN_STATUS_STATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(status);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATUS_STATUS_2 = "diagnosticReport.status = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_MR_STATUS =
		new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByMR_STATUS",
			new String[] {
				String.class.getName(), Boolean.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MR_STATUS =
		new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED,
			DiagnosticReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMR_STATUS",
			new String[] { String.class.getName(), Boolean.class.getName() },
			DiagnosticReportModelImpl.MRNUMBER_COLUMN_BITMASK |
			DiagnosticReportModelImpl.STATUS_COLUMN_BITMASK |
			DiagnosticReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MR_STATUS = new FinderPath(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMR_STATUS",
			new String[] { String.class.getName(), Boolean.class.getName() });

	/**
	 * Returns all the diagnostic reports where mrNumber = &#63; and status = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @return the matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findByMR_STATUS(String mrNumber,
		boolean status) throws SystemException {
		return findByMR_STATUS(mrNumber, status, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the diagnostic reports where mrNumber = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @return the range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findByMR_STATUS(String mrNumber,
		boolean status, int start, int end) throws SystemException {
		return findByMR_STATUS(mrNumber, status, start, end, null);
	}

	/**
	 * Returns an ordered range of all the diagnostic reports where mrNumber = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findByMR_STATUS(String mrNumber,
		boolean status, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MR_STATUS;
			finderArgs = new Object[] { mrNumber, status };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_MR_STATUS;
			finderArgs = new Object[] {
					mrNumber, status,
					
					start, end, orderByComparator
				};
		}

		List<DiagnosticReport> list = (List<DiagnosticReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DiagnosticReport diagnosticReport : list) {
				if (!Validator.equals(mrNumber, diagnosticReport.getMrNumber()) ||
						(status != diagnosticReport.getStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_2);
			}

			query.append(_FINDER_COLUMN_MR_STATUS_STATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				qPos.add(status);

				if (!pagination) {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DiagnosticReport>(list);
				}
				else {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findByMR_STATUS_First(String mrNumber,
		boolean status, OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchByMR_STATUS_First(mrNumber,
				status, orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the first diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchByMR_STATUS_First(String mrNumber,
		boolean status, OrderByComparator orderByComparator)
		throws SystemException {
		List<DiagnosticReport> list = findByMR_STATUS(mrNumber, status, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findByMR_STATUS_Last(String mrNumber,
		boolean status, OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchByMR_STATUS_Last(mrNumber,
				status, orderByComparator);

		if (diagnosticReport != null) {
			return diagnosticReport;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDiagnosticReportException(msg.toString());
	}

	/**
	 * Returns the last diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchByMR_STATUS_Last(String mrNumber,
		boolean status, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByMR_STATUS(mrNumber, status);

		if (count == 0) {
			return null;
		}

		List<DiagnosticReport> list = findByMR_STATUS(mrNumber, status,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the diagnostic reports before and after the current diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	 *
	 * @param diagnosticId the primary key of the current diagnostic report
	 * @param mrNumber the mr number
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport[] findByMR_STATUS_PrevAndNext(long diagnosticId,
		String mrNumber, boolean status, OrderByComparator orderByComparator)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = findByPrimaryKey(diagnosticId);

		Session session = null;

		try {
			session = openSession();

			DiagnosticReport[] array = new DiagnosticReportImpl[3];

			array[0] = getByMR_STATUS_PrevAndNext(session, diagnosticReport,
					mrNumber, status, orderByComparator, true);

			array[1] = diagnosticReport;

			array[2] = getByMR_STATUS_PrevAndNext(session, diagnosticReport,
					mrNumber, status, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DiagnosticReport getByMR_STATUS_PrevAndNext(Session session,
		DiagnosticReport diagnosticReport, String mrNumber, boolean status,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DIAGNOSTICREPORT_WHERE);

		boolean bindMrNumber = false;

		if (mrNumber == null) {
			query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_1);
		}
		else if (mrNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_3);
		}
		else {
			bindMrNumber = true;

			query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_2);
		}

		query.append(_FINDER_COLUMN_MR_STATUS_STATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DiagnosticReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMrNumber) {
			qPos.add(mrNumber);
		}

		qPos.add(status);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(diagnosticReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DiagnosticReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the diagnostic reports where mrNumber = &#63; and status = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByMR_STATUS(String mrNumber, boolean status)
		throws SystemException {
		for (DiagnosticReport diagnosticReport : findByMR_STATUS(mrNumber,
				status, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(diagnosticReport);
		}
	}

	/**
	 * Returns the number of diagnostic reports where mrNumber = &#63; and status = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param status the status
	 * @return the number of matching diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByMR_STATUS(String mrNumber, boolean status)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MR_STATUS;

		Object[] finderArgs = new Object[] { mrNumber, status };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DIAGNOSTICREPORT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MR_STATUS_MRNUMBER_2);
			}

			query.append(_FINDER_COLUMN_MR_STATUS_STATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				qPos.add(status);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MR_STATUS_MRNUMBER_1 = "diagnosticReport.mrNumber IS NULL AND ";
	private static final String _FINDER_COLUMN_MR_STATUS_MRNUMBER_2 = "diagnosticReport.mrNumber = ? AND ";
	private static final String _FINDER_COLUMN_MR_STATUS_MRNUMBER_3 = "(diagnosticReport.mrNumber IS NULL OR diagnosticReport.mrNumber = '') AND ";
	private static final String _FINDER_COLUMN_MR_STATUS_STATUS_2 = "diagnosticReport.status = ?";

	public DiagnosticReportPersistenceImpl() {
		setModelClass(DiagnosticReport.class);
	}

	/**
	 * Caches the diagnostic report in the entity cache if it is enabled.
	 *
	 * @param diagnosticReport the diagnostic report
	 */
	@Override
	public void cacheResult(DiagnosticReport diagnosticReport) {
		EntityCacheUtil.putResult(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportImpl.class, diagnosticReport.getPrimaryKey(),
			diagnosticReport);

		diagnosticReport.resetOriginalValues();
	}

	/**
	 * Caches the diagnostic reports in the entity cache if it is enabled.
	 *
	 * @param diagnosticReports the diagnostic reports
	 */
	@Override
	public void cacheResult(List<DiagnosticReport> diagnosticReports) {
		for (DiagnosticReport diagnosticReport : diagnosticReports) {
			if (EntityCacheUtil.getResult(
						DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
						DiagnosticReportImpl.class,
						diagnosticReport.getPrimaryKey()) == null) {
				cacheResult(diagnosticReport);
			}
			else {
				diagnosticReport.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all diagnostic reports.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(DiagnosticReportImpl.class.getName());
		}

		EntityCacheUtil.clearCache(DiagnosticReportImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the diagnostic report.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(DiagnosticReport diagnosticReport) {
		EntityCacheUtil.removeResult(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportImpl.class, diagnosticReport.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<DiagnosticReport> diagnosticReports) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (DiagnosticReport diagnosticReport : diagnosticReports) {
			EntityCacheUtil.removeResult(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
				DiagnosticReportImpl.class, diagnosticReport.getPrimaryKey());
		}
	}

	/**
	 * Creates a new diagnostic report with the primary key. Does not add the diagnostic report to the database.
	 *
	 * @param diagnosticId the primary key for the new diagnostic report
	 * @return the new diagnostic report
	 */
	@Override
	public DiagnosticReport create(long diagnosticId) {
		DiagnosticReport diagnosticReport = new DiagnosticReportImpl();

		diagnosticReport.setNew(true);
		diagnosticReport.setPrimaryKey(diagnosticId);

		return diagnosticReport;
	}

	/**
	 * Removes the diagnostic report with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param diagnosticId the primary key of the diagnostic report
	 * @return the diagnostic report that was removed
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport remove(long diagnosticId)
		throws NoSuchDiagnosticReportException, SystemException {
		return remove((Serializable)diagnosticId);
	}

	/**
	 * Removes the diagnostic report with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the diagnostic report
	 * @return the diagnostic report that was removed
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport remove(Serializable primaryKey)
		throws NoSuchDiagnosticReportException, SystemException {
		Session session = null;

		try {
			session = openSession();

			DiagnosticReport diagnosticReport = (DiagnosticReport)session.get(DiagnosticReportImpl.class,
					primaryKey);

			if (diagnosticReport == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDiagnosticReportException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(diagnosticReport);
		}
		catch (NoSuchDiagnosticReportException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected DiagnosticReport removeImpl(DiagnosticReport diagnosticReport)
		throws SystemException {
		diagnosticReport = toUnwrappedModel(diagnosticReport);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(diagnosticReport)) {
				diagnosticReport = (DiagnosticReport)session.get(DiagnosticReportImpl.class,
						diagnosticReport.getPrimaryKeyObj());
			}

			if (diagnosticReport != null) {
				session.delete(diagnosticReport);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (diagnosticReport != null) {
			clearCache(diagnosticReport);
		}

		return diagnosticReport;
	}

	@Override
	public DiagnosticReport updateImpl(
		com.napier.portal.db.model.DiagnosticReport diagnosticReport)
		throws SystemException {
		diagnosticReport = toUnwrappedModel(diagnosticReport);

		boolean isNew = diagnosticReport.isNew();

		DiagnosticReportModelImpl diagnosticReportModelImpl = (DiagnosticReportModelImpl)diagnosticReport;

		Session session = null;

		try {
			session = openSession();

			if (diagnosticReport.isNew()) {
				session.save(diagnosticReport);

				diagnosticReport.setNew(false);
			}
			else {
				session.merge(diagnosticReport);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !DiagnosticReportModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((diagnosticReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						diagnosticReportModelImpl.getOriginalMrNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);

				args = new Object[] { diagnosticReportModelImpl.getMrNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);
			}

			if ((diagnosticReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						diagnosticReportModelImpl.getOriginalIpNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);

				args = new Object[] { diagnosticReportModelImpl.getIpNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);
			}

			if ((diagnosticReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						diagnosticReportModelImpl.getOriginalTestName()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TESTNAME, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME,
					args);

				args = new Object[] { diagnosticReportModelImpl.getTestName() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TESTNAME, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME,
					args);
			}

			if ((diagnosticReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						diagnosticReportModelImpl.getOriginalStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATUS, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS,
					args);

				args = new Object[] { diagnosticReportModelImpl.getStatus() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATUS, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS,
					args);
			}

			if ((diagnosticReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MR_STATUS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						diagnosticReportModelImpl.getOriginalMrNumber(),
						diagnosticReportModelImpl.getOriginalStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MR_STATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MR_STATUS,
					args);

				args = new Object[] {
						diagnosticReportModelImpl.getMrNumber(),
						diagnosticReportModelImpl.getStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MR_STATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MR_STATUS,
					args);
			}
		}

		EntityCacheUtil.putResult(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
			DiagnosticReportImpl.class, diagnosticReport.getPrimaryKey(),
			diagnosticReport);

		return diagnosticReport;
	}

	protected DiagnosticReport toUnwrappedModel(
		DiagnosticReport diagnosticReport) {
		if (diagnosticReport instanceof DiagnosticReportImpl) {
			return diagnosticReport;
		}

		DiagnosticReportImpl diagnosticReportImpl = new DiagnosticReportImpl();

		diagnosticReportImpl.setNew(diagnosticReport.isNew());
		diagnosticReportImpl.setPrimaryKey(diagnosticReport.getPrimaryKey());

		diagnosticReportImpl.setDiagnosticId(diagnosticReport.getDiagnosticId());
		diagnosticReportImpl.setMrNumber(diagnosticReport.getMrNumber());
		diagnosticReportImpl.setOrderNumber(diagnosticReport.getOrderNumber());
		diagnosticReportImpl.setOrderDate(diagnosticReport.getOrderDate());
		diagnosticReportImpl.setReportedOn(diagnosticReport.getReportedOn());
		diagnosticReportImpl.setIpNumber(diagnosticReport.getIpNumber());
		diagnosticReportImpl.setTestName(diagnosticReport.getTestName());
		diagnosticReportImpl.setDepartmentName(diagnosticReport.getDepartmentName());
		diagnosticReportImpl.setStatus(diagnosticReport.isStatus());
		diagnosticReportImpl.setDocPath(diagnosticReport.getDocPath());

		return diagnosticReportImpl;
	}

	/**
	 * Returns the diagnostic report with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the diagnostic report
	 * @return the diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDiagnosticReportException, SystemException {
		DiagnosticReport diagnosticReport = fetchByPrimaryKey(primaryKey);

		if (diagnosticReport == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDiagnosticReportException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return diagnosticReport;
	}

	/**
	 * Returns the diagnostic report with the primary key or throws a {@link com.napier.portal.db.NoSuchDiagnosticReportException} if it could not be found.
	 *
	 * @param diagnosticId the primary key of the diagnostic report
	 * @return the diagnostic report
	 * @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport findByPrimaryKey(long diagnosticId)
		throws NoSuchDiagnosticReportException, SystemException {
		return findByPrimaryKey((Serializable)diagnosticId);
	}

	/**
	 * Returns the diagnostic report with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the diagnostic report
	 * @return the diagnostic report, or <code>null</code> if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		DiagnosticReport diagnosticReport = (DiagnosticReport)EntityCacheUtil.getResult(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
				DiagnosticReportImpl.class, primaryKey);

		if (diagnosticReport == _nullDiagnosticReport) {
			return null;
		}

		if (diagnosticReport == null) {
			Session session = null;

			try {
				session = openSession();

				diagnosticReport = (DiagnosticReport)session.get(DiagnosticReportImpl.class,
						primaryKey);

				if (diagnosticReport != null) {
					cacheResult(diagnosticReport);
				}
				else {
					EntityCacheUtil.putResult(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
						DiagnosticReportImpl.class, primaryKey,
						_nullDiagnosticReport);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(DiagnosticReportModelImpl.ENTITY_CACHE_ENABLED,
					DiagnosticReportImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return diagnosticReport;
	}

	/**
	 * Returns the diagnostic report with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param diagnosticId the primary key of the diagnostic report
	 * @return the diagnostic report, or <code>null</code> if a diagnostic report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DiagnosticReport fetchByPrimaryKey(long diagnosticId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)diagnosticId);
	}

	/**
	 * Returns all the diagnostic reports.
	 *
	 * @return the diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the diagnostic reports.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @return the range of diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the diagnostic reports.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of diagnostic reports
	 * @param end the upper bound of the range of diagnostic reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DiagnosticReport> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<DiagnosticReport> list = (List<DiagnosticReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_DIAGNOSTICREPORT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DIAGNOSTICREPORT;

				if (pagination) {
					sql = sql.concat(DiagnosticReportModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DiagnosticReport>(list);
				}
				else {
					list = (List<DiagnosticReport>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the diagnostic reports from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (DiagnosticReport diagnosticReport : findAll()) {
			remove(diagnosticReport);
		}
	}

	/**
	 * Returns the number of diagnostic reports.
	 *
	 * @return the number of diagnostic reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DIAGNOSTICREPORT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the diagnostic report persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.DiagnosticReport")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<DiagnosticReport>> listenersList = new ArrayList<ModelListener<DiagnosticReport>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<DiagnosticReport>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(DiagnosticReportImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_DIAGNOSTICREPORT = "SELECT diagnosticReport FROM DiagnosticReport diagnosticReport";
	private static final String _SQL_SELECT_DIAGNOSTICREPORT_WHERE = "SELECT diagnosticReport FROM DiagnosticReport diagnosticReport WHERE ";
	private static final String _SQL_COUNT_DIAGNOSTICREPORT = "SELECT COUNT(diagnosticReport) FROM DiagnosticReport diagnosticReport";
	private static final String _SQL_COUNT_DIAGNOSTICREPORT_WHERE = "SELECT COUNT(diagnosticReport) FROM DiagnosticReport diagnosticReport WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "diagnosticReport.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No DiagnosticReport exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No DiagnosticReport exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(DiagnosticReportPersistenceImpl.class);
	private static DiagnosticReport _nullDiagnosticReport = new DiagnosticReportImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<DiagnosticReport> toCacheModel() {
				return _nullDiagnosticReportCacheModel;
			}
		};

	private static CacheModel<DiagnosticReport> _nullDiagnosticReportCacheModel = new CacheModel<DiagnosticReport>() {
			@Override
			public DiagnosticReport toEntityModel() {
				return _nullDiagnosticReport;
			}
		};
}