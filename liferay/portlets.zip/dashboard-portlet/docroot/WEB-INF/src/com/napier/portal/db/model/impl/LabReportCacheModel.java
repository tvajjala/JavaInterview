/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.LabReport;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing LabReport in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see LabReport
 * @generated
 */
public class LabReportCacheModel implements CacheModel<LabReport>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{labId=");
		sb.append(labId);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", orderNumber=");
		sb.append(orderNumber);
		sb.append(", orderDate=");
		sb.append(orderDate);
		sb.append(", reportedOn=");
		sb.append(reportedOn);
		sb.append(", testName=");
		sb.append(testName);
		sb.append(", ipNumber=");
		sb.append(ipNumber);
		sb.append(", docPath=");
		sb.append(docPath);
		sb.append(", departmentName=");
		sb.append(departmentName);
		sb.append(", status=");
		sb.append(status);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public LabReport toEntityModel() {
		LabReportImpl labReportImpl = new LabReportImpl();

		labReportImpl.setLabId(labId);

		if (mrNumber == null) {
			labReportImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			labReportImpl.setMrNumber(mrNumber);
		}

		if (orderNumber == null) {
			labReportImpl.setOrderNumber(StringPool.BLANK);
		}
		else {
			labReportImpl.setOrderNumber(orderNumber);
		}

		if (orderDate == Long.MIN_VALUE) {
			labReportImpl.setOrderDate(null);
		}
		else {
			labReportImpl.setOrderDate(new Date(orderDate));
		}

		if (reportedOn == Long.MIN_VALUE) {
			labReportImpl.setReportedOn(null);
		}
		else {
			labReportImpl.setReportedOn(new Date(reportedOn));
		}

		if (testName == null) {
			labReportImpl.setTestName(StringPool.BLANK);
		}
		else {
			labReportImpl.setTestName(testName);
		}

		if (ipNumber == null) {
			labReportImpl.setIpNumber(StringPool.BLANK);
		}
		else {
			labReportImpl.setIpNumber(ipNumber);
		}

		if (docPath == null) {
			labReportImpl.setDocPath(StringPool.BLANK);
		}
		else {
			labReportImpl.setDocPath(docPath);
		}

		if (departmentName == null) {
			labReportImpl.setDepartmentName(StringPool.BLANK);
		}
		else {
			labReportImpl.setDepartmentName(departmentName);
		}

		labReportImpl.setStatus(status);

		labReportImpl.resetOriginalValues();

		return labReportImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		labId = objectInput.readLong();
		mrNumber = objectInput.readUTF();
		orderNumber = objectInput.readUTF();
		orderDate = objectInput.readLong();
		reportedOn = objectInput.readLong();
		testName = objectInput.readUTF();
		ipNumber = objectInput.readUTF();
		docPath = objectInput.readUTF();
		departmentName = objectInput.readUTF();
		status = objectInput.readBoolean();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(labId);

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		if (orderNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(orderNumber);
		}

		objectOutput.writeLong(orderDate);
		objectOutput.writeLong(reportedOn);

		if (testName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(testName);
		}

		if (ipNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ipNumber);
		}

		if (docPath == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(docPath);
		}

		if (departmentName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(departmentName);
		}

		objectOutput.writeBoolean(status);
	}

	public long labId;
	public String mrNumber;
	public String orderNumber;
	public long orderDate;
	public long reportedOn;
	public String testName;
	public String ipNumber;
	public String docPath;
	public String departmentName;
	public boolean status;
}