/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.DiagnosticReport;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing DiagnosticReport in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see DiagnosticReport
 * @generated
 */
public class DiagnosticReportCacheModel implements CacheModel<DiagnosticReport>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{diagnosticId=");
		sb.append(diagnosticId);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", orderNumber=");
		sb.append(orderNumber);
		sb.append(", orderDate=");
		sb.append(orderDate);
		sb.append(", reportedOn=");
		sb.append(reportedOn);
		sb.append(", ipNumber=");
		sb.append(ipNumber);
		sb.append(", testName=");
		sb.append(testName);
		sb.append(", departmentName=");
		sb.append(departmentName);
		sb.append(", status=");
		sb.append(status);
		sb.append(", docPath=");
		sb.append(docPath);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public DiagnosticReport toEntityModel() {
		DiagnosticReportImpl diagnosticReportImpl = new DiagnosticReportImpl();

		diagnosticReportImpl.setDiagnosticId(diagnosticId);

		if (mrNumber == null) {
			diagnosticReportImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			diagnosticReportImpl.setMrNumber(mrNumber);
		}

		if (orderNumber == null) {
			diagnosticReportImpl.setOrderNumber(StringPool.BLANK);
		}
		else {
			diagnosticReportImpl.setOrderNumber(orderNumber);
		}

		if (orderDate == Long.MIN_VALUE) {
			diagnosticReportImpl.setOrderDate(null);
		}
		else {
			diagnosticReportImpl.setOrderDate(new Date(orderDate));
		}

		if (reportedOn == Long.MIN_VALUE) {
			diagnosticReportImpl.setReportedOn(null);
		}
		else {
			diagnosticReportImpl.setReportedOn(new Date(reportedOn));
		}

		if (ipNumber == null) {
			diagnosticReportImpl.setIpNumber(StringPool.BLANK);
		}
		else {
			diagnosticReportImpl.setIpNumber(ipNumber);
		}

		if (testName == null) {
			diagnosticReportImpl.setTestName(StringPool.BLANK);
		}
		else {
			diagnosticReportImpl.setTestName(testName);
		}

		if (departmentName == null) {
			diagnosticReportImpl.setDepartmentName(StringPool.BLANK);
		}
		else {
			diagnosticReportImpl.setDepartmentName(departmentName);
		}

		diagnosticReportImpl.setStatus(status);

		if (docPath == null) {
			diagnosticReportImpl.setDocPath(StringPool.BLANK);
		}
		else {
			diagnosticReportImpl.setDocPath(docPath);
		}

		diagnosticReportImpl.resetOriginalValues();

		return diagnosticReportImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		diagnosticId = objectInput.readLong();
		mrNumber = objectInput.readUTF();
		orderNumber = objectInput.readUTF();
		orderDate = objectInput.readLong();
		reportedOn = objectInput.readLong();
		ipNumber = objectInput.readUTF();
		testName = objectInput.readUTF();
		departmentName = objectInput.readUTF();
		status = objectInput.readBoolean();
		docPath = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(diagnosticId);

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		if (orderNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(orderNumber);
		}

		objectOutput.writeLong(orderDate);
		objectOutput.writeLong(reportedOn);

		if (ipNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ipNumber);
		}

		if (testName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(testName);
		}

		if (departmentName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(departmentName);
		}

		objectOutput.writeBoolean(status);

		if (docPath == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(docPath);
		}
	}

	public long diagnosticId;
	public String mrNumber;
	public String orderNumber;
	public long orderDate;
	public long reportedOn;
	public String ipNumber;
	public String testName;
	public String departmentName;
	public boolean status;
	public String docPath;
}