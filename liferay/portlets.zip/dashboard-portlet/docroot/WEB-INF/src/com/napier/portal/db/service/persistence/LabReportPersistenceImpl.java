/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchLabReportException;
import com.napier.portal.db.model.LabReport;
import com.napier.portal.db.model.impl.LabReportImpl;
import com.napier.portal.db.model.impl.LabReportModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the lab report service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see LabReportPersistence
 * @see LabReportUtil
 * @generated
 */
public class LabReportPersistenceImpl extends BasePersistenceImpl<LabReport>
	implements LabReportPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link LabReportUtil} to access the lab report persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = LabReportImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBymrNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER =
		new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBymrNumber",
			new String[] { String.class.getName() },
			LabReportModelImpl.MRNUMBER_COLUMN_BITMASK |
			LabReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MRNUMBER = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymrNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the lab reports where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBymrNumber(String mrNumber)
		throws SystemException {
		return findBymrNumber(mrNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the lab reports where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @return the range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBymrNumber(String mrNumber, int start, int end)
		throws SystemException {
		return findBymrNumber(mrNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the lab reports where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBymrNumber(String mrNumber, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber, start, end, orderByComparator };
		}

		List<LabReport> list = (List<LabReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (LabReport labReport : list) {
				if (!Validator.equals(mrNumber, labReport.getMrNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_LABREPORT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(LabReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				if (!pagination) {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<LabReport>(list);
				}
				else {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first lab report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchBymrNumber_First(mrNumber, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the first lab report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<LabReport> list = findBymrNumber(mrNumber, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last lab report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchBymrNumber_Last(mrNumber, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the last lab report in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBymrNumber(mrNumber);

		if (count == 0) {
			return null;
		}

		List<LabReport> list = findBymrNumber(mrNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the lab reports before and after the current lab report in the ordered set where mrNumber = &#63;.
	 *
	 * @param labId the primary key of the current lab report
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport[] findBymrNumber_PrevAndNext(long labId, String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = findByPrimaryKey(labId);

		Session session = null;

		try {
			session = openSession();

			LabReport[] array = new LabReportImpl[3];

			array[0] = getBymrNumber_PrevAndNext(session, labReport, mrNumber,
					orderByComparator, true);

			array[1] = labReport;

			array[2] = getBymrNumber_PrevAndNext(session, labReport, mrNumber,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected LabReport getBymrNumber_PrevAndNext(Session session,
		LabReport labReport, String mrNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_LABREPORT_WHERE);

		boolean bindMrNumber = false;

		if (mrNumber == null) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
		}
		else if (mrNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
		}
		else {
			bindMrNumber = true;

			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(LabReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMrNumber) {
			qPos.add(mrNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(labReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<LabReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the lab reports where mrNumber = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBymrNumber(String mrNumber) throws SystemException {
		for (LabReport labReport : findBymrNumber(mrNumber, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(labReport);
		}
	}

	/**
	 * Returns the number of lab reports where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the number of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymrNumber(String mrNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MRNUMBER;

		Object[] finderArgs = new Object[] { mrNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_LABREPORT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_1 = "labReport.mrNumber IS NULL";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_2 = "labReport.mrNumber = ?";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_3 = "(labReport.mrNumber IS NULL OR labReport.mrNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByipNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER =
		new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByipNumber",
			new String[] { String.class.getName() },
			LabReportModelImpl.IPNUMBER_COLUMN_BITMASK |
			LabReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_IPNUMBER = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByipNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the lab reports where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findByipNumber(String ipNumber)
		throws SystemException {
		return findByipNumber(ipNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the lab reports where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @return the range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findByipNumber(String ipNumber, int start, int end)
		throws SystemException {
		return findByipNumber(ipNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the lab reports where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findByipNumber(String ipNumber, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber, start, end, orderByComparator };
		}

		List<LabReport> list = (List<LabReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (LabReport labReport : list) {
				if (!Validator.equals(ipNumber, labReport.getIpNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_LABREPORT_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(LabReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				if (!pagination) {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<LabReport>(list);
				}
				else {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first lab report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchByipNumber_First(ipNumber, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the first lab report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<LabReport> list = findByipNumber(ipNumber, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last lab report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchByipNumber_Last(ipNumber, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the last lab report in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByipNumber(ipNumber);

		if (count == 0) {
			return null;
		}

		List<LabReport> list = findByipNumber(ipNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the lab reports before and after the current lab report in the ordered set where ipNumber = &#63;.
	 *
	 * @param labId the primary key of the current lab report
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport[] findByipNumber_PrevAndNext(long labId, String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = findByPrimaryKey(labId);

		Session session = null;

		try {
			session = openSession();

			LabReport[] array = new LabReportImpl[3];

			array[0] = getByipNumber_PrevAndNext(session, labReport, ipNumber,
					orderByComparator, true);

			array[1] = labReport;

			array[2] = getByipNumber_PrevAndNext(session, labReport, ipNumber,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected LabReport getByipNumber_PrevAndNext(Session session,
		LabReport labReport, String ipNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_LABREPORT_WHERE);

		boolean bindIpNumber = false;

		if (ipNumber == null) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
		}
		else if (ipNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
		}
		else {
			bindIpNumber = true;

			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(LabReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindIpNumber) {
			qPos.add(ipNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(labReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<LabReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the lab reports where ipNumber = &#63; from the database.
	 *
	 * @param ipNumber the ip number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByipNumber(String ipNumber) throws SystemException {
		for (LabReport labReport : findByipNumber(ipNumber, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(labReport);
		}
	}

	/**
	 * Returns the number of lab reports where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the number of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByipNumber(String ipNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_IPNUMBER;

		Object[] finderArgs = new Object[] { ipNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_LABREPORT_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_1 = "labReport.ipNumber IS NULL";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_2 = "labReport.ipNumber = ?";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_3 = "(labReport.ipNumber IS NULL OR labReport.ipNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_TESTNAME = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBytestName",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME =
		new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBytestName",
			new String[] { String.class.getName() },
			LabReportModelImpl.TESTNAME_COLUMN_BITMASK |
			LabReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TESTNAME = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBytestName",
			new String[] { String.class.getName() });

	/**
	 * Returns all the lab reports where testName = &#63;.
	 *
	 * @param testName the test name
	 * @return the matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBytestName(String testName)
		throws SystemException {
		return findBytestName(testName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the lab reports where testName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param testName the test name
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @return the range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBytestName(String testName, int start, int end)
		throws SystemException {
		return findBytestName(testName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the lab reports where testName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param testName the test name
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBytestName(String testName, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME;
			finderArgs = new Object[] { testName };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_TESTNAME;
			finderArgs = new Object[] { testName, start, end, orderByComparator };
		}

		List<LabReport> list = (List<LabReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (LabReport labReport : list) {
				if (!Validator.equals(testName, labReport.getTestName())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_LABREPORT_WHERE);

			boolean bindTestName = false;

			if (testName == null) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_1);
			}
			else if (testName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_3);
			}
			else {
				bindTestName = true;

				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(LabReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTestName) {
					qPos.add(testName);
				}

				if (!pagination) {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<LabReport>(list);
				}
				else {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first lab report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findBytestName_First(String testName,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchBytestName_First(testName, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("testName=");
		msg.append(testName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the first lab report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchBytestName_First(String testName,
		OrderByComparator orderByComparator) throws SystemException {
		List<LabReport> list = findBytestName(testName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last lab report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findBytestName_Last(String testName,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchBytestName_Last(testName, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("testName=");
		msg.append(testName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the last lab report in the ordered set where testName = &#63;.
	 *
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchBytestName_Last(String testName,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBytestName(testName);

		if (count == 0) {
			return null;
		}

		List<LabReport> list = findBytestName(testName, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the lab reports before and after the current lab report in the ordered set where testName = &#63;.
	 *
	 * @param labId the primary key of the current lab report
	 * @param testName the test name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport[] findBytestName_PrevAndNext(long labId, String testName,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = findByPrimaryKey(labId);

		Session session = null;

		try {
			session = openSession();

			LabReport[] array = new LabReportImpl[3];

			array[0] = getBytestName_PrevAndNext(session, labReport, testName,
					orderByComparator, true);

			array[1] = labReport;

			array[2] = getBytestName_PrevAndNext(session, labReport, testName,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected LabReport getBytestName_PrevAndNext(Session session,
		LabReport labReport, String testName,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_LABREPORT_WHERE);

		boolean bindTestName = false;

		if (testName == null) {
			query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_1);
		}
		else if (testName.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_3);
		}
		else {
			bindTestName = true;

			query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(LabReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindTestName) {
			qPos.add(testName);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(labReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<LabReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the lab reports where testName = &#63; from the database.
	 *
	 * @param testName the test name
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBytestName(String testName) throws SystemException {
		for (LabReport labReport : findBytestName(testName, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(labReport);
		}
	}

	/**
	 * Returns the number of lab reports where testName = &#63;.
	 *
	 * @param testName the test name
	 * @return the number of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBytestName(String testName) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TESTNAME;

		Object[] finderArgs = new Object[] { testName };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_LABREPORT_WHERE);

			boolean bindTestName = false;

			if (testName == null) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_1);
			}
			else if (testName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_3);
			}
			else {
				bindTestName = true;

				query.append(_FINDER_COLUMN_TESTNAME_TESTNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTestName) {
					qPos.add(testName);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TESTNAME_TESTNAME_1 = "labReport.testName IS NULL";
	private static final String _FINDER_COLUMN_TESTNAME_TESTNAME_2 = "labReport.testName = ?";
	private static final String _FINDER_COLUMN_TESTNAME_TESTNAME_3 = "(labReport.testName IS NULL OR labReport.testName = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_STATUS = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBystatus",
			new String[] {
				Boolean.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS =
		new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, LabReportImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBystatus",
			new String[] { Boolean.class.getName() },
			LabReportModelImpl.STATUS_COLUMN_BITMASK |
			LabReportModelImpl.ORDERDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_STATUS = new FinderPath(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBystatus",
			new String[] { Boolean.class.getName() });

	/**
	 * Returns all the lab reports where status = &#63;.
	 *
	 * @param status the status
	 * @return the matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBystatus(boolean status)
		throws SystemException {
		return findBystatus(status, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the lab reports where status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @return the range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBystatus(boolean status, int start, int end)
		throws SystemException {
		return findBystatus(status, start, end, null);
	}

	/**
	 * Returns an ordered range of all the lab reports where status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findBystatus(boolean status, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS;
			finderArgs = new Object[] { status };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_STATUS;
			finderArgs = new Object[] { status, start, end, orderByComparator };
		}

		List<LabReport> list = (List<LabReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (LabReport labReport : list) {
				if ((status != labReport.getStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_LABREPORT_WHERE);

			query.append(_FINDER_COLUMN_STATUS_STATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(LabReportModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(status);

				if (!pagination) {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<LabReport>(list);
				}
				else {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first lab report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findBystatus_First(boolean status,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchBystatus_First(status, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the first lab report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchBystatus_First(boolean status,
		OrderByComparator orderByComparator) throws SystemException {
		List<LabReport> list = findBystatus(status, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last lab report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findBystatus_Last(boolean status,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchBystatus_Last(status, orderByComparator);

		if (labReport != null) {
			return labReport;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchLabReportException(msg.toString());
	}

	/**
	 * Returns the last lab report in the ordered set where status = &#63;.
	 *
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchBystatus_Last(boolean status,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBystatus(status);

		if (count == 0) {
			return null;
		}

		List<LabReport> list = findBystatus(status, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the lab reports before and after the current lab report in the ordered set where status = &#63;.
	 *
	 * @param labId the primary key of the current lab report
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport[] findBystatus_PrevAndNext(long labId, boolean status,
		OrderByComparator orderByComparator)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = findByPrimaryKey(labId);

		Session session = null;

		try {
			session = openSession();

			LabReport[] array = new LabReportImpl[3];

			array[0] = getBystatus_PrevAndNext(session, labReport, status,
					orderByComparator, true);

			array[1] = labReport;

			array[2] = getBystatus_PrevAndNext(session, labReport, status,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected LabReport getBystatus_PrevAndNext(Session session,
		LabReport labReport, boolean status,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_LABREPORT_WHERE);

		query.append(_FINDER_COLUMN_STATUS_STATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(LabReportModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(status);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(labReport);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<LabReport> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the lab reports where status = &#63; from the database.
	 *
	 * @param status the status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBystatus(boolean status) throws SystemException {
		for (LabReport labReport : findBystatus(status, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(labReport);
		}
	}

	/**
	 * Returns the number of lab reports where status = &#63;.
	 *
	 * @param status the status
	 * @return the number of matching lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBystatus(boolean status) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_STATUS;

		Object[] finderArgs = new Object[] { status };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_LABREPORT_WHERE);

			query.append(_FINDER_COLUMN_STATUS_STATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(status);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATUS_STATUS_2 = "labReport.status = ?";

	public LabReportPersistenceImpl() {
		setModelClass(LabReport.class);
	}

	/**
	 * Caches the lab report in the entity cache if it is enabled.
	 *
	 * @param labReport the lab report
	 */
	@Override
	public void cacheResult(LabReport labReport) {
		EntityCacheUtil.putResult(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportImpl.class, labReport.getPrimaryKey(), labReport);

		labReport.resetOriginalValues();
	}

	/**
	 * Caches the lab reports in the entity cache if it is enabled.
	 *
	 * @param labReports the lab reports
	 */
	@Override
	public void cacheResult(List<LabReport> labReports) {
		for (LabReport labReport : labReports) {
			if (EntityCacheUtil.getResult(
						LabReportModelImpl.ENTITY_CACHE_ENABLED,
						LabReportImpl.class, labReport.getPrimaryKey()) == null) {
				cacheResult(labReport);
			}
			else {
				labReport.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all lab reports.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(LabReportImpl.class.getName());
		}

		EntityCacheUtil.clearCache(LabReportImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the lab report.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(LabReport labReport) {
		EntityCacheUtil.removeResult(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportImpl.class, labReport.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<LabReport> labReports) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (LabReport labReport : labReports) {
			EntityCacheUtil.removeResult(LabReportModelImpl.ENTITY_CACHE_ENABLED,
				LabReportImpl.class, labReport.getPrimaryKey());
		}
	}

	/**
	 * Creates a new lab report with the primary key. Does not add the lab report to the database.
	 *
	 * @param labId the primary key for the new lab report
	 * @return the new lab report
	 */
	@Override
	public LabReport create(long labId) {
		LabReport labReport = new LabReportImpl();

		labReport.setNew(true);
		labReport.setPrimaryKey(labId);

		return labReport;
	}

	/**
	 * Removes the lab report with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param labId the primary key of the lab report
	 * @return the lab report that was removed
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport remove(long labId)
		throws NoSuchLabReportException, SystemException {
		return remove((Serializable)labId);
	}

	/**
	 * Removes the lab report with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the lab report
	 * @return the lab report that was removed
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport remove(Serializable primaryKey)
		throws NoSuchLabReportException, SystemException {
		Session session = null;

		try {
			session = openSession();

			LabReport labReport = (LabReport)session.get(LabReportImpl.class,
					primaryKey);

			if (labReport == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchLabReportException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(labReport);
		}
		catch (NoSuchLabReportException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected LabReport removeImpl(LabReport labReport)
		throws SystemException {
		labReport = toUnwrappedModel(labReport);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(labReport)) {
				labReport = (LabReport)session.get(LabReportImpl.class,
						labReport.getPrimaryKeyObj());
			}

			if (labReport != null) {
				session.delete(labReport);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (labReport != null) {
			clearCache(labReport);
		}

		return labReport;
	}

	@Override
	public LabReport updateImpl(com.napier.portal.db.model.LabReport labReport)
		throws SystemException {
		labReport = toUnwrappedModel(labReport);

		boolean isNew = labReport.isNew();

		LabReportModelImpl labReportModelImpl = (LabReportModelImpl)labReport;

		Session session = null;

		try {
			session = openSession();

			if (labReport.isNew()) {
				session.save(labReport);

				labReport.setNew(false);
			}
			else {
				session.merge(labReport);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !LabReportModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((labReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						labReportModelImpl.getOriginalMrNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);

				args = new Object[] { labReportModelImpl.getMrNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);
			}

			if ((labReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						labReportModelImpl.getOriginalIpNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);

				args = new Object[] { labReportModelImpl.getIpNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);
			}

			if ((labReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						labReportModelImpl.getOriginalTestName()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TESTNAME, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME,
					args);

				args = new Object[] { labReportModelImpl.getTestName() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TESTNAME, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TESTNAME,
					args);
			}

			if ((labReportModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						labReportModelImpl.getOriginalStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATUS, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS,
					args);

				args = new Object[] { labReportModelImpl.getStatus() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATUS, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUS,
					args);
			}
		}

		EntityCacheUtil.putResult(LabReportModelImpl.ENTITY_CACHE_ENABLED,
			LabReportImpl.class, labReport.getPrimaryKey(), labReport);

		return labReport;
	}

	protected LabReport toUnwrappedModel(LabReport labReport) {
		if (labReport instanceof LabReportImpl) {
			return labReport;
		}

		LabReportImpl labReportImpl = new LabReportImpl();

		labReportImpl.setNew(labReport.isNew());
		labReportImpl.setPrimaryKey(labReport.getPrimaryKey());

		labReportImpl.setLabId(labReport.getLabId());
		labReportImpl.setMrNumber(labReport.getMrNumber());
		labReportImpl.setOrderNumber(labReport.getOrderNumber());
		labReportImpl.setOrderDate(labReport.getOrderDate());
		labReportImpl.setReportedOn(labReport.getReportedOn());
		labReportImpl.setTestName(labReport.getTestName());
		labReportImpl.setIpNumber(labReport.getIpNumber());
		labReportImpl.setDocPath(labReport.getDocPath());
		labReportImpl.setDepartmentName(labReport.getDepartmentName());
		labReportImpl.setStatus(labReport.isStatus());

		return labReportImpl;
	}

	/**
	 * Returns the lab report with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the lab report
	 * @return the lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findByPrimaryKey(Serializable primaryKey)
		throws NoSuchLabReportException, SystemException {
		LabReport labReport = fetchByPrimaryKey(primaryKey);

		if (labReport == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchLabReportException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return labReport;
	}

	/**
	 * Returns the lab report with the primary key or throws a {@link com.napier.portal.db.NoSuchLabReportException} if it could not be found.
	 *
	 * @param labId the primary key of the lab report
	 * @return the lab report
	 * @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport findByPrimaryKey(long labId)
		throws NoSuchLabReportException, SystemException {
		return findByPrimaryKey((Serializable)labId);
	}

	/**
	 * Returns the lab report with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the lab report
	 * @return the lab report, or <code>null</code> if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		LabReport labReport = (LabReport)EntityCacheUtil.getResult(LabReportModelImpl.ENTITY_CACHE_ENABLED,
				LabReportImpl.class, primaryKey);

		if (labReport == _nullLabReport) {
			return null;
		}

		if (labReport == null) {
			Session session = null;

			try {
				session = openSession();

				labReport = (LabReport)session.get(LabReportImpl.class,
						primaryKey);

				if (labReport != null) {
					cacheResult(labReport);
				}
				else {
					EntityCacheUtil.putResult(LabReportModelImpl.ENTITY_CACHE_ENABLED,
						LabReportImpl.class, primaryKey, _nullLabReport);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(LabReportModelImpl.ENTITY_CACHE_ENABLED,
					LabReportImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return labReport;
	}

	/**
	 * Returns the lab report with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param labId the primary key of the lab report
	 * @return the lab report, or <code>null</code> if a lab report with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public LabReport fetchByPrimaryKey(long labId) throws SystemException {
		return fetchByPrimaryKey((Serializable)labId);
	}

	/**
	 * Returns all the lab reports.
	 *
	 * @return the lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the lab reports.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @return the range of lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the lab reports.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of lab reports
	 * @param end the upper bound of the range of lab reports (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<LabReport> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<LabReport> list = (List<LabReport>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_LABREPORT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_LABREPORT;

				if (pagination) {
					sql = sql.concat(LabReportModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<LabReport>(list);
				}
				else {
					list = (List<LabReport>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the lab reports from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (LabReport labReport : findAll()) {
			remove(labReport);
		}
	}

	/**
	 * Returns the number of lab reports.
	 *
	 * @return the number of lab reports
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_LABREPORT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the lab report persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.LabReport")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<LabReport>> listenersList = new ArrayList<ModelListener<LabReport>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<LabReport>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(LabReportImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_LABREPORT = "SELECT labReport FROM LabReport labReport";
	private static final String _SQL_SELECT_LABREPORT_WHERE = "SELECT labReport FROM LabReport labReport WHERE ";
	private static final String _SQL_COUNT_LABREPORT = "SELECT COUNT(labReport) FROM LabReport labReport";
	private static final String _SQL_COUNT_LABREPORT_WHERE = "SELECT COUNT(labReport) FROM LabReport labReport WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "labReport.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No LabReport exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No LabReport exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(LabReportPersistenceImpl.class);
	private static LabReport _nullLabReport = new LabReportImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<LabReport> toCacheModel() {
				return _nullLabReportCacheModel;
			}
		};

	private static CacheModel<LabReport> _nullLabReportCacheModel = new CacheModel<LabReport>() {
			@Override
			public LabReport toEntityModel() {
				return _nullLabReport;
			}
		};
}