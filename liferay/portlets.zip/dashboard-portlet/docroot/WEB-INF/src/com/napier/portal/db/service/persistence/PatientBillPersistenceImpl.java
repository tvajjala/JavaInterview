/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchPatientBillException;
import com.napier.portal.db.model.PatientBill;
import com.napier.portal.db.model.impl.PatientBillImpl;
import com.napier.portal.db.model.impl.PatientBillModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the patient bill service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PatientBillPersistence
 * @see PatientBillUtil
 * @generated
 */
public class PatientBillPersistenceImpl extends BasePersistenceImpl<PatientBill>
	implements PatientBillPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link PatientBillUtil} to access the patient bill persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = PatientBillImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBymrNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER =
		new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBymrNumber",
			new String[] { String.class.getName() },
			PatientBillModelImpl.MRNUMBER_COLUMN_BITMASK |
			PatientBillModelImpl.ADMISSIONDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MRNUMBER = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymrNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the patient bills where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBymrNumber(String mrNumber)
		throws SystemException {
		return findBymrNumber(mrNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the patient bills where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @return the range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBymrNumber(String mrNumber, int start, int end)
		throws SystemException {
		return findBymrNumber(mrNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the patient bills where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBymrNumber(String mrNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber, start, end, orderByComparator };
		}

		List<PatientBill> list = (List<PatientBill>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PatientBill patientBill : list) {
				if (!Validator.equals(mrNumber, patientBill.getMrNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PATIENTBILL_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PatientBillModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				if (!pagination) {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PatientBill>(list);
				}
				else {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first patient bill in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBymrNumber_First(mrNumber,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the first patient bill in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<PatientBill> list = findBymrNumber(mrNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last patient bill in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBymrNumber_Last(mrNumber,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the last patient bill in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBymrNumber(mrNumber);

		if (count == 0) {
			return null;
		}

		List<PatientBill> list = findBymrNumber(mrNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the patient bills before and after the current patient bill in the ordered set where mrNumber = &#63;.
	 *
	 * @param patientBillId the primary key of the current patient bill
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill[] findBymrNumber_PrevAndNext(long patientBillId,
		String mrNumber, OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = findByPrimaryKey(patientBillId);

		Session session = null;

		try {
			session = openSession();

			PatientBill[] array = new PatientBillImpl[3];

			array[0] = getBymrNumber_PrevAndNext(session, patientBill,
					mrNumber, orderByComparator, true);

			array[1] = patientBill;

			array[2] = getBymrNumber_PrevAndNext(session, patientBill,
					mrNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PatientBill getBymrNumber_PrevAndNext(Session session,
		PatientBill patientBill, String mrNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PATIENTBILL_WHERE);

		boolean bindMrNumber = false;

		if (mrNumber == null) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
		}
		else if (mrNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
		}
		else {
			bindMrNumber = true;

			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PatientBillModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMrNumber) {
			qPos.add(mrNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(patientBill);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PatientBill> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the patient bills where mrNumber = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBymrNumber(String mrNumber) throws SystemException {
		for (PatientBill patientBill : findBymrNumber(mrNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(patientBill);
		}
	}

	/**
	 * Returns the number of patient bills where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the number of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymrNumber(String mrNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MRNUMBER;

		Object[] finderArgs = new Object[] { mrNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PATIENTBILL_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_1 = "patientBill.mrNumber IS NULL";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_2 = "patientBill.mrNumber = ?";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_3 = "(patientBill.mrNumber IS NULL OR patientBill.mrNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByipNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER =
		new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByipNumber",
			new String[] { String.class.getName() },
			PatientBillModelImpl.IPNUMBER_COLUMN_BITMASK |
			PatientBillModelImpl.ADMISSIONDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_IPNUMBER = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByipNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the patient bills where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findByipNumber(String ipNumber)
		throws SystemException {
		return findByipNumber(ipNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the patient bills where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @return the range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findByipNumber(String ipNumber, int start, int end)
		throws SystemException {
		return findByipNumber(ipNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the patient bills where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findByipNumber(String ipNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber, start, end, orderByComparator };
		}

		List<PatientBill> list = (List<PatientBill>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PatientBill patientBill : list) {
				if (!Validator.equals(ipNumber, patientBill.getIpNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PATIENTBILL_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PatientBillModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				if (!pagination) {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PatientBill>(list);
				}
				else {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first patient bill in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchByipNumber_First(ipNumber,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the first patient bill in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<PatientBill> list = findByipNumber(ipNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last patient bill in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchByipNumber_Last(ipNumber,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the last patient bill in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByipNumber(ipNumber);

		if (count == 0) {
			return null;
		}

		List<PatientBill> list = findByipNumber(ipNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the patient bills before and after the current patient bill in the ordered set where ipNumber = &#63;.
	 *
	 * @param patientBillId the primary key of the current patient bill
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill[] findByipNumber_PrevAndNext(long patientBillId,
		String ipNumber, OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = findByPrimaryKey(patientBillId);

		Session session = null;

		try {
			session = openSession();

			PatientBill[] array = new PatientBillImpl[3];

			array[0] = getByipNumber_PrevAndNext(session, patientBill,
					ipNumber, orderByComparator, true);

			array[1] = patientBill;

			array[2] = getByipNumber_PrevAndNext(session, patientBill,
					ipNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PatientBill getByipNumber_PrevAndNext(Session session,
		PatientBill patientBill, String ipNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PATIENTBILL_WHERE);

		boolean bindIpNumber = false;

		if (ipNumber == null) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
		}
		else if (ipNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
		}
		else {
			bindIpNumber = true;

			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PatientBillModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindIpNumber) {
			qPos.add(ipNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(patientBill);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PatientBill> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the patient bills where ipNumber = &#63; from the database.
	 *
	 * @param ipNumber the ip number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByipNumber(String ipNumber) throws SystemException {
		for (PatientBill patientBill : findByipNumber(ipNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(patientBill);
		}
	}

	/**
	 * Returns the number of patient bills where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the number of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByipNumber(String ipNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_IPNUMBER;

		Object[] finderArgs = new Object[] { ipNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PATIENTBILL_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_1 = "patientBill.ipNumber IS NULL";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_2 = "patientBill.ipNumber = ?";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_3 = "(patientBill.ipNumber IS NULL OR patientBill.ipNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANY = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycompany",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANY =
		new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycompany",
			new String[] { String.class.getName() },
			PatientBillModelImpl.COMPANY_COLUMN_BITMASK |
			PatientBillModelImpl.ADMISSIONDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_COMPANY = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycompany",
			new String[] { String.class.getName() });

	/**
	 * Returns all the patient bills where company = &#63;.
	 *
	 * @param company the company
	 * @return the matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBycompany(String company)
		throws SystemException {
		return findBycompany(company, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the patient bills where company = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param company the company
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @return the range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBycompany(String company, int start, int end)
		throws SystemException {
		return findBycompany(company, start, end, null);
	}

	/**
	 * Returns an ordered range of all the patient bills where company = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param company the company
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBycompany(String company, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANY;
			finderArgs = new Object[] { company };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANY;
			finderArgs = new Object[] { company, start, end, orderByComparator };
		}

		List<PatientBill> list = (List<PatientBill>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PatientBill patientBill : list) {
				if (!Validator.equals(company, patientBill.getCompany())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PATIENTBILL_WHERE);

			boolean bindCompany = false;

			if (company == null) {
				query.append(_FINDER_COLUMN_COMPANY_COMPANY_1);
			}
			else if (company.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANY_COMPANY_3);
			}
			else {
				bindCompany = true;

				query.append(_FINDER_COLUMN_COMPANY_COMPANY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PatientBillModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCompany) {
					qPos.add(company);
				}

				if (!pagination) {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PatientBill>(list);
				}
				else {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first patient bill in the ordered set where company = &#63;.
	 *
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBycompany_First(String company,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBycompany_First(company,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("company=");
		msg.append(company);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the first patient bill in the ordered set where company = &#63;.
	 *
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBycompany_First(String company,
		OrderByComparator orderByComparator) throws SystemException {
		List<PatientBill> list = findBycompany(company, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last patient bill in the ordered set where company = &#63;.
	 *
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBycompany_Last(String company,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBycompany_Last(company, orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("company=");
		msg.append(company);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the last patient bill in the ordered set where company = &#63;.
	 *
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBycompany_Last(String company,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBycompany(company);

		if (count == 0) {
			return null;
		}

		List<PatientBill> list = findBycompany(company, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the patient bills before and after the current patient bill in the ordered set where company = &#63;.
	 *
	 * @param patientBillId the primary key of the current patient bill
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill[] findBycompany_PrevAndNext(long patientBillId,
		String company, OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = findByPrimaryKey(patientBillId);

		Session session = null;

		try {
			session = openSession();

			PatientBill[] array = new PatientBillImpl[3];

			array[0] = getBycompany_PrevAndNext(session, patientBill, company,
					orderByComparator, true);

			array[1] = patientBill;

			array[2] = getBycompany_PrevAndNext(session, patientBill, company,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PatientBill getBycompany_PrevAndNext(Session session,
		PatientBill patientBill, String company,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PATIENTBILL_WHERE);

		boolean bindCompany = false;

		if (company == null) {
			query.append(_FINDER_COLUMN_COMPANY_COMPANY_1);
		}
		else if (company.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_COMPANY_COMPANY_3);
		}
		else {
			bindCompany = true;

			query.append(_FINDER_COLUMN_COMPANY_COMPANY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PatientBillModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCompany) {
			qPos.add(company);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(patientBill);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PatientBill> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the patient bills where company = &#63; from the database.
	 *
	 * @param company the company
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBycompany(String company) throws SystemException {
		for (PatientBill patientBill : findBycompany(company,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(patientBill);
		}
	}

	/**
	 * Returns the number of patient bills where company = &#63;.
	 *
	 * @param company the company
	 * @return the number of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBycompany(String company) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_COMPANY;

		Object[] finderArgs = new Object[] { company };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PATIENTBILL_WHERE);

			boolean bindCompany = false;

			if (company == null) {
				query.append(_FINDER_COLUMN_COMPANY_COMPANY_1);
			}
			else if (company.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANY_COMPANY_3);
			}
			else {
				bindCompany = true;

				query.append(_FINDER_COLUMN_COMPANY_COMPANY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCompany) {
					qPos.add(company);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANY_COMPANY_1 = "patientBill.company IS NULL";
	private static final String _FINDER_COLUMN_COMPANY_COMPANY_2 = "patientBill.company = ?";
	private static final String _FINDER_COLUMN_COMPANY_COMPANY_3 = "(patientBill.company IS NULL OR patientBill.company = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_SPONSER = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBysponser",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SPONSER =
		new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBysponser",
			new String[] { String.class.getName() },
			PatientBillModelImpl.SPONSER_COLUMN_BITMASK |
			PatientBillModelImpl.ADMISSIONDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_SPONSER = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBysponser",
			new String[] { String.class.getName() });

	/**
	 * Returns all the patient bills where sponser = &#63;.
	 *
	 * @param sponser the sponser
	 * @return the matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBysponser(String sponser)
		throws SystemException {
		return findBysponser(sponser, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the patient bills where sponser = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sponser the sponser
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @return the range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBysponser(String sponser, int start, int end)
		throws SystemException {
		return findBysponser(sponser, start, end, null);
	}

	/**
	 * Returns an ordered range of all the patient bills where sponser = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sponser the sponser
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBysponser(String sponser, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SPONSER;
			finderArgs = new Object[] { sponser };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_SPONSER;
			finderArgs = new Object[] { sponser, start, end, orderByComparator };
		}

		List<PatientBill> list = (List<PatientBill>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PatientBill patientBill : list) {
				if (!Validator.equals(sponser, patientBill.getSponser())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PATIENTBILL_WHERE);

			boolean bindSponser = false;

			if (sponser == null) {
				query.append(_FINDER_COLUMN_SPONSER_SPONSER_1);
			}
			else if (sponser.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_SPONSER_SPONSER_3);
			}
			else {
				bindSponser = true;

				query.append(_FINDER_COLUMN_SPONSER_SPONSER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PatientBillModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSponser) {
					qPos.add(sponser);
				}

				if (!pagination) {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PatientBill>(list);
				}
				else {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first patient bill in the ordered set where sponser = &#63;.
	 *
	 * @param sponser the sponser
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBysponser_First(String sponser,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBysponser_First(sponser,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("sponser=");
		msg.append(sponser);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the first patient bill in the ordered set where sponser = &#63;.
	 *
	 * @param sponser the sponser
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBysponser_First(String sponser,
		OrderByComparator orderByComparator) throws SystemException {
		List<PatientBill> list = findBysponser(sponser, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last patient bill in the ordered set where sponser = &#63;.
	 *
	 * @param sponser the sponser
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBysponser_Last(String sponser,
		OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBysponser_Last(sponser, orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("sponser=");
		msg.append(sponser);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the last patient bill in the ordered set where sponser = &#63;.
	 *
	 * @param sponser the sponser
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBysponser_Last(String sponser,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBysponser(sponser);

		if (count == 0) {
			return null;
		}

		List<PatientBill> list = findBysponser(sponser, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the patient bills before and after the current patient bill in the ordered set where sponser = &#63;.
	 *
	 * @param patientBillId the primary key of the current patient bill
	 * @param sponser the sponser
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill[] findBysponser_PrevAndNext(long patientBillId,
		String sponser, OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = findByPrimaryKey(patientBillId);

		Session session = null;

		try {
			session = openSession();

			PatientBill[] array = new PatientBillImpl[3];

			array[0] = getBysponser_PrevAndNext(session, patientBill, sponser,
					orderByComparator, true);

			array[1] = patientBill;

			array[2] = getBysponser_PrevAndNext(session, patientBill, sponser,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PatientBill getBysponser_PrevAndNext(Session session,
		PatientBill patientBill, String sponser,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PATIENTBILL_WHERE);

		boolean bindSponser = false;

		if (sponser == null) {
			query.append(_FINDER_COLUMN_SPONSER_SPONSER_1);
		}
		else if (sponser.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_SPONSER_SPONSER_3);
		}
		else {
			bindSponser = true;

			query.append(_FINDER_COLUMN_SPONSER_SPONSER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PatientBillModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindSponser) {
			qPos.add(sponser);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(patientBill);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PatientBill> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the patient bills where sponser = &#63; from the database.
	 *
	 * @param sponser the sponser
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBysponser(String sponser) throws SystemException {
		for (PatientBill patientBill : findBysponser(sponser,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(patientBill);
		}
	}

	/**
	 * Returns the number of patient bills where sponser = &#63;.
	 *
	 * @param sponser the sponser
	 * @return the number of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBysponser(String sponser) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_SPONSER;

		Object[] finderArgs = new Object[] { sponser };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PATIENTBILL_WHERE);

			boolean bindSponser = false;

			if (sponser == null) {
				query.append(_FINDER_COLUMN_SPONSER_SPONSER_1);
			}
			else if (sponser.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_SPONSER_SPONSER_3);
			}
			else {
				bindSponser = true;

				query.append(_FINDER_COLUMN_SPONSER_SPONSER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSponser) {
					qPos.add(sponser);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SPONSER_SPONSER_1 = "patientBill.sponser IS NULL";
	private static final String _FINDER_COLUMN_SPONSER_SPONSER_2 = "patientBill.sponser = ?";
	private static final String _FINDER_COLUMN_SPONSER_SPONSER_3 = "(patientBill.sponser IS NULL OR patientBill.sponser = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANYSPONSER =
		new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycompanySponser",
			new String[] {
				String.class.getName(), String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYSPONSER =
		new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, PatientBillImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycompanySponser",
			new String[] { String.class.getName(), String.class.getName() },
			PatientBillModelImpl.SPONSER_COLUMN_BITMASK |
			PatientBillModelImpl.COMPANY_COLUMN_BITMASK |
			PatientBillModelImpl.ADMISSIONDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_COMPANYSPONSER = new FinderPath(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycompanySponser",
			new String[] { String.class.getName(), String.class.getName() });

	/**
	 * Returns all the patient bills where sponser = &#63; and company = &#63;.
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @return the matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBycompanySponser(String sponser, String company)
		throws SystemException {
		return findBycompanySponser(sponser, company, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the patient bills where sponser = &#63; and company = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @return the range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBycompanySponser(String sponser,
		String company, int start, int end) throws SystemException {
		return findBycompanySponser(sponser, company, start, end, null);
	}

	/**
	 * Returns an ordered range of all the patient bills where sponser = &#63; and company = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findBycompanySponser(String sponser,
		String company, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYSPONSER;
			finderArgs = new Object[] { sponser, company };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANYSPONSER;
			finderArgs = new Object[] {
					sponser, company,
					
					start, end, orderByComparator
				};
		}

		List<PatientBill> list = (List<PatientBill>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PatientBill patientBill : list) {
				if (!Validator.equals(sponser, patientBill.getSponser()) ||
						!Validator.equals(company, patientBill.getCompany())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_PATIENTBILL_WHERE);

			boolean bindSponser = false;

			if (sponser == null) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_1);
			}
			else if (sponser.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_3);
			}
			else {
				bindSponser = true;

				query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_2);
			}

			boolean bindCompany = false;

			if (company == null) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_1);
			}
			else if (company.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_3);
			}
			else {
				bindCompany = true;

				query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PatientBillModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSponser) {
					qPos.add(sponser);
				}

				if (bindCompany) {
					qPos.add(company);
				}

				if (!pagination) {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PatientBill>(list);
				}
				else {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first patient bill in the ordered set where sponser = &#63; and company = &#63;.
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBycompanySponser_First(String sponser,
		String company, OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBycompanySponser_First(sponser, company,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("sponser=");
		msg.append(sponser);

		msg.append(", company=");
		msg.append(company);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the first patient bill in the ordered set where sponser = &#63; and company = &#63;.
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBycompanySponser_First(String sponser,
		String company, OrderByComparator orderByComparator)
		throws SystemException {
		List<PatientBill> list = findBycompanySponser(sponser, company, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last patient bill in the ordered set where sponser = &#63; and company = &#63;.
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findBycompanySponser_Last(String sponser,
		String company, OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchBycompanySponser_Last(sponser, company,
				orderByComparator);

		if (patientBill != null) {
			return patientBill;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("sponser=");
		msg.append(sponser);

		msg.append(", company=");
		msg.append(company);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPatientBillException(msg.toString());
	}

	/**
	 * Returns the last patient bill in the ordered set where sponser = &#63; and company = &#63;.
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchBycompanySponser_Last(String sponser,
		String company, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countBycompanySponser(sponser, company);

		if (count == 0) {
			return null;
		}

		List<PatientBill> list = findBycompanySponser(sponser, company,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the patient bills before and after the current patient bill in the ordered set where sponser = &#63; and company = &#63;.
	 *
	 * @param patientBillId the primary key of the current patient bill
	 * @param sponser the sponser
	 * @param company the company
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill[] findBycompanySponser_PrevAndNext(long patientBillId,
		String sponser, String company, OrderByComparator orderByComparator)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = findByPrimaryKey(patientBillId);

		Session session = null;

		try {
			session = openSession();

			PatientBill[] array = new PatientBillImpl[3];

			array[0] = getBycompanySponser_PrevAndNext(session, patientBill,
					sponser, company, orderByComparator, true);

			array[1] = patientBill;

			array[2] = getBycompanySponser_PrevAndNext(session, patientBill,
					sponser, company, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PatientBill getBycompanySponser_PrevAndNext(Session session,
		PatientBill patientBill, String sponser, String company,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PATIENTBILL_WHERE);

		boolean bindSponser = false;

		if (sponser == null) {
			query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_1);
		}
		else if (sponser.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_3);
		}
		else {
			bindSponser = true;

			query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_2);
		}

		boolean bindCompany = false;

		if (company == null) {
			query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_1);
		}
		else if (company.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_3);
		}
		else {
			bindCompany = true;

			query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PatientBillModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindSponser) {
			qPos.add(sponser);
		}

		if (bindCompany) {
			qPos.add(company);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(patientBill);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PatientBill> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the patient bills where sponser = &#63; and company = &#63; from the database.
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBycompanySponser(String sponser, String company)
		throws SystemException {
		for (PatientBill patientBill : findBycompanySponser(sponser, company,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(patientBill);
		}
	}

	/**
	 * Returns the number of patient bills where sponser = &#63; and company = &#63;.
	 *
	 * @param sponser the sponser
	 * @param company the company
	 * @return the number of matching patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBycompanySponser(String sponser, String company)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_COMPANYSPONSER;

		Object[] finderArgs = new Object[] { sponser, company };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_PATIENTBILL_WHERE);

			boolean bindSponser = false;

			if (sponser == null) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_1);
			}
			else if (sponser.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_3);
			}
			else {
				bindSponser = true;

				query.append(_FINDER_COLUMN_COMPANYSPONSER_SPONSER_2);
			}

			boolean bindCompany = false;

			if (company == null) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_1);
			}
			else if (company.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_3);
			}
			else {
				bindCompany = true;

				query.append(_FINDER_COLUMN_COMPANYSPONSER_COMPANY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSponser) {
					qPos.add(sponser);
				}

				if (bindCompany) {
					qPos.add(company);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYSPONSER_SPONSER_1 = "patientBill.sponser IS NULL AND ";
	private static final String _FINDER_COLUMN_COMPANYSPONSER_SPONSER_2 = "patientBill.sponser = ? AND ";
	private static final String _FINDER_COLUMN_COMPANYSPONSER_SPONSER_3 = "(patientBill.sponser IS NULL OR patientBill.sponser = '') AND ";
	private static final String _FINDER_COLUMN_COMPANYSPONSER_COMPANY_1 = "patientBill.company IS NULL";
	private static final String _FINDER_COLUMN_COMPANYSPONSER_COMPANY_2 = "patientBill.company = ?";
	private static final String _FINDER_COLUMN_COMPANYSPONSER_COMPANY_3 = "(patientBill.company IS NULL OR patientBill.company = '')";

	public PatientBillPersistenceImpl() {
		setModelClass(PatientBill.class);
	}

	/**
	 * Caches the patient bill in the entity cache if it is enabled.
	 *
	 * @param patientBill the patient bill
	 */
	@Override
	public void cacheResult(PatientBill patientBill) {
		EntityCacheUtil.putResult(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillImpl.class, patientBill.getPrimaryKey(), patientBill);

		patientBill.resetOriginalValues();
	}

	/**
	 * Caches the patient bills in the entity cache if it is enabled.
	 *
	 * @param patientBills the patient bills
	 */
	@Override
	public void cacheResult(List<PatientBill> patientBills) {
		for (PatientBill patientBill : patientBills) {
			if (EntityCacheUtil.getResult(
						PatientBillModelImpl.ENTITY_CACHE_ENABLED,
						PatientBillImpl.class, patientBill.getPrimaryKey()) == null) {
				cacheResult(patientBill);
			}
			else {
				patientBill.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all patient bills.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(PatientBillImpl.class.getName());
		}

		EntityCacheUtil.clearCache(PatientBillImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the patient bill.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(PatientBill patientBill) {
		EntityCacheUtil.removeResult(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillImpl.class, patientBill.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<PatientBill> patientBills) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (PatientBill patientBill : patientBills) {
			EntityCacheUtil.removeResult(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
				PatientBillImpl.class, patientBill.getPrimaryKey());
		}
	}

	/**
	 * Creates a new patient bill with the primary key. Does not add the patient bill to the database.
	 *
	 * @param patientBillId the primary key for the new patient bill
	 * @return the new patient bill
	 */
	@Override
	public PatientBill create(long patientBillId) {
		PatientBill patientBill = new PatientBillImpl();

		patientBill.setNew(true);
		patientBill.setPrimaryKey(patientBillId);

		return patientBill;
	}

	/**
	 * Removes the patient bill with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param patientBillId the primary key of the patient bill
	 * @return the patient bill that was removed
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill remove(long patientBillId)
		throws NoSuchPatientBillException, SystemException {
		return remove((Serializable)patientBillId);
	}

	/**
	 * Removes the patient bill with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the patient bill
	 * @return the patient bill that was removed
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill remove(Serializable primaryKey)
		throws NoSuchPatientBillException, SystemException {
		Session session = null;

		try {
			session = openSession();

			PatientBill patientBill = (PatientBill)session.get(PatientBillImpl.class,
					primaryKey);

			if (patientBill == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchPatientBillException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(patientBill);
		}
		catch (NoSuchPatientBillException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected PatientBill removeImpl(PatientBill patientBill)
		throws SystemException {
		patientBill = toUnwrappedModel(patientBill);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(patientBill)) {
				patientBill = (PatientBill)session.get(PatientBillImpl.class,
						patientBill.getPrimaryKeyObj());
			}

			if (patientBill != null) {
				session.delete(patientBill);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (patientBill != null) {
			clearCache(patientBill);
		}

		return patientBill;
	}

	@Override
	public PatientBill updateImpl(
		com.napier.portal.db.model.PatientBill patientBill)
		throws SystemException {
		patientBill = toUnwrappedModel(patientBill);

		boolean isNew = patientBill.isNew();

		PatientBillModelImpl patientBillModelImpl = (PatientBillModelImpl)patientBill;

		Session session = null;

		try {
			session = openSession();

			if (patientBill.isNew()) {
				session.save(patientBill);

				patientBill.setNew(false);
			}
			else {
				session.merge(patientBill);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !PatientBillModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((patientBillModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						patientBillModelImpl.getOriginalMrNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);

				args = new Object[] { patientBillModelImpl.getMrNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);
			}

			if ((patientBillModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						patientBillModelImpl.getOriginalIpNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);

				args = new Object[] { patientBillModelImpl.getIpNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);
			}

			if ((patientBillModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANY.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						patientBillModelImpl.getOriginalCompany()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANY, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANY,
					args);

				args = new Object[] { patientBillModelImpl.getCompany() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANY, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANY,
					args);
			}

			if ((patientBillModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SPONSER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						patientBillModelImpl.getOriginalSponser()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_SPONSER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SPONSER,
					args);

				args = new Object[] { patientBillModelImpl.getSponser() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_SPONSER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SPONSER,
					args);
			}

			if ((patientBillModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYSPONSER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						patientBillModelImpl.getOriginalSponser(),
						patientBillModelImpl.getOriginalCompany()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYSPONSER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYSPONSER,
					args);

				args = new Object[] {
						patientBillModelImpl.getSponser(),
						patientBillModelImpl.getCompany()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYSPONSER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYSPONSER,
					args);
			}
		}

		EntityCacheUtil.putResult(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
			PatientBillImpl.class, patientBill.getPrimaryKey(), patientBill);

		return patientBill;
	}

	protected PatientBill toUnwrappedModel(PatientBill patientBill) {
		if (patientBill instanceof PatientBillImpl) {
			return patientBill;
		}

		PatientBillImpl patientBillImpl = new PatientBillImpl();

		patientBillImpl.setNew(patientBill.isNew());
		patientBillImpl.setPrimaryKey(patientBill.getPrimaryKey());

		patientBillImpl.setPatientBillId(patientBill.getPatientBillId());
		patientBillImpl.setMrNumber(patientBill.getMrNumber());
		patientBillImpl.setIpNumber(patientBill.getIpNumber());
		patientBillImpl.setBillNumber(patientBill.getBillNumber());
		patientBillImpl.setCompany(patientBill.getCompany());
		patientBillImpl.setSponser(patientBill.getSponser());
		patientBillImpl.setPlanName(patientBill.getPlanName());
		patientBillImpl.setPlanExpiry(patientBill.getPlanExpiry());
		patientBillImpl.setAdmissionDate(patientBill.getAdmissionDate());
		patientBillImpl.setIsBillgenerated(patientBill.isIsBillgenerated());
		patientBillImpl.setIsBalanceAmount(patientBill.isIsBalanceAmount());
		patientBillImpl.setBillAmount(patientBill.getBillAmount());
		patientBillImpl.setPaidAmount(patientBill.getPaidAmount());

		return patientBillImpl;
	}

	/**
	 * Returns the patient bill with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the patient bill
	 * @return the patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findByPrimaryKey(Serializable primaryKey)
		throws NoSuchPatientBillException, SystemException {
		PatientBill patientBill = fetchByPrimaryKey(primaryKey);

		if (patientBill == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchPatientBillException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return patientBill;
	}

	/**
	 * Returns the patient bill with the primary key or throws a {@link com.napier.portal.db.NoSuchPatientBillException} if it could not be found.
	 *
	 * @param patientBillId the primary key of the patient bill
	 * @return the patient bill
	 * @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill findByPrimaryKey(long patientBillId)
		throws NoSuchPatientBillException, SystemException {
		return findByPrimaryKey((Serializable)patientBillId);
	}

	/**
	 * Returns the patient bill with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the patient bill
	 * @return the patient bill, or <code>null</code> if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		PatientBill patientBill = (PatientBill)EntityCacheUtil.getResult(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
				PatientBillImpl.class, primaryKey);

		if (patientBill == _nullPatientBill) {
			return null;
		}

		if (patientBill == null) {
			Session session = null;

			try {
				session = openSession();

				patientBill = (PatientBill)session.get(PatientBillImpl.class,
						primaryKey);

				if (patientBill != null) {
					cacheResult(patientBill);
				}
				else {
					EntityCacheUtil.putResult(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
						PatientBillImpl.class, primaryKey, _nullPatientBill);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(PatientBillModelImpl.ENTITY_CACHE_ENABLED,
					PatientBillImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return patientBill;
	}

	/**
	 * Returns the patient bill with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param patientBillId the primary key of the patient bill
	 * @return the patient bill, or <code>null</code> if a patient bill with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PatientBill fetchByPrimaryKey(long patientBillId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)patientBillId);
	}

	/**
	 * Returns all the patient bills.
	 *
	 * @return the patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the patient bills.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @return the range of patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the patient bills.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of patient bills
	 * @param end the upper bound of the range of patient bills (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PatientBill> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<PatientBill> list = (List<PatientBill>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_PATIENTBILL);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_PATIENTBILL;

				if (pagination) {
					sql = sql.concat(PatientBillModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PatientBill>(list);
				}
				else {
					list = (List<PatientBill>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the patient bills from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (PatientBill patientBill : findAll()) {
			remove(patientBill);
		}
	}

	/**
	 * Returns the number of patient bills.
	 *
	 * @return the number of patient bills
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_PATIENTBILL);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the patient bill persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.PatientBill")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<PatientBill>> listenersList = new ArrayList<ModelListener<PatientBill>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<PatientBill>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(PatientBillImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_PATIENTBILL = "SELECT patientBill FROM PatientBill patientBill";
	private static final String _SQL_SELECT_PATIENTBILL_WHERE = "SELECT patientBill FROM PatientBill patientBill WHERE ";
	private static final String _SQL_COUNT_PATIENTBILL = "SELECT COUNT(patientBill) FROM PatientBill patientBill";
	private static final String _SQL_COUNT_PATIENTBILL_WHERE = "SELECT COUNT(patientBill) FROM PatientBill patientBill WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "patientBill.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No PatientBill exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No PatientBill exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(PatientBillPersistenceImpl.class);
	private static PatientBill _nullPatientBill = new PatientBillImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<PatientBill> toCacheModel() {
				return _nullPatientBillCacheModel;
			}
		};

	private static CacheModel<PatientBill> _nullPatientBillCacheModel = new CacheModel<PatientBill>() {
			@Override
			public PatientBill toEntityModel() {
				return _nullPatientBill;
			}
		};
}