/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.CalendarUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchDepositException;
import com.napier.portal.db.model.Deposit;
import com.napier.portal.db.model.impl.DepositImpl;
import com.napier.portal.db.model.impl.DepositModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * The persistence implementation for the deposit service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DepositPersistence
 * @see DepositUtil
 * @generated
 */
public class DepositPersistenceImpl extends BasePersistenceImpl<Deposit>
	implements DepositPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link DepositUtil} to access the deposit persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = DepositImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_PATIENTBILLID =
		new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBypatientBillId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PATIENTBILLID =
		new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBypatientBillId",
			new String[] { Long.class.getName() },
			DepositModelImpl.PATIENTBILLID_COLUMN_BITMASK |
			DepositModelImpl.DEPOSITDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_PATIENTBILLID = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBypatientBillId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the deposits where patientBillId = &#63;.
	 *
	 * @param patientBillId the patient bill ID
	 * @return the matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBypatientBillId(long patientBillId)
		throws SystemException {
		return findBypatientBillId(patientBillId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the deposits where patientBillId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param patientBillId the patient bill ID
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @return the range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBypatientBillId(long patientBillId, int start,
		int end) throws SystemException {
		return findBypatientBillId(patientBillId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the deposits where patientBillId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param patientBillId the patient bill ID
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBypatientBillId(long patientBillId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PATIENTBILLID;
			finderArgs = new Object[] { patientBillId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_PATIENTBILLID;
			finderArgs = new Object[] {
					patientBillId,
					
					start, end, orderByComparator
				};
		}

		List<Deposit> list = (List<Deposit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Deposit deposit : list) {
				if ((patientBillId != deposit.getPatientBillId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DEPOSIT_WHERE);

			query.append(_FINDER_COLUMN_PATIENTBILLID_PATIENTBILLID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DepositModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(patientBillId);

				if (!pagination) {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Deposit>(list);
				}
				else {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first deposit in the ordered set where patientBillId = &#63;.
	 *
	 * @param patientBillId the patient bill ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findBypatientBillId_First(long patientBillId,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchBypatientBillId_First(patientBillId,
				orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("patientBillId=");
		msg.append(patientBillId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the first deposit in the ordered set where patientBillId = &#63;.
	 *
	 * @param patientBillId the patient bill ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBypatientBillId_First(long patientBillId,
		OrderByComparator orderByComparator) throws SystemException {
		List<Deposit> list = findBypatientBillId(patientBillId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last deposit in the ordered set where patientBillId = &#63;.
	 *
	 * @param patientBillId the patient bill ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findBypatientBillId_Last(long patientBillId,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchBypatientBillId_Last(patientBillId,
				orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("patientBillId=");
		msg.append(patientBillId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the last deposit in the ordered set where patientBillId = &#63;.
	 *
	 * @param patientBillId the patient bill ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBypatientBillId_Last(long patientBillId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBypatientBillId(patientBillId);

		if (count == 0) {
			return null;
		}

		List<Deposit> list = findBypatientBillId(patientBillId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the deposits before and after the current deposit in the ordered set where patientBillId = &#63;.
	 *
	 * @param depositId the primary key of the current deposit
	 * @param patientBillId the patient bill ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit[] findBypatientBillId_PrevAndNext(long depositId,
		long patientBillId, OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = findByPrimaryKey(depositId);

		Session session = null;

		try {
			session = openSession();

			Deposit[] array = new DepositImpl[3];

			array[0] = getBypatientBillId_PrevAndNext(session, deposit,
					patientBillId, orderByComparator, true);

			array[1] = deposit;

			array[2] = getBypatientBillId_PrevAndNext(session, deposit,
					patientBillId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Deposit getBypatientBillId_PrevAndNext(Session session,
		Deposit deposit, long patientBillId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DEPOSIT_WHERE);

		query.append(_FINDER_COLUMN_PATIENTBILLID_PATIENTBILLID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DepositModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(patientBillId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(deposit);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Deposit> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the deposits where patientBillId = &#63; from the database.
	 *
	 * @param patientBillId the patient bill ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBypatientBillId(long patientBillId)
		throws SystemException {
		for (Deposit deposit : findBypatientBillId(patientBillId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(deposit);
		}
	}

	/**
	 * Returns the number of deposits where patientBillId = &#63;.
	 *
	 * @param patientBillId the patient bill ID
	 * @return the number of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBypatientBillId(long patientBillId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_PATIENTBILLID;

		Object[] finderArgs = new Object[] { patientBillId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DEPOSIT_WHERE);

			query.append(_FINDER_COLUMN_PATIENTBILLID_PATIENTBILLID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(patientBillId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PATIENTBILLID_PATIENTBILLID_2 = "deposit.patientBillId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_DEPOSITNUMBER = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchBydepositNumber",
			new String[] { String.class.getName() },
			DepositModelImpl.DEPOSITNUMBER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DEPOSITNUMBER = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBydepositNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns the deposit where depositNumber = &#63; or throws a {@link com.napier.portal.db.NoSuchDepositException} if it could not be found.
	 *
	 * @param depositNumber the deposit number
	 * @return the matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findBydepositNumber(String depositNumber)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchBydepositNumber(depositNumber);

		if (deposit == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("depositNumber=");
			msg.append(depositNumber);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchDepositException(msg.toString());
		}

		return deposit;
	}

	/**
	 * Returns the deposit where depositNumber = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param depositNumber the deposit number
	 * @return the matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBydepositNumber(String depositNumber)
		throws SystemException {
		return fetchBydepositNumber(depositNumber, true);
	}

	/**
	 * Returns the deposit where depositNumber = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param depositNumber the deposit number
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBydepositNumber(String depositNumber,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { depositNumber };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER,
					finderArgs, this);
		}

		if (result instanceof Deposit) {
			Deposit deposit = (Deposit)result;

			if (!Validator.equals(depositNumber, deposit.getDepositNumber())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_DEPOSIT_WHERE);

			boolean bindDepositNumber = false;

			if (depositNumber == null) {
				query.append(_FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_1);
			}
			else if (depositNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_3);
			}
			else {
				bindDepositNumber = true;

				query.append(_FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDepositNumber) {
					qPos.add(depositNumber);
				}

				List<Deposit> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"DepositPersistenceImpl.fetchBydepositNumber(String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					Deposit deposit = list.get(0);

					result = deposit;

					cacheResult(deposit);

					if ((deposit.getDepositNumber() == null) ||
							!deposit.getDepositNumber().equals(depositNumber)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER,
							finderArgs, deposit);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Deposit)result;
		}
	}

	/**
	 * Removes the deposit where depositNumber = &#63; from the database.
	 *
	 * @param depositNumber the deposit number
	 * @return the deposit that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit removeBydepositNumber(String depositNumber)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = findBydepositNumber(depositNumber);

		return remove(deposit);
	}

	/**
	 * Returns the number of deposits where depositNumber = &#63;.
	 *
	 * @param depositNumber the deposit number
	 * @return the number of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBydepositNumber(String depositNumber)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DEPOSITNUMBER;

		Object[] finderArgs = new Object[] { depositNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DEPOSIT_WHERE);

			boolean bindDepositNumber = false;

			if (depositNumber == null) {
				query.append(_FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_1);
			}
			else if (depositNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_3);
			}
			else {
				bindDepositNumber = true;

				query.append(_FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDepositNumber) {
					qPos.add(depositNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_1 = "deposit.depositNumber IS NULL";
	private static final String _FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_2 = "deposit.depositNumber = ?";
	private static final String _FINDER_COLUMN_DEPOSITNUMBER_DEPOSITNUMBER_3 = "(deposit.depositNumber IS NULL OR deposit.depositNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBymrNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER =
		new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBymrNumber",
			new String[] { String.class.getName() },
			DepositModelImpl.MRNUMBER_COLUMN_BITMASK |
			DepositModelImpl.DEPOSITDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MRNUMBER = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymrNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the deposits where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBymrNumber(String mrNumber)
		throws SystemException {
		return findBymrNumber(mrNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the deposits where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @return the range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBymrNumber(String mrNumber, int start, int end)
		throws SystemException {
		return findBymrNumber(mrNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the deposits where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBymrNumber(String mrNumber, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber, start, end, orderByComparator };
		}

		List<Deposit> list = (List<Deposit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Deposit deposit : list) {
				if (!Validator.equals(mrNumber, deposit.getMrNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DEPOSIT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DepositModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				if (!pagination) {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Deposit>(list);
				}
				else {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first deposit in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchBymrNumber_First(mrNumber, orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the first deposit in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<Deposit> list = findBymrNumber(mrNumber, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last deposit in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchBymrNumber_Last(mrNumber, orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the last deposit in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBymrNumber(mrNumber);

		if (count == 0) {
			return null;
		}

		List<Deposit> list = findBymrNumber(mrNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the deposits before and after the current deposit in the ordered set where mrNumber = &#63;.
	 *
	 * @param depositId the primary key of the current deposit
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit[] findBymrNumber_PrevAndNext(long depositId,
		String mrNumber, OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = findByPrimaryKey(depositId);

		Session session = null;

		try {
			session = openSession();

			Deposit[] array = new DepositImpl[3];

			array[0] = getBymrNumber_PrevAndNext(session, deposit, mrNumber,
					orderByComparator, true);

			array[1] = deposit;

			array[2] = getBymrNumber_PrevAndNext(session, deposit, mrNumber,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Deposit getBymrNumber_PrevAndNext(Session session,
		Deposit deposit, String mrNumber, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DEPOSIT_WHERE);

		boolean bindMrNumber = false;

		if (mrNumber == null) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
		}
		else if (mrNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
		}
		else {
			bindMrNumber = true;

			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DepositModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMrNumber) {
			qPos.add(mrNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(deposit);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Deposit> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the deposits where mrNumber = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBymrNumber(String mrNumber) throws SystemException {
		for (Deposit deposit : findBymrNumber(mrNumber, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(deposit);
		}
	}

	/**
	 * Returns the number of deposits where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the number of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymrNumber(String mrNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MRNUMBER;

		Object[] finderArgs = new Object[] { mrNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DEPOSIT_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_1 = "deposit.mrNumber IS NULL";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_2 = "deposit.mrNumber = ?";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_3 = "(deposit.mrNumber IS NULL OR deposit.mrNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByipNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER =
		new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByipNumber",
			new String[] { String.class.getName() },
			DepositModelImpl.IPNUMBER_COLUMN_BITMASK |
			DepositModelImpl.DEPOSITDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_IPNUMBER = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByipNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the deposits where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findByipNumber(String ipNumber)
		throws SystemException {
		return findByipNumber(ipNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the deposits where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @return the range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findByipNumber(String ipNumber, int start, int end)
		throws SystemException {
		return findByipNumber(ipNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the deposits where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findByipNumber(String ipNumber, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber, start, end, orderByComparator };
		}

		List<Deposit> list = (List<Deposit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Deposit deposit : list) {
				if (!Validator.equals(ipNumber, deposit.getIpNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DEPOSIT_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DepositModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				if (!pagination) {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Deposit>(list);
				}
				else {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first deposit in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchByipNumber_First(ipNumber, orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the first deposit in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<Deposit> list = findByipNumber(ipNumber, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last deposit in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchByipNumber_Last(ipNumber, orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the last deposit in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByipNumber(ipNumber);

		if (count == 0) {
			return null;
		}

		List<Deposit> list = findByipNumber(ipNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the deposits before and after the current deposit in the ordered set where ipNumber = &#63;.
	 *
	 * @param depositId the primary key of the current deposit
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit[] findByipNumber_PrevAndNext(long depositId,
		String ipNumber, OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = findByPrimaryKey(depositId);

		Session session = null;

		try {
			session = openSession();

			Deposit[] array = new DepositImpl[3];

			array[0] = getByipNumber_PrevAndNext(session, deposit, ipNumber,
					orderByComparator, true);

			array[1] = deposit;

			array[2] = getByipNumber_PrevAndNext(session, deposit, ipNumber,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Deposit getByipNumber_PrevAndNext(Session session,
		Deposit deposit, String ipNumber, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DEPOSIT_WHERE);

		boolean bindIpNumber = false;

		if (ipNumber == null) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
		}
		else if (ipNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
		}
		else {
			bindIpNumber = true;

			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DepositModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindIpNumber) {
			qPos.add(ipNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(deposit);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Deposit> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the deposits where ipNumber = &#63; from the database.
	 *
	 * @param ipNumber the ip number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByipNumber(String ipNumber) throws SystemException {
		for (Deposit deposit : findByipNumber(ipNumber, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(deposit);
		}
	}

	/**
	 * Returns the number of deposits where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the number of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByipNumber(String ipNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_IPNUMBER;

		Object[] finderArgs = new Object[] { ipNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DEPOSIT_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_1 = "deposit.ipNumber IS NULL";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_2 = "deposit.ipNumber = ?";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_3 = "(deposit.ipNumber IS NULL OR deposit.ipNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_DEPOSITDATE =
		new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBydepositDate",
			new String[] {
				Date.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DEPOSITDATE =
		new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, DepositImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBydepositDate",
			new String[] { Date.class.getName() },
			DepositModelImpl.DEPOSITDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DEPOSITDATE = new FinderPath(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBydepositDate",
			new String[] { Date.class.getName() });

	/**
	 * Returns all the deposits where depositDate = &#63;.
	 *
	 * @param depositDate the deposit date
	 * @return the matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBydepositDate(Date depositDate)
		throws SystemException {
		return findBydepositDate(depositDate, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the deposits where depositDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param depositDate the deposit date
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @return the range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBydepositDate(Date depositDate, int start, int end)
		throws SystemException {
		return findBydepositDate(depositDate, start, end, null);
	}

	/**
	 * Returns an ordered range of all the deposits where depositDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param depositDate the deposit date
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findBydepositDate(Date depositDate, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DEPOSITDATE;
			finderArgs = new Object[] { depositDate };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_DEPOSITDATE;
			finderArgs = new Object[] { depositDate, start, end, orderByComparator };
		}

		List<Deposit> list = (List<Deposit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Deposit deposit : list) {
				if (!Validator.equals(depositDate, deposit.getDepositDate())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DEPOSIT_WHERE);

			boolean bindDepositDate = false;

			if (depositDate == null) {
				query.append(_FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_1);
			}
			else {
				bindDepositDate = true;

				query.append(_FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DepositModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDepositDate) {
					qPos.add(CalendarUtil.getTimestamp(depositDate));
				}

				if (!pagination) {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Deposit>(list);
				}
				else {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first deposit in the ordered set where depositDate = &#63;.
	 *
	 * @param depositDate the deposit date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findBydepositDate_First(Date depositDate,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchBydepositDate_First(depositDate,
				orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("depositDate=");
		msg.append(depositDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the first deposit in the ordered set where depositDate = &#63;.
	 *
	 * @param depositDate the deposit date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBydepositDate_First(Date depositDate,
		OrderByComparator orderByComparator) throws SystemException {
		List<Deposit> list = findBydepositDate(depositDate, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last deposit in the ordered set where depositDate = &#63;.
	 *
	 * @param depositDate the deposit date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findBydepositDate_Last(Date depositDate,
		OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchBydepositDate_Last(depositDate, orderByComparator);

		if (deposit != null) {
			return deposit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("depositDate=");
		msg.append(depositDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDepositException(msg.toString());
	}

	/**
	 * Returns the last deposit in the ordered set where depositDate = &#63;.
	 *
	 * @param depositDate the deposit date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching deposit, or <code>null</code> if a matching deposit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchBydepositDate_Last(Date depositDate,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBydepositDate(depositDate);

		if (count == 0) {
			return null;
		}

		List<Deposit> list = findBydepositDate(depositDate, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the deposits before and after the current deposit in the ordered set where depositDate = &#63;.
	 *
	 * @param depositId the primary key of the current deposit
	 * @param depositDate the deposit date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit[] findBydepositDate_PrevAndNext(long depositId,
		Date depositDate, OrderByComparator orderByComparator)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = findByPrimaryKey(depositId);

		Session session = null;

		try {
			session = openSession();

			Deposit[] array = new DepositImpl[3];

			array[0] = getBydepositDate_PrevAndNext(session, deposit,
					depositDate, orderByComparator, true);

			array[1] = deposit;

			array[2] = getBydepositDate_PrevAndNext(session, deposit,
					depositDate, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Deposit getBydepositDate_PrevAndNext(Session session,
		Deposit deposit, Date depositDate, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DEPOSIT_WHERE);

		boolean bindDepositDate = false;

		if (depositDate == null) {
			query.append(_FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_1);
		}
		else {
			bindDepositDate = true;

			query.append(_FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DepositModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindDepositDate) {
			qPos.add(CalendarUtil.getTimestamp(depositDate));
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(deposit);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Deposit> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the deposits where depositDate = &#63; from the database.
	 *
	 * @param depositDate the deposit date
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBydepositDate(Date depositDate) throws SystemException {
		for (Deposit deposit : findBydepositDate(depositDate,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(deposit);
		}
	}

	/**
	 * Returns the number of deposits where depositDate = &#63;.
	 *
	 * @param depositDate the deposit date
	 * @return the number of matching deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBydepositDate(Date depositDate) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DEPOSITDATE;

		Object[] finderArgs = new Object[] { depositDate };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DEPOSIT_WHERE);

			boolean bindDepositDate = false;

			if (depositDate == null) {
				query.append(_FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_1);
			}
			else {
				bindDepositDate = true;

				query.append(_FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDepositDate) {
					qPos.add(CalendarUtil.getTimestamp(depositDate));
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_1 = "deposit.depositDate IS NULL";
	private static final String _FINDER_COLUMN_DEPOSITDATE_DEPOSITDATE_2 = "deposit.depositDate = ?";

	public DepositPersistenceImpl() {
		setModelClass(Deposit.class);
	}

	/**
	 * Caches the deposit in the entity cache if it is enabled.
	 *
	 * @param deposit the deposit
	 */
	@Override
	public void cacheResult(Deposit deposit) {
		EntityCacheUtil.putResult(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositImpl.class, deposit.getPrimaryKey(), deposit);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER,
			new Object[] { deposit.getDepositNumber() }, deposit);

		deposit.resetOriginalValues();
	}

	/**
	 * Caches the deposits in the entity cache if it is enabled.
	 *
	 * @param deposits the deposits
	 */
	@Override
	public void cacheResult(List<Deposit> deposits) {
		for (Deposit deposit : deposits) {
			if (EntityCacheUtil.getResult(
						DepositModelImpl.ENTITY_CACHE_ENABLED,
						DepositImpl.class, deposit.getPrimaryKey()) == null) {
				cacheResult(deposit);
			}
			else {
				deposit.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all deposits.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(DepositImpl.class.getName());
		}

		EntityCacheUtil.clearCache(DepositImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the deposit.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Deposit deposit) {
		EntityCacheUtil.removeResult(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositImpl.class, deposit.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(deposit);
	}

	@Override
	public void clearCache(List<Deposit> deposits) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Deposit deposit : deposits) {
			EntityCacheUtil.removeResult(DepositModelImpl.ENTITY_CACHE_ENABLED,
				DepositImpl.class, deposit.getPrimaryKey());

			clearUniqueFindersCache(deposit);
		}
	}

	protected void cacheUniqueFindersCache(Deposit deposit) {
		if (deposit.isNew()) {
			Object[] args = new Object[] { deposit.getDepositNumber() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_DEPOSITNUMBER, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER, args,
				deposit);
		}
		else {
			DepositModelImpl depositModelImpl = (DepositModelImpl)deposit;

			if ((depositModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_DEPOSITNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { deposit.getDepositNumber() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_DEPOSITNUMBER,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER,
					args, deposit);
			}
		}
	}

	protected void clearUniqueFindersCache(Deposit deposit) {
		DepositModelImpl depositModelImpl = (DepositModelImpl)deposit;

		Object[] args = new Object[] { deposit.getDepositNumber() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DEPOSITNUMBER, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER, args);

		if ((depositModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_DEPOSITNUMBER.getColumnBitmask()) != 0) {
			args = new Object[] { depositModelImpl.getOriginalDepositNumber() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DEPOSITNUMBER,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_DEPOSITNUMBER,
				args);
		}
	}

	/**
	 * Creates a new deposit with the primary key. Does not add the deposit to the database.
	 *
	 * @param depositId the primary key for the new deposit
	 * @return the new deposit
	 */
	@Override
	public Deposit create(long depositId) {
		Deposit deposit = new DepositImpl();

		deposit.setNew(true);
		deposit.setPrimaryKey(depositId);

		return deposit;
	}

	/**
	 * Removes the deposit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param depositId the primary key of the deposit
	 * @return the deposit that was removed
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit remove(long depositId)
		throws NoSuchDepositException, SystemException {
		return remove((Serializable)depositId);
	}

	/**
	 * Removes the deposit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the deposit
	 * @return the deposit that was removed
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit remove(Serializable primaryKey)
		throws NoSuchDepositException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Deposit deposit = (Deposit)session.get(DepositImpl.class, primaryKey);

			if (deposit == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDepositException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(deposit);
		}
		catch (NoSuchDepositException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Deposit removeImpl(Deposit deposit) throws SystemException {
		deposit = toUnwrappedModel(deposit);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(deposit)) {
				deposit = (Deposit)session.get(DepositImpl.class,
						deposit.getPrimaryKeyObj());
			}

			if (deposit != null) {
				session.delete(deposit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (deposit != null) {
			clearCache(deposit);
		}

		return deposit;
	}

	@Override
	public Deposit updateImpl(com.napier.portal.db.model.Deposit deposit)
		throws SystemException {
		deposit = toUnwrappedModel(deposit);

		boolean isNew = deposit.isNew();

		DepositModelImpl depositModelImpl = (DepositModelImpl)deposit;

		Session session = null;

		try {
			session = openSession();

			if (deposit.isNew()) {
				session.save(deposit);

				deposit.setNew(false);
			}
			else {
				session.merge(deposit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !DepositModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((depositModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PATIENTBILLID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						depositModelImpl.getOriginalPatientBillId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PATIENTBILLID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PATIENTBILLID,
					args);

				args = new Object[] { depositModelImpl.getPatientBillId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PATIENTBILLID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PATIENTBILLID,
					args);
			}

			if ((depositModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						depositModelImpl.getOriginalMrNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);

				args = new Object[] { depositModelImpl.getMrNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);
			}

			if ((depositModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						depositModelImpl.getOriginalIpNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);

				args = new Object[] { depositModelImpl.getIpNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);
			}

			if ((depositModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DEPOSITDATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						depositModelImpl.getOriginalDepositDate()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DEPOSITDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DEPOSITDATE,
					args);

				args = new Object[] { depositModelImpl.getDepositDate() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DEPOSITDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DEPOSITDATE,
					args);
			}
		}

		EntityCacheUtil.putResult(DepositModelImpl.ENTITY_CACHE_ENABLED,
			DepositImpl.class, deposit.getPrimaryKey(), deposit);

		clearUniqueFindersCache(deposit);
		cacheUniqueFindersCache(deposit);

		return deposit;
	}

	protected Deposit toUnwrappedModel(Deposit deposit) {
		if (deposit instanceof DepositImpl) {
			return deposit;
		}

		DepositImpl depositImpl = new DepositImpl();

		depositImpl.setNew(deposit.isNew());
		depositImpl.setPrimaryKey(deposit.getPrimaryKey());

		depositImpl.setDepositId(deposit.getDepositId());
		depositImpl.setMrNumber(deposit.getMrNumber());
		depositImpl.setIpNumber(deposit.getIpNumber());
		depositImpl.setDepositNumber(deposit.getDepositNumber());
		depositImpl.setDepositAmount(deposit.getDepositAmount());
		depositImpl.setDepositAgainst(deposit.getDepositAgainst());
		depositImpl.setDepositDate(deposit.getDepositDate());
		depositImpl.setPatientBillId(deposit.getPatientBillId());

		return depositImpl;
	}

	/**
	 * Returns the deposit with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the deposit
	 * @return the deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDepositException, SystemException {
		Deposit deposit = fetchByPrimaryKey(primaryKey);

		if (deposit == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDepositException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return deposit;
	}

	/**
	 * Returns the deposit with the primary key or throws a {@link com.napier.portal.db.NoSuchDepositException} if it could not be found.
	 *
	 * @param depositId the primary key of the deposit
	 * @return the deposit
	 * @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit findByPrimaryKey(long depositId)
		throws NoSuchDepositException, SystemException {
		return findByPrimaryKey((Serializable)depositId);
	}

	/**
	 * Returns the deposit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the deposit
	 * @return the deposit, or <code>null</code> if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		Deposit deposit = (Deposit)EntityCacheUtil.getResult(DepositModelImpl.ENTITY_CACHE_ENABLED,
				DepositImpl.class, primaryKey);

		if (deposit == _nullDeposit) {
			return null;
		}

		if (deposit == null) {
			Session session = null;

			try {
				session = openSession();

				deposit = (Deposit)session.get(DepositImpl.class, primaryKey);

				if (deposit != null) {
					cacheResult(deposit);
				}
				else {
					EntityCacheUtil.putResult(DepositModelImpl.ENTITY_CACHE_ENABLED,
						DepositImpl.class, primaryKey, _nullDeposit);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(DepositModelImpl.ENTITY_CACHE_ENABLED,
					DepositImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return deposit;
	}

	/**
	 * Returns the deposit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param depositId the primary key of the deposit
	 * @return the deposit, or <code>null</code> if a deposit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Deposit fetchByPrimaryKey(long depositId) throws SystemException {
		return fetchByPrimaryKey((Serializable)depositId);
	}

	/**
	 * Returns all the deposits.
	 *
	 * @return the deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the deposits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @return the range of deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findAll(int start, int end) throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the deposits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of deposits
	 * @param end the upper bound of the range of deposits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Deposit> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Deposit> list = (List<Deposit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_DEPOSIT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DEPOSIT;

				if (pagination) {
					sql = sql.concat(DepositModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Deposit>(list);
				}
				else {
					list = (List<Deposit>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the deposits from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (Deposit deposit : findAll()) {
			remove(deposit);
		}
	}

	/**
	 * Returns the number of deposits.
	 *
	 * @return the number of deposits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DEPOSIT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the deposit persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.Deposit")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Deposit>> listenersList = new ArrayList<ModelListener<Deposit>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Deposit>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(DepositImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_DEPOSIT = "SELECT deposit FROM Deposit deposit";
	private static final String _SQL_SELECT_DEPOSIT_WHERE = "SELECT deposit FROM Deposit deposit WHERE ";
	private static final String _SQL_COUNT_DEPOSIT = "SELECT COUNT(deposit) FROM Deposit deposit";
	private static final String _SQL_COUNT_DEPOSIT_WHERE = "SELECT COUNT(deposit) FROM Deposit deposit WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "deposit.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Deposit exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Deposit exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(DepositPersistenceImpl.class);
	private static Deposit _nullDeposit = new DepositImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Deposit> toCacheModel() {
				return _nullDepositCacheModel;
			}
		};

	private static CacheModel<Deposit> _nullDepositCacheModel = new CacheModel<Deposit>() {
			@Override
			public Deposit toEntityModel() {
				return _nullDeposit;
			}
		};
}