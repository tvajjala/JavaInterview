/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.CalendarUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchDischargeSummaryException;
import com.napier.portal.db.model.DischargeSummary;
import com.napier.portal.db.model.impl.DischargeSummaryImpl;
import com.napier.portal.db.model.impl.DischargeSummaryModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * The persistence implementation for the discharge summary service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DischargeSummaryPersistence
 * @see DischargeSummaryUtil
 * @generated
 */
public class DischargeSummaryPersistenceImpl extends BasePersistenceImpl<DischargeSummary>
	implements DischargeSummaryPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link DischargeSummaryUtil} to access the discharge summary persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = DischargeSummaryImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBymrNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER =
		new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBymrNumber",
			new String[] { String.class.getName() },
			DischargeSummaryModelImpl.MRNUMBER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MRNUMBER = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymrNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the discharge summaries where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findBymrNumber(String mrNumber)
		throws SystemException {
		return findBymrNumber(mrNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the discharge summaries where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @return the range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findBymrNumber(String mrNumber, int start,
		int end) throws SystemException {
		return findBymrNumber(mrNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discharge summaries where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findBymrNumber(String mrNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber, start, end, orderByComparator };
		}

		List<DischargeSummary> list = (List<DischargeSummary>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DischargeSummary dischargeSummary : list) {
				if (!Validator.equals(mrNumber, dischargeSummary.getMrNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				if (!pagination) {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DischargeSummary>(list);
				}
				else {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discharge summary in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchBymrNumber_First(mrNumber,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the first discharge summary in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<DischargeSummary> list = findBymrNumber(mrNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discharge summary in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchBymrNumber_Last(mrNumber,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the last discharge summary in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBymrNumber(mrNumber);

		if (count == 0) {
			return null;
		}

		List<DischargeSummary> list = findBymrNumber(mrNumber, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discharge summaries before and after the current discharge summary in the ordered set where mrNumber = &#63;.
	 *
	 * @param dischargeSummaryId the primary key of the current discharge summary
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary[] findBymrNumber_PrevAndNext(
		long dischargeSummaryId, String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = findByPrimaryKey(dischargeSummaryId);

		Session session = null;

		try {
			session = openSession();

			DischargeSummary[] array = new DischargeSummaryImpl[3];

			array[0] = getBymrNumber_PrevAndNext(session, dischargeSummary,
					mrNumber, orderByComparator, true);

			array[1] = dischargeSummary;

			array[2] = getBymrNumber_PrevAndNext(session, dischargeSummary,
					mrNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DischargeSummary getBymrNumber_PrevAndNext(Session session,
		DischargeSummary dischargeSummary, String mrNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

		boolean bindMrNumber = false;

		if (mrNumber == null) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
		}
		else if (mrNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
		}
		else {
			bindMrNumber = true;

			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMrNumber) {
			qPos.add(mrNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(dischargeSummary);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DischargeSummary> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discharge summaries where mrNumber = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBymrNumber(String mrNumber) throws SystemException {
		for (DischargeSummary dischargeSummary : findBymrNumber(mrNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(dischargeSummary);
		}
	}

	/**
	 * Returns the number of discharge summaries where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the number of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymrNumber(String mrNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MRNUMBER;

		Object[] finderArgs = new Object[] { mrNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCHARGESUMMARY_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_1 = "dischargeSummary.mrNumber IS NULL";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_2 = "dischargeSummary.mrNumber = ?";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_3 = "(dischargeSummary.mrNumber IS NULL OR dischargeSummary.mrNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByipNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER =
		new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByipNumber",
			new String[] { String.class.getName() },
			DischargeSummaryModelImpl.IPNUMBER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_IPNUMBER = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByipNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the discharge summaries where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByipNumber(String ipNumber)
		throws SystemException {
		return findByipNumber(ipNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the discharge summaries where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @return the range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByipNumber(String ipNumber, int start,
		int end) throws SystemException {
		return findByipNumber(ipNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discharge summaries where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByipNumber(String ipNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber, start, end, orderByComparator };
		}

		List<DischargeSummary> list = (List<DischargeSummary>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DischargeSummary dischargeSummary : list) {
				if (!Validator.equals(ipNumber, dischargeSummary.getIpNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				if (!pagination) {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DischargeSummary>(list);
				}
				else {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discharge summary in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByipNumber_First(ipNumber,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the first discharge summary in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<DischargeSummary> list = findByipNumber(ipNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discharge summary in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByipNumber_Last(ipNumber,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the last discharge summary in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByipNumber(ipNumber);

		if (count == 0) {
			return null;
		}

		List<DischargeSummary> list = findByipNumber(ipNumber, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discharge summaries before and after the current discharge summary in the ordered set where ipNumber = &#63;.
	 *
	 * @param dischargeSummaryId the primary key of the current discharge summary
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary[] findByipNumber_PrevAndNext(
		long dischargeSummaryId, String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = findByPrimaryKey(dischargeSummaryId);

		Session session = null;

		try {
			session = openSession();

			DischargeSummary[] array = new DischargeSummaryImpl[3];

			array[0] = getByipNumber_PrevAndNext(session, dischargeSummary,
					ipNumber, orderByComparator, true);

			array[1] = dischargeSummary;

			array[2] = getByipNumber_PrevAndNext(session, dischargeSummary,
					ipNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DischargeSummary getByipNumber_PrevAndNext(Session session,
		DischargeSummary dischargeSummary, String ipNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

		boolean bindIpNumber = false;

		if (ipNumber == null) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
		}
		else if (ipNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
		}
		else {
			bindIpNumber = true;

			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindIpNumber) {
			qPos.add(ipNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(dischargeSummary);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DischargeSummary> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discharge summaries where ipNumber = &#63; from the database.
	 *
	 * @param ipNumber the ip number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByipNumber(String ipNumber) throws SystemException {
		for (DischargeSummary dischargeSummary : findByipNumber(ipNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(dischargeSummary);
		}
	}

	/**
	 * Returns the number of discharge summaries where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the number of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByipNumber(String ipNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_IPNUMBER;

		Object[] finderArgs = new Object[] { ipNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCHARGESUMMARY_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_1 = "dischargeSummary.ipNumber IS NULL";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_2 = "dischargeSummary.ipNumber = ?";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_3 = "(dischargeSummary.ipNumber IS NULL OR dischargeSummary.ipNumber = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_BEDCLASS = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchBybedClass", new String[] { String.class.getName() },
			DischargeSummaryModelImpl.BEDCLASS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BEDCLASS = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybedClass",
			new String[] { String.class.getName() });

	/**
	 * Returns the discharge summary where bedClass = &#63; or throws a {@link com.napier.portal.db.NoSuchDischargeSummaryException} if it could not be found.
	 *
	 * @param bedClass the bed class
	 * @return the matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findBybedClass(String bedClass)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchBybedClass(bedClass);

		if (dischargeSummary == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("bedClass=");
			msg.append(bedClass);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchDischargeSummaryException(msg.toString());
		}

		return dischargeSummary;
	}

	/**
	 * Returns the discharge summary where bedClass = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param bedClass the bed class
	 * @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchBybedClass(String bedClass)
		throws SystemException {
		return fetchBybedClass(bedClass, true);
	}

	/**
	 * Returns the discharge summary where bedClass = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param bedClass the bed class
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchBybedClass(String bedClass,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { bedClass };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_BEDCLASS,
					finderArgs, this);
		}

		if (result instanceof DischargeSummary) {
			DischargeSummary dischargeSummary = (DischargeSummary)result;

			if (!Validator.equals(bedClass, dischargeSummary.getBedClass())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

			boolean bindBedClass = false;

			if (bedClass == null) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_1);
			}
			else if (bedClass.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_3);
			}
			else {
				bindBedClass = true;

				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindBedClass) {
					qPos.add(bedClass);
				}

				List<DischargeSummary> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_BEDCLASS,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"DischargeSummaryPersistenceImpl.fetchBybedClass(String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					DischargeSummary dischargeSummary = list.get(0);

					result = dischargeSummary;

					cacheResult(dischargeSummary);

					if ((dischargeSummary.getBedClass() == null) ||
							!dischargeSummary.getBedClass().equals(bedClass)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_BEDCLASS,
							finderArgs, dischargeSummary);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_BEDCLASS,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (DischargeSummary)result;
		}
	}

	/**
	 * Removes the discharge summary where bedClass = &#63; from the database.
	 *
	 * @param bedClass the bed class
	 * @return the discharge summary that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary removeBybedClass(String bedClass)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = findBybedClass(bedClass);

		return remove(dischargeSummary);
	}

	/**
	 * Returns the number of discharge summaries where bedClass = &#63;.
	 *
	 * @param bedClass the bed class
	 * @return the number of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybedClass(String bedClass) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BEDCLASS;

		Object[] finderArgs = new Object[] { bedClass };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCHARGESUMMARY_WHERE);

			boolean bindBedClass = false;

			if (bedClass == null) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_1);
			}
			else if (bedClass.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_3);
			}
			else {
				bindBedClass = true;

				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindBedClass) {
					qPos.add(bedClass);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BEDCLASS_BEDCLASS_1 = "dischargeSummary.bedClass IS NULL";
	private static final String _FINDER_COLUMN_BEDCLASS_BEDCLASS_2 = "dischargeSummary.bedClass = ?";
	private static final String _FINDER_COLUMN_BEDCLASS_BEDCLASS_3 = "(dischargeSummary.bedClass IS NULL OR dischargeSummary.bedClass = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_WARD = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByward",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByward",
			new String[] { String.class.getName() },
			DischargeSummaryModelImpl.WARD_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_WARD = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByward",
			new String[] { String.class.getName() });

	/**
	 * Returns all the discharge summaries where ward = &#63;.
	 *
	 * @param ward the ward
	 * @return the matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByward(String ward)
		throws SystemException {
		return findByward(ward, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discharge summaries where ward = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ward the ward
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @return the range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByward(String ward, int start, int end)
		throws SystemException {
		return findByward(ward, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discharge summaries where ward = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ward the ward
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByward(String ward, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD;
			finderArgs = new Object[] { ward };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_WARD;
			finderArgs = new Object[] { ward, start, end, orderByComparator };
		}

		List<DischargeSummary> list = (List<DischargeSummary>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DischargeSummary dischargeSummary : list) {
				if (!Validator.equals(ward, dischargeSummary.getWard())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

			boolean bindWard = false;

			if (ward == null) {
				query.append(_FINDER_COLUMN_WARD_WARD_1);
			}
			else if (ward.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARD_WARD_3);
			}
			else {
				bindWard = true;

				query.append(_FINDER_COLUMN_WARD_WARD_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindWard) {
					qPos.add(ward);
				}

				if (!pagination) {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DischargeSummary>(list);
				}
				else {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discharge summary in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByward_First(String ward,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByward_First(ward,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ward=");
		msg.append(ward);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the first discharge summary in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByward_First(String ward,
		OrderByComparator orderByComparator) throws SystemException {
		List<DischargeSummary> list = findByward(ward, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discharge summary in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByward_Last(String ward,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByward_Last(ward,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ward=");
		msg.append(ward);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the last discharge summary in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByward_Last(String ward,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByward(ward);

		if (count == 0) {
			return null;
		}

		List<DischargeSummary> list = findByward(ward, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discharge summaries before and after the current discharge summary in the ordered set where ward = &#63;.
	 *
	 * @param dischargeSummaryId the primary key of the current discharge summary
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary[] findByward_PrevAndNext(long dischargeSummaryId,
		String ward, OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = findByPrimaryKey(dischargeSummaryId);

		Session session = null;

		try {
			session = openSession();

			DischargeSummary[] array = new DischargeSummaryImpl[3];

			array[0] = getByward_PrevAndNext(session, dischargeSummary, ward,
					orderByComparator, true);

			array[1] = dischargeSummary;

			array[2] = getByward_PrevAndNext(session, dischargeSummary, ward,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DischargeSummary getByward_PrevAndNext(Session session,
		DischargeSummary dischargeSummary, String ward,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

		boolean bindWard = false;

		if (ward == null) {
			query.append(_FINDER_COLUMN_WARD_WARD_1);
		}
		else if (ward.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_WARD_WARD_3);
		}
		else {
			bindWard = true;

			query.append(_FINDER_COLUMN_WARD_WARD_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindWard) {
			qPos.add(ward);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(dischargeSummary);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DischargeSummary> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discharge summaries where ward = &#63; from the database.
	 *
	 * @param ward the ward
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByward(String ward) throws SystemException {
		for (DischargeSummary dischargeSummary : findByward(ward,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(dischargeSummary);
		}
	}

	/**
	 * Returns the number of discharge summaries where ward = &#63;.
	 *
	 * @param ward the ward
	 * @return the number of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByward(String ward) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_WARD;

		Object[] finderArgs = new Object[] { ward };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCHARGESUMMARY_WHERE);

			boolean bindWard = false;

			if (ward == null) {
				query.append(_FINDER_COLUMN_WARD_WARD_1);
			}
			else if (ward.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARD_WARD_3);
			}
			else {
				bindWard = true;

				query.append(_FINDER_COLUMN_WARD_WARD_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindWard) {
					qPos.add(ward);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_WARD_WARD_1 = "dischargeSummary.ward IS NULL";
	private static final String _FINDER_COLUMN_WARD_WARD_2 = "dischargeSummary.ward = ?";
	private static final String _FINDER_COLUMN_WARD_WARD_3 = "(dischargeSummary.ward IS NULL OR dischargeSummary.ward = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_WARDBED = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByWardBed",
			new String[] { String.class.getName(), String.class.getName() },
			DischargeSummaryModelImpl.WARD_COLUMN_BITMASK |
			DischargeSummaryModelImpl.BEDCLASS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_WARDBED = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByWardBed",
			new String[] { String.class.getName(), String.class.getName() });

	/**
	 * Returns the discharge summary where ward = &#63; and bedClass = &#63; or throws a {@link com.napier.portal.db.NoSuchDischargeSummaryException} if it could not be found.
	 *
	 * @param ward the ward
	 * @param bedClass the bed class
	 * @return the matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByWardBed(String ward, String bedClass)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByWardBed(ward, bedClass);

		if (dischargeSummary == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("ward=");
			msg.append(ward);

			msg.append(", bedClass=");
			msg.append(bedClass);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchDischargeSummaryException(msg.toString());
		}

		return dischargeSummary;
	}

	/**
	 * Returns the discharge summary where ward = &#63; and bedClass = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param ward the ward
	 * @param bedClass the bed class
	 * @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByWardBed(String ward, String bedClass)
		throws SystemException {
		return fetchByWardBed(ward, bedClass, true);
	}

	/**
	 * Returns the discharge summary where ward = &#63; and bedClass = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param ward the ward
	 * @param bedClass the bed class
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByWardBed(String ward, String bedClass,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { ward, bedClass };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_WARDBED,
					finderArgs, this);
		}

		if (result instanceof DischargeSummary) {
			DischargeSummary dischargeSummary = (DischargeSummary)result;

			if (!Validator.equals(ward, dischargeSummary.getWard()) ||
					!Validator.equals(bedClass, dischargeSummary.getBedClass())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

			boolean bindWard = false;

			if (ward == null) {
				query.append(_FINDER_COLUMN_WARDBED_WARD_1);
			}
			else if (ward.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARDBED_WARD_3);
			}
			else {
				bindWard = true;

				query.append(_FINDER_COLUMN_WARDBED_WARD_2);
			}

			boolean bindBedClass = false;

			if (bedClass == null) {
				query.append(_FINDER_COLUMN_WARDBED_BEDCLASS_1);
			}
			else if (bedClass.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARDBED_BEDCLASS_3);
			}
			else {
				bindBedClass = true;

				query.append(_FINDER_COLUMN_WARDBED_BEDCLASS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindWard) {
					qPos.add(ward);
				}

				if (bindBedClass) {
					qPos.add(bedClass);
				}

				List<DischargeSummary> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_WARDBED,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"DischargeSummaryPersistenceImpl.fetchByWardBed(String, String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					DischargeSummary dischargeSummary = list.get(0);

					result = dischargeSummary;

					cacheResult(dischargeSummary);

					if ((dischargeSummary.getWard() == null) ||
							!dischargeSummary.getWard().equals(ward) ||
							(dischargeSummary.getBedClass() == null) ||
							!dischargeSummary.getBedClass().equals(bedClass)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_WARDBED,
							finderArgs, dischargeSummary);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_WARDBED,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (DischargeSummary)result;
		}
	}

	/**
	 * Removes the discharge summary where ward = &#63; and bedClass = &#63; from the database.
	 *
	 * @param ward the ward
	 * @param bedClass the bed class
	 * @return the discharge summary that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary removeByWardBed(String ward, String bedClass)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = findByWardBed(ward, bedClass);

		return remove(dischargeSummary);
	}

	/**
	 * Returns the number of discharge summaries where ward = &#63; and bedClass = &#63;.
	 *
	 * @param ward the ward
	 * @param bedClass the bed class
	 * @return the number of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByWardBed(String ward, String bedClass)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_WARDBED;

		Object[] finderArgs = new Object[] { ward, bedClass };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DISCHARGESUMMARY_WHERE);

			boolean bindWard = false;

			if (ward == null) {
				query.append(_FINDER_COLUMN_WARDBED_WARD_1);
			}
			else if (ward.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARDBED_WARD_3);
			}
			else {
				bindWard = true;

				query.append(_FINDER_COLUMN_WARDBED_WARD_2);
			}

			boolean bindBedClass = false;

			if (bedClass == null) {
				query.append(_FINDER_COLUMN_WARDBED_BEDCLASS_1);
			}
			else if (bedClass.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARDBED_BEDCLASS_3);
			}
			else {
				bindBedClass = true;

				query.append(_FINDER_COLUMN_WARDBED_BEDCLASS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindWard) {
					qPos.add(ward);
				}

				if (bindBedClass) {
					qPos.add(bedClass);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_WARDBED_WARD_1 = "dischargeSummary.ward IS NULL AND ";
	private static final String _FINDER_COLUMN_WARDBED_WARD_2 = "dischargeSummary.ward = ? AND ";
	private static final String _FINDER_COLUMN_WARDBED_WARD_3 = "(dischargeSummary.ward IS NULL OR dischargeSummary.ward = '') AND ";
	private static final String _FINDER_COLUMN_WARDBED_BEDCLASS_1 = "dischargeSummary.bedClass IS NULL";
	private static final String _FINDER_COLUMN_WARDBED_BEDCLASS_2 = "dischargeSummary.bedClass = ?";
	private static final String _FINDER_COLUMN_WARDBED_BEDCLASS_3 = "(dischargeSummary.bedClass IS NULL OR dischargeSummary.bedClass = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_DISCHARGEDATE =
		new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBydischargeDate",
			new String[] {
				Date.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCHARGEDATE =
		new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBydischargeDate",
			new String[] { Date.class.getName() },
			DischargeSummaryModelImpl.DISCHARGEDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DISCHARGEDATE = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBydischargeDate",
			new String[] { Date.class.getName() });

	/**
	 * Returns all the discharge summaries where dischargeDate = &#63;.
	 *
	 * @param dischargeDate the discharge date
	 * @return the matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findBydischargeDate(Date dischargeDate)
		throws SystemException {
		return findBydischargeDate(dischargeDate, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discharge summaries where dischargeDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dischargeDate the discharge date
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @return the range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findBydischargeDate(Date dischargeDate,
		int start, int end) throws SystemException {
		return findBydischargeDate(dischargeDate, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discharge summaries where dischargeDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dischargeDate the discharge date
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findBydischargeDate(Date dischargeDate,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCHARGEDATE;
			finderArgs = new Object[] { dischargeDate };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_DISCHARGEDATE;
			finderArgs = new Object[] {
					dischargeDate,
					
					start, end, orderByComparator
				};
		}

		List<DischargeSummary> list = (List<DischargeSummary>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DischargeSummary dischargeSummary : list) {
				if (!Validator.equals(dischargeDate,
							dischargeSummary.getDischargeDate())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

			boolean bindDischargeDate = false;

			if (dischargeDate == null) {
				query.append(_FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_1);
			}
			else {
				bindDischargeDate = true;

				query.append(_FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDischargeDate) {
					qPos.add(CalendarUtil.getTimestamp(dischargeDate));
				}

				if (!pagination) {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DischargeSummary>(list);
				}
				else {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discharge summary in the ordered set where dischargeDate = &#63;.
	 *
	 * @param dischargeDate the discharge date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findBydischargeDate_First(Date dischargeDate,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchBydischargeDate_First(dischargeDate,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("dischargeDate=");
		msg.append(dischargeDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the first discharge summary in the ordered set where dischargeDate = &#63;.
	 *
	 * @param dischargeDate the discharge date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchBydischargeDate_First(Date dischargeDate,
		OrderByComparator orderByComparator) throws SystemException {
		List<DischargeSummary> list = findBydischargeDate(dischargeDate, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discharge summary in the ordered set where dischargeDate = &#63;.
	 *
	 * @param dischargeDate the discharge date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findBydischargeDate_Last(Date dischargeDate,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchBydischargeDate_Last(dischargeDate,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("dischargeDate=");
		msg.append(dischargeDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the last discharge summary in the ordered set where dischargeDate = &#63;.
	 *
	 * @param dischargeDate the discharge date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchBydischargeDate_Last(Date dischargeDate,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBydischargeDate(dischargeDate);

		if (count == 0) {
			return null;
		}

		List<DischargeSummary> list = findBydischargeDate(dischargeDate,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discharge summaries before and after the current discharge summary in the ordered set where dischargeDate = &#63;.
	 *
	 * @param dischargeSummaryId the primary key of the current discharge summary
	 * @param dischargeDate the discharge date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary[] findBydischargeDate_PrevAndNext(
		long dischargeSummaryId, Date dischargeDate,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = findByPrimaryKey(dischargeSummaryId);

		Session session = null;

		try {
			session = openSession();

			DischargeSummary[] array = new DischargeSummaryImpl[3];

			array[0] = getBydischargeDate_PrevAndNext(session,
					dischargeSummary, dischargeDate, orderByComparator, true);

			array[1] = dischargeSummary;

			array[2] = getBydischargeDate_PrevAndNext(session,
					dischargeSummary, dischargeDate, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DischargeSummary getBydischargeDate_PrevAndNext(Session session,
		DischargeSummary dischargeSummary, Date dischargeDate,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

		boolean bindDischargeDate = false;

		if (dischargeDate == null) {
			query.append(_FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_1);
		}
		else {
			bindDischargeDate = true;

			query.append(_FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindDischargeDate) {
			qPos.add(CalendarUtil.getTimestamp(dischargeDate));
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(dischargeSummary);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DischargeSummary> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discharge summaries where dischargeDate = &#63; from the database.
	 *
	 * @param dischargeDate the discharge date
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBydischargeDate(Date dischargeDate)
		throws SystemException {
		for (DischargeSummary dischargeSummary : findBydischargeDate(
				dischargeDate, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(dischargeSummary);
		}
	}

	/**
	 * Returns the number of discharge summaries where dischargeDate = &#63;.
	 *
	 * @param dischargeDate the discharge date
	 * @return the number of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBydischargeDate(Date dischargeDate)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DISCHARGEDATE;

		Object[] finderArgs = new Object[] { dischargeDate };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCHARGESUMMARY_WHERE);

			boolean bindDischargeDate = false;

			if (dischargeDate == null) {
				query.append(_FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_1);
			}
			else {
				bindDischargeDate = true;

				query.append(_FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDischargeDate) {
					qPos.add(CalendarUtil.getTimestamp(dischargeDate));
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_1 = "dischargeSummary.dischargeDate IS NULL";
	private static final String _FINDER_COLUMN_DISCHARGEDATE_DISCHARGEDATE_2 = "dischargeSummary.dischargeDate = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ADMISSIONDATE =
		new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByadmissionDate",
			new String[] {
				Date.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADMISSIONDATE =
		new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED,
			DischargeSummaryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByadmissionDate",
			new String[] { Date.class.getName() },
			DischargeSummaryModelImpl.ADMISSIONDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ADMISSIONDATE = new FinderPath(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByadmissionDate",
			new String[] { Date.class.getName() });

	/**
	 * Returns all the discharge summaries where admissionDate = &#63;.
	 *
	 * @param admissionDate the admission date
	 * @return the matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByadmissionDate(Date admissionDate)
		throws SystemException {
		return findByadmissionDate(admissionDate, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discharge summaries where admissionDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param admissionDate the admission date
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @return the range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByadmissionDate(Date admissionDate,
		int start, int end) throws SystemException {
		return findByadmissionDate(admissionDate, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discharge summaries where admissionDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param admissionDate the admission date
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findByadmissionDate(Date admissionDate,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADMISSIONDATE;
			finderArgs = new Object[] { admissionDate };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ADMISSIONDATE;
			finderArgs = new Object[] {
					admissionDate,
					
					start, end, orderByComparator
				};
		}

		List<DischargeSummary> list = (List<DischargeSummary>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DischargeSummary dischargeSummary : list) {
				if (!Validator.equals(admissionDate,
							dischargeSummary.getAdmissionDate())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

			boolean bindAdmissionDate = false;

			if (admissionDate == null) {
				query.append(_FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_1);
			}
			else {
				bindAdmissionDate = true;

				query.append(_FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAdmissionDate) {
					qPos.add(CalendarUtil.getTimestamp(admissionDate));
				}

				if (!pagination) {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DischargeSummary>(list);
				}
				else {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discharge summary in the ordered set where admissionDate = &#63;.
	 *
	 * @param admissionDate the admission date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByadmissionDate_First(Date admissionDate,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByadmissionDate_First(admissionDate,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("admissionDate=");
		msg.append(admissionDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the first discharge summary in the ordered set where admissionDate = &#63;.
	 *
	 * @param admissionDate the admission date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByadmissionDate_First(Date admissionDate,
		OrderByComparator orderByComparator) throws SystemException {
		List<DischargeSummary> list = findByadmissionDate(admissionDate, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discharge summary in the ordered set where admissionDate = &#63;.
	 *
	 * @param admissionDate the admission date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByadmissionDate_Last(Date admissionDate,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByadmissionDate_Last(admissionDate,
				orderByComparator);

		if (dischargeSummary != null) {
			return dischargeSummary;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("admissionDate=");
		msg.append(admissionDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDischargeSummaryException(msg.toString());
	}

	/**
	 * Returns the last discharge summary in the ordered set where admissionDate = &#63;.
	 *
	 * @param admissionDate the admission date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByadmissionDate_Last(Date admissionDate,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByadmissionDate(admissionDate);

		if (count == 0) {
			return null;
		}

		List<DischargeSummary> list = findByadmissionDate(admissionDate,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discharge summaries before and after the current discharge summary in the ordered set where admissionDate = &#63;.
	 *
	 * @param dischargeSummaryId the primary key of the current discharge summary
	 * @param admissionDate the admission date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary[] findByadmissionDate_PrevAndNext(
		long dischargeSummaryId, Date admissionDate,
		OrderByComparator orderByComparator)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = findByPrimaryKey(dischargeSummaryId);

		Session session = null;

		try {
			session = openSession();

			DischargeSummary[] array = new DischargeSummaryImpl[3];

			array[0] = getByadmissionDate_PrevAndNext(session,
					dischargeSummary, admissionDate, orderByComparator, true);

			array[1] = dischargeSummary;

			array[2] = getByadmissionDate_PrevAndNext(session,
					dischargeSummary, admissionDate, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DischargeSummary getByadmissionDate_PrevAndNext(Session session,
		DischargeSummary dischargeSummary, Date admissionDate,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCHARGESUMMARY_WHERE);

		boolean bindAdmissionDate = false;

		if (admissionDate == null) {
			query.append(_FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_1);
		}
		else {
			bindAdmissionDate = true;

			query.append(_FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DischargeSummaryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAdmissionDate) {
			qPos.add(CalendarUtil.getTimestamp(admissionDate));
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(dischargeSummary);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DischargeSummary> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discharge summaries where admissionDate = &#63; from the database.
	 *
	 * @param admissionDate the admission date
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByadmissionDate(Date admissionDate)
		throws SystemException {
		for (DischargeSummary dischargeSummary : findByadmissionDate(
				admissionDate, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(dischargeSummary);
		}
	}

	/**
	 * Returns the number of discharge summaries where admissionDate = &#63;.
	 *
	 * @param admissionDate the admission date
	 * @return the number of matching discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByadmissionDate(Date admissionDate)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ADMISSIONDATE;

		Object[] finderArgs = new Object[] { admissionDate };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCHARGESUMMARY_WHERE);

			boolean bindAdmissionDate = false;

			if (admissionDate == null) {
				query.append(_FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_1);
			}
			else {
				bindAdmissionDate = true;

				query.append(_FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAdmissionDate) {
					qPos.add(CalendarUtil.getTimestamp(admissionDate));
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_1 = "dischargeSummary.admissionDate IS NULL";
	private static final String _FINDER_COLUMN_ADMISSIONDATE_ADMISSIONDATE_2 = "dischargeSummary.admissionDate = ?";

	public DischargeSummaryPersistenceImpl() {
		setModelClass(DischargeSummary.class);
	}

	/**
	 * Caches the discharge summary in the entity cache if it is enabled.
	 *
	 * @param dischargeSummary the discharge summary
	 */
	@Override
	public void cacheResult(DischargeSummary dischargeSummary) {
		EntityCacheUtil.putResult(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryImpl.class, dischargeSummary.getPrimaryKey(),
			dischargeSummary);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_BEDCLASS,
			new Object[] { dischargeSummary.getBedClass() }, dischargeSummary);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_WARDBED,
			new Object[] {
				dischargeSummary.getWard(), dischargeSummary.getBedClass()
			}, dischargeSummary);

		dischargeSummary.resetOriginalValues();
	}

	/**
	 * Caches the discharge summaries in the entity cache if it is enabled.
	 *
	 * @param dischargeSummaries the discharge summaries
	 */
	@Override
	public void cacheResult(List<DischargeSummary> dischargeSummaries) {
		for (DischargeSummary dischargeSummary : dischargeSummaries) {
			if (EntityCacheUtil.getResult(
						DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
						DischargeSummaryImpl.class,
						dischargeSummary.getPrimaryKey()) == null) {
				cacheResult(dischargeSummary);
			}
			else {
				dischargeSummary.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all discharge summaries.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(DischargeSummaryImpl.class.getName());
		}

		EntityCacheUtil.clearCache(DischargeSummaryImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the discharge summary.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(DischargeSummary dischargeSummary) {
		EntityCacheUtil.removeResult(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryImpl.class, dischargeSummary.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(dischargeSummary);
	}

	@Override
	public void clearCache(List<DischargeSummary> dischargeSummaries) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (DischargeSummary dischargeSummary : dischargeSummaries) {
			EntityCacheUtil.removeResult(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
				DischargeSummaryImpl.class, dischargeSummary.getPrimaryKey());

			clearUniqueFindersCache(dischargeSummary);
		}
	}

	protected void cacheUniqueFindersCache(DischargeSummary dischargeSummary) {
		if (dischargeSummary.isNew()) {
			Object[] args = new Object[] { dischargeSummary.getBedClass() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_BEDCLASS, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_BEDCLASS, args,
				dischargeSummary);

			args = new Object[] {
					dischargeSummary.getWard(), dischargeSummary.getBedClass()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_WARDBED, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_WARDBED, args,
				dischargeSummary);
		}
		else {
			DischargeSummaryModelImpl dischargeSummaryModelImpl = (DischargeSummaryModelImpl)dischargeSummary;

			if ((dischargeSummaryModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_BEDCLASS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { dischargeSummary.getBedClass() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_BEDCLASS, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_BEDCLASS, args,
					dischargeSummary);
			}

			if ((dischargeSummaryModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_WARDBED.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						dischargeSummary.getWard(),
						dischargeSummary.getBedClass()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_WARDBED, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_WARDBED, args,
					dischargeSummary);
			}
		}
	}

	protected void clearUniqueFindersCache(DischargeSummary dischargeSummary) {
		DischargeSummaryModelImpl dischargeSummaryModelImpl = (DischargeSummaryModelImpl)dischargeSummary;

		Object[] args = new Object[] { dischargeSummary.getBedClass() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BEDCLASS, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_BEDCLASS, args);

		if ((dischargeSummaryModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_BEDCLASS.getColumnBitmask()) != 0) {
			args = new Object[] { dischargeSummaryModelImpl.getOriginalBedClass() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BEDCLASS, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_BEDCLASS, args);
		}

		args = new Object[] {
				dischargeSummary.getWard(), dischargeSummary.getBedClass()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_WARDBED, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_WARDBED, args);

		if ((dischargeSummaryModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_WARDBED.getColumnBitmask()) != 0) {
			args = new Object[] {
					dischargeSummaryModelImpl.getOriginalWard(),
					dischargeSummaryModelImpl.getOriginalBedClass()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_WARDBED, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_WARDBED, args);
		}
	}

	/**
	 * Creates a new discharge summary with the primary key. Does not add the discharge summary to the database.
	 *
	 * @param dischargeSummaryId the primary key for the new discharge summary
	 * @return the new discharge summary
	 */
	@Override
	public DischargeSummary create(long dischargeSummaryId) {
		DischargeSummary dischargeSummary = new DischargeSummaryImpl();

		dischargeSummary.setNew(true);
		dischargeSummary.setPrimaryKey(dischargeSummaryId);

		return dischargeSummary;
	}

	/**
	 * Removes the discharge summary with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param dischargeSummaryId the primary key of the discharge summary
	 * @return the discharge summary that was removed
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary remove(long dischargeSummaryId)
		throws NoSuchDischargeSummaryException, SystemException {
		return remove((Serializable)dischargeSummaryId);
	}

	/**
	 * Removes the discharge summary with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the discharge summary
	 * @return the discharge summary that was removed
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary remove(Serializable primaryKey)
		throws NoSuchDischargeSummaryException, SystemException {
		Session session = null;

		try {
			session = openSession();

			DischargeSummary dischargeSummary = (DischargeSummary)session.get(DischargeSummaryImpl.class,
					primaryKey);

			if (dischargeSummary == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDischargeSummaryException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(dischargeSummary);
		}
		catch (NoSuchDischargeSummaryException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected DischargeSummary removeImpl(DischargeSummary dischargeSummary)
		throws SystemException {
		dischargeSummary = toUnwrappedModel(dischargeSummary);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(dischargeSummary)) {
				dischargeSummary = (DischargeSummary)session.get(DischargeSummaryImpl.class,
						dischargeSummary.getPrimaryKeyObj());
			}

			if (dischargeSummary != null) {
				session.delete(dischargeSummary);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (dischargeSummary != null) {
			clearCache(dischargeSummary);
		}

		return dischargeSummary;
	}

	@Override
	public DischargeSummary updateImpl(
		com.napier.portal.db.model.DischargeSummary dischargeSummary)
		throws SystemException {
		dischargeSummary = toUnwrappedModel(dischargeSummary);

		boolean isNew = dischargeSummary.isNew();

		DischargeSummaryModelImpl dischargeSummaryModelImpl = (DischargeSummaryModelImpl)dischargeSummary;

		Session session = null;

		try {
			session = openSession();

			if (dischargeSummary.isNew()) {
				session.save(dischargeSummary);

				dischargeSummary.setNew(false);
			}
			else {
				session.merge(dischargeSummary);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !DischargeSummaryModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((dischargeSummaryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						dischargeSummaryModelImpl.getOriginalMrNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);

				args = new Object[] { dischargeSummaryModelImpl.getMrNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);
			}

			if ((dischargeSummaryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						dischargeSummaryModelImpl.getOriginalIpNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);

				args = new Object[] { dischargeSummaryModelImpl.getIpNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);
			}

			if ((dischargeSummaryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						dischargeSummaryModelImpl.getOriginalWard()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_WARD, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD,
					args);

				args = new Object[] { dischargeSummaryModelImpl.getWard() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_WARD, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD,
					args);
			}

			if ((dischargeSummaryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCHARGEDATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						dischargeSummaryModelImpl.getOriginalDischargeDate()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DISCHARGEDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCHARGEDATE,
					args);

				args = new Object[] { dischargeSummaryModelImpl.getDischargeDate() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DISCHARGEDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCHARGEDATE,
					args);
			}

			if ((dischargeSummaryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADMISSIONDATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						dischargeSummaryModelImpl.getOriginalAdmissionDate()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ADMISSIONDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADMISSIONDATE,
					args);

				args = new Object[] { dischargeSummaryModelImpl.getAdmissionDate() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ADMISSIONDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADMISSIONDATE,
					args);
			}
		}

		EntityCacheUtil.putResult(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
			DischargeSummaryImpl.class, dischargeSummary.getPrimaryKey(),
			dischargeSummary);

		clearUniqueFindersCache(dischargeSummary);
		cacheUniqueFindersCache(dischargeSummary);

		return dischargeSummary;
	}

	protected DischargeSummary toUnwrappedModel(
		DischargeSummary dischargeSummary) {
		if (dischargeSummary instanceof DischargeSummaryImpl) {
			return dischargeSummary;
		}

		DischargeSummaryImpl dischargeSummaryImpl = new DischargeSummaryImpl();

		dischargeSummaryImpl.setNew(dischargeSummary.isNew());
		dischargeSummaryImpl.setPrimaryKey(dischargeSummary.getPrimaryKey());

		dischargeSummaryImpl.setDischargeSummaryId(dischargeSummary.getDischargeSummaryId());
		dischargeSummaryImpl.setMrNumber(dischargeSummary.getMrNumber());
		dischargeSummaryImpl.setIpNumber(dischargeSummary.getIpNumber());
		dischargeSummaryImpl.setDocPath(dischargeSummary.getDocPath());
		dischargeSummaryImpl.setDepartmentName(dischargeSummary.getDepartmentName());
		dischargeSummaryImpl.setStatus(dischargeSummary.isStatus());
		dischargeSummaryImpl.setWard(dischargeSummary.getWard());
		dischargeSummaryImpl.setBedClass(dischargeSummary.getBedClass());
		dischargeSummaryImpl.setDischargeDate(dischargeSummary.getDischargeDate());
		dischargeSummaryImpl.setAdmissionDate(dischargeSummary.getAdmissionDate());
		dischargeSummaryImpl.setPrimaryDoctor(dischargeSummary.getPrimaryDoctor());
		dischargeSummaryImpl.setChiefComplaint(dischargeSummary.getChiefComplaint());

		return dischargeSummaryImpl;
	}

	/**
	 * Returns the discharge summary with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the discharge summary
	 * @return the discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDischargeSummaryException, SystemException {
		DischargeSummary dischargeSummary = fetchByPrimaryKey(primaryKey);

		if (dischargeSummary == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDischargeSummaryException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return dischargeSummary;
	}

	/**
	 * Returns the discharge summary with the primary key or throws a {@link com.napier.portal.db.NoSuchDischargeSummaryException} if it could not be found.
	 *
	 * @param dischargeSummaryId the primary key of the discharge summary
	 * @return the discharge summary
	 * @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary findByPrimaryKey(long dischargeSummaryId)
		throws NoSuchDischargeSummaryException, SystemException {
		return findByPrimaryKey((Serializable)dischargeSummaryId);
	}

	/**
	 * Returns the discharge summary with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the discharge summary
	 * @return the discharge summary, or <code>null</code> if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		DischargeSummary dischargeSummary = (DischargeSummary)EntityCacheUtil.getResult(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
				DischargeSummaryImpl.class, primaryKey);

		if (dischargeSummary == _nullDischargeSummary) {
			return null;
		}

		if (dischargeSummary == null) {
			Session session = null;

			try {
				session = openSession();

				dischargeSummary = (DischargeSummary)session.get(DischargeSummaryImpl.class,
						primaryKey);

				if (dischargeSummary != null) {
					cacheResult(dischargeSummary);
				}
				else {
					EntityCacheUtil.putResult(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
						DischargeSummaryImpl.class, primaryKey,
						_nullDischargeSummary);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(DischargeSummaryModelImpl.ENTITY_CACHE_ENABLED,
					DischargeSummaryImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return dischargeSummary;
	}

	/**
	 * Returns the discharge summary with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param dischargeSummaryId the primary key of the discharge summary
	 * @return the discharge summary, or <code>null</code> if a discharge summary with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DischargeSummary fetchByPrimaryKey(long dischargeSummaryId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)dischargeSummaryId);
	}

	/**
	 * Returns all the discharge summaries.
	 *
	 * @return the discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discharge summaries.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @return the range of discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the discharge summaries.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of discharge summaries
	 * @param end the upper bound of the range of discharge summaries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DischargeSummary> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<DischargeSummary> list = (List<DischargeSummary>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_DISCHARGESUMMARY);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DISCHARGESUMMARY;

				if (pagination) {
					sql = sql.concat(DischargeSummaryModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DischargeSummary>(list);
				}
				else {
					list = (List<DischargeSummary>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the discharge summaries from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (DischargeSummary dischargeSummary : findAll()) {
			remove(dischargeSummary);
		}
	}

	/**
	 * Returns the number of discharge summaries.
	 *
	 * @return the number of discharge summaries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DISCHARGESUMMARY);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the discharge summary persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.DischargeSummary")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<DischargeSummary>> listenersList = new ArrayList<ModelListener<DischargeSummary>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<DischargeSummary>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(DischargeSummaryImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_DISCHARGESUMMARY = "SELECT dischargeSummary FROM DischargeSummary dischargeSummary";
	private static final String _SQL_SELECT_DISCHARGESUMMARY_WHERE = "SELECT dischargeSummary FROM DischargeSummary dischargeSummary WHERE ";
	private static final String _SQL_COUNT_DISCHARGESUMMARY = "SELECT COUNT(dischargeSummary) FROM DischargeSummary dischargeSummary";
	private static final String _SQL_COUNT_DISCHARGESUMMARY_WHERE = "SELECT COUNT(dischargeSummary) FROM DischargeSummary dischargeSummary WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "dischargeSummary.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No DischargeSummary exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No DischargeSummary exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(DischargeSummaryPersistenceImpl.class);
	private static DischargeSummary _nullDischargeSummary = new DischargeSummaryImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<DischargeSummary> toCacheModel() {
				return _nullDischargeSummaryCacheModel;
			}
		};

	private static CacheModel<DischargeSummary> _nullDischargeSummaryCacheModel = new CacheModel<DischargeSummary>() {
			@Override
			public DischargeSummary toEntityModel() {
				return _nullDischargeSummary;
			}
		};
}