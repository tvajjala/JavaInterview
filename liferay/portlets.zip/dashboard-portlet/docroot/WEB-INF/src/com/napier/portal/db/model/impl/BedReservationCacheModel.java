/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.BedReservation;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing BedReservation in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see BedReservation
 * @generated
 */
public class BedReservationCacheModel implements CacheModel<BedReservation>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{bedReservationId=");
		sb.append(bedReservationId);
		sb.append(", bedClass=");
		sb.append(bedClass);
		sb.append(", ward=");
		sb.append(ward);
		sb.append(", totalBedCount=");
		sb.append(totalBedCount);
		sb.append(", vacantBedCount=");
		sb.append(vacantBedCount);
		sb.append(", hospitalTariff=");
		sb.append(hospitalTariff);
		sb.append(", gender=");
		sb.append(gender);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public BedReservation toEntityModel() {
		BedReservationImpl bedReservationImpl = new BedReservationImpl();

		bedReservationImpl.setBedReservationId(bedReservationId);

		if (bedClass == null) {
			bedReservationImpl.setBedClass(StringPool.BLANK);
		}
		else {
			bedReservationImpl.setBedClass(bedClass);
		}

		if (ward == null) {
			bedReservationImpl.setWard(StringPool.BLANK);
		}
		else {
			bedReservationImpl.setWard(ward);
		}

		bedReservationImpl.setTotalBedCount(totalBedCount);
		bedReservationImpl.setVacantBedCount(vacantBedCount);
		bedReservationImpl.setHospitalTariff(hospitalTariff);

		if (gender == null) {
			bedReservationImpl.setGender(StringPool.BLANK);
		}
		else {
			bedReservationImpl.setGender(gender);
		}

		bedReservationImpl.resetOriginalValues();

		return bedReservationImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		bedReservationId = objectInput.readLong();
		bedClass = objectInput.readUTF();
		ward = objectInput.readUTF();
		totalBedCount = objectInput.readInt();
		vacantBedCount = objectInput.readInt();
		hospitalTariff = objectInput.readDouble();
		gender = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(bedReservationId);

		if (bedClass == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bedClass);
		}

		if (ward == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ward);
		}

		objectOutput.writeInt(totalBedCount);
		objectOutput.writeInt(vacantBedCount);
		objectOutput.writeDouble(hospitalTariff);

		if (gender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(gender);
		}
	}

	public long bedReservationId;
	public String bedClass;
	public String ward;
	public int totalBedCount;
	public int vacantBedCount;
	public double hospitalTariff;
	public String gender;
}