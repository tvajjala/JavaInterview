/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.PatientBill;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing PatientBill in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see PatientBill
 * @generated
 */
public class PatientBillCacheModel implements CacheModel<PatientBill>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{patientBillId=");
		sb.append(patientBillId);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", ipNumber=");
		sb.append(ipNumber);
		sb.append(", billNumber=");
		sb.append(billNumber);
		sb.append(", company=");
		sb.append(company);
		sb.append(", sponser=");
		sb.append(sponser);
		sb.append(", planName=");
		sb.append(planName);
		sb.append(", planExpiry=");
		sb.append(planExpiry);
		sb.append(", admissionDate=");
		sb.append(admissionDate);
		sb.append(", isBillgenerated=");
		sb.append(isBillgenerated);
		sb.append(", isBalanceAmount=");
		sb.append(isBalanceAmount);
		sb.append(", billAmount=");
		sb.append(billAmount);
		sb.append(", paidAmount=");
		sb.append(paidAmount);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public PatientBill toEntityModel() {
		PatientBillImpl patientBillImpl = new PatientBillImpl();

		patientBillImpl.setPatientBillId(patientBillId);

		if (mrNumber == null) {
			patientBillImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			patientBillImpl.setMrNumber(mrNumber);
		}

		if (ipNumber == null) {
			patientBillImpl.setIpNumber(StringPool.BLANK);
		}
		else {
			patientBillImpl.setIpNumber(ipNumber);
		}

		if (billNumber == null) {
			patientBillImpl.setBillNumber(StringPool.BLANK);
		}
		else {
			patientBillImpl.setBillNumber(billNumber);
		}

		if (company == null) {
			patientBillImpl.setCompany(StringPool.BLANK);
		}
		else {
			patientBillImpl.setCompany(company);
		}

		if (sponser == null) {
			patientBillImpl.setSponser(StringPool.BLANK);
		}
		else {
			patientBillImpl.setSponser(sponser);
		}

		if (planName == null) {
			patientBillImpl.setPlanName(StringPool.BLANK);
		}
		else {
			patientBillImpl.setPlanName(planName);
		}

		if (planExpiry == Long.MIN_VALUE) {
			patientBillImpl.setPlanExpiry(null);
		}
		else {
			patientBillImpl.setPlanExpiry(new Date(planExpiry));
		}

		if (admissionDate == Long.MIN_VALUE) {
			patientBillImpl.setAdmissionDate(null);
		}
		else {
			patientBillImpl.setAdmissionDate(new Date(admissionDate));
		}

		patientBillImpl.setIsBillgenerated(isBillgenerated);
		patientBillImpl.setIsBalanceAmount(isBalanceAmount);
		patientBillImpl.setBillAmount(billAmount);
		patientBillImpl.setPaidAmount(paidAmount);

		patientBillImpl.resetOriginalValues();

		return patientBillImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		patientBillId = objectInput.readLong();
		mrNumber = objectInput.readUTF();
		ipNumber = objectInput.readUTF();
		billNumber = objectInput.readUTF();
		company = objectInput.readUTF();
		sponser = objectInput.readUTF();
		planName = objectInput.readUTF();
		planExpiry = objectInput.readLong();
		admissionDate = objectInput.readLong();
		isBillgenerated = objectInput.readBoolean();
		isBalanceAmount = objectInput.readBoolean();
		billAmount = objectInput.readDouble();
		paidAmount = objectInput.readDouble();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(patientBillId);

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		if (ipNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ipNumber);
		}

		if (billNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(billNumber);
		}

		if (company == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(company);
		}

		if (sponser == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(sponser);
		}

		if (planName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(planName);
		}

		objectOutput.writeLong(planExpiry);
		objectOutput.writeLong(admissionDate);
		objectOutput.writeBoolean(isBillgenerated);
		objectOutput.writeBoolean(isBalanceAmount);
		objectOutput.writeDouble(billAmount);
		objectOutput.writeDouble(paidAmount);
	}

	public long patientBillId;
	public String mrNumber;
	public String ipNumber;
	public String billNumber;
	public String company;
	public String sponser;
	public String planName;
	public long planExpiry;
	public long admissionDate;
	public boolean isBillgenerated;
	public boolean isBalanceAmount;
	public double billAmount;
	public double paidAmount;
}