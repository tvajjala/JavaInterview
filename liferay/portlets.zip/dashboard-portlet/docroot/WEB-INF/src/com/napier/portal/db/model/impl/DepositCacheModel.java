/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.Deposit;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Deposit in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see Deposit
 * @generated
 */
public class DepositCacheModel implements CacheModel<Deposit>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{depositId=");
		sb.append(depositId);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", ipNumber=");
		sb.append(ipNumber);
		sb.append(", depositNumber=");
		sb.append(depositNumber);
		sb.append(", depositAmount=");
		sb.append(depositAmount);
		sb.append(", depositAgainst=");
		sb.append(depositAgainst);
		sb.append(", depositDate=");
		sb.append(depositDate);
		sb.append(", patientBillId=");
		sb.append(patientBillId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Deposit toEntityModel() {
		DepositImpl depositImpl = new DepositImpl();

		depositImpl.setDepositId(depositId);

		if (mrNumber == null) {
			depositImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			depositImpl.setMrNumber(mrNumber);
		}

		if (ipNumber == null) {
			depositImpl.setIpNumber(StringPool.BLANK);
		}
		else {
			depositImpl.setIpNumber(ipNumber);
		}

		if (depositNumber == null) {
			depositImpl.setDepositNumber(StringPool.BLANK);
		}
		else {
			depositImpl.setDepositNumber(depositNumber);
		}

		depositImpl.setDepositAmount(depositAmount);

		if (depositAgainst == null) {
			depositImpl.setDepositAgainst(StringPool.BLANK);
		}
		else {
			depositImpl.setDepositAgainst(depositAgainst);
		}

		if (depositDate == Long.MIN_VALUE) {
			depositImpl.setDepositDate(null);
		}
		else {
			depositImpl.setDepositDate(new Date(depositDate));
		}

		depositImpl.setPatientBillId(patientBillId);

		depositImpl.resetOriginalValues();

		return depositImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		depositId = objectInput.readLong();
		mrNumber = objectInput.readUTF();
		ipNumber = objectInput.readUTF();
		depositNumber = objectInput.readUTF();
		depositAmount = objectInput.readDouble();
		depositAgainst = objectInput.readUTF();
		depositDate = objectInput.readLong();
		patientBillId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(depositId);

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		if (ipNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ipNumber);
		}

		if (depositNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(depositNumber);
		}

		objectOutput.writeDouble(depositAmount);

		if (depositAgainst == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(depositAgainst);
		}

		objectOutput.writeLong(depositDate);
		objectOutput.writeLong(patientBillId);
	}

	public long depositId;
	public String mrNumber;
	public String ipNumber;
	public String depositNumber;
	public double depositAmount;
	public String depositAgainst;
	public long depositDate;
	public long patientBillId;
}