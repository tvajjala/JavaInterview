/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.BedAllocation;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing BedAllocation in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see BedAllocation
 * @generated
 */
public class BedAllocationCacheModel implements CacheModel<BedAllocation>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{bedAllocationId=");
		sb.append(bedAllocationId);
		sb.append(", bedReservationNumber=");
		sb.append(bedReservationNumber);
		sb.append(", bedReservationDate=");
		sb.append(bedReservationDate);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", ipNumber=");
		sb.append(ipNumber);
		sb.append(", bedNumber=");
		sb.append(bedNumber);
		sb.append(", joiningDate=");
		sb.append(joiningDate);
		sb.append(", admissionDate=");
		sb.append(admissionDate);
		sb.append(", patientName=");
		sb.append(patientName);
		sb.append(", age=");
		sb.append(age);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", mobile=");
		sb.append(mobile);
		sb.append(", email=");
		sb.append(email);
		sb.append(", status=");
		sb.append(status);
		sb.append(", createdUserId=");
		sb.append(createdUserId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public BedAllocation toEntityModel() {
		BedAllocationImpl bedAllocationImpl = new BedAllocationImpl();

		bedAllocationImpl.setBedAllocationId(bedAllocationId);

		if (bedReservationNumber == null) {
			bedAllocationImpl.setBedReservationNumber(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setBedReservationNumber(bedReservationNumber);
		}

		if (bedReservationDate == Long.MIN_VALUE) {
			bedAllocationImpl.setBedReservationDate(null);
		}
		else {
			bedAllocationImpl.setBedReservationDate(new Date(bedReservationDate));
		}

		if (mrNumber == null) {
			bedAllocationImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setMrNumber(mrNumber);
		}

		if (ipNumber == null) {
			bedAllocationImpl.setIpNumber(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setIpNumber(ipNumber);
		}

		if (bedNumber == null) {
			bedAllocationImpl.setBedNumber(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setBedNumber(bedNumber);
		}

		if (joiningDate == Long.MIN_VALUE) {
			bedAllocationImpl.setJoiningDate(null);
		}
		else {
			bedAllocationImpl.setJoiningDate(new Date(joiningDate));
		}

		if (admissionDate == Long.MIN_VALUE) {
			bedAllocationImpl.setAdmissionDate(null);
		}
		else {
			bedAllocationImpl.setAdmissionDate(new Date(admissionDate));
		}

		if (patientName == null) {
			bedAllocationImpl.setPatientName(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setPatientName(patientName);
		}

		bedAllocationImpl.setAge(age);

		if (gender == null) {
			bedAllocationImpl.setGender(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setGender(gender);
		}

		if (mobile == null) {
			bedAllocationImpl.setMobile(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setMobile(mobile);
		}

		if (email == null) {
			bedAllocationImpl.setEmail(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setEmail(email);
		}

		if (status == null) {
			bedAllocationImpl.setStatus(StringPool.BLANK);
		}
		else {
			bedAllocationImpl.setStatus(status);
		}

		bedAllocationImpl.setCreatedUserId(createdUserId);

		bedAllocationImpl.resetOriginalValues();

		return bedAllocationImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		bedAllocationId = objectInput.readLong();
		bedReservationNumber = objectInput.readUTF();
		bedReservationDate = objectInput.readLong();
		mrNumber = objectInput.readUTF();
		ipNumber = objectInput.readUTF();
		bedNumber = objectInput.readUTF();
		joiningDate = objectInput.readLong();
		admissionDate = objectInput.readLong();
		patientName = objectInput.readUTF();
		age = objectInput.readInt();
		gender = objectInput.readUTF();
		mobile = objectInput.readUTF();
		email = objectInput.readUTF();
		status = objectInput.readUTF();
		createdUserId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(bedAllocationId);

		if (bedReservationNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bedReservationNumber);
		}

		objectOutput.writeLong(bedReservationDate);

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		if (ipNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ipNumber);
		}

		if (bedNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bedNumber);
		}

		objectOutput.writeLong(joiningDate);
		objectOutput.writeLong(admissionDate);

		if (patientName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(patientName);
		}

		objectOutput.writeInt(age);

		if (gender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(gender);
		}

		if (mobile == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mobile);
		}

		if (email == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (status == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(status);
		}

		objectOutput.writeLong(createdUserId);
	}

	public long bedAllocationId;
	public String bedReservationNumber;
	public long bedReservationDate;
	public String mrNumber;
	public String ipNumber;
	public String bedNumber;
	public long joiningDate;
	public long admissionDate;
	public String patientName;
	public int age;
	public String gender;
	public String mobile;
	public String email;
	public String status;
	public long createdUserId;
}