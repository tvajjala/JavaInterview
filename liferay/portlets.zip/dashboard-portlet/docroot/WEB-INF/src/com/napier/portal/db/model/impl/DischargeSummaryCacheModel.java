/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.DischargeSummary;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing DischargeSummary in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see DischargeSummary
 * @generated
 */
public class DischargeSummaryCacheModel implements CacheModel<DischargeSummary>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(25);

		sb.append("{dischargeSummaryId=");
		sb.append(dischargeSummaryId);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", ipNumber=");
		sb.append(ipNumber);
		sb.append(", docPath=");
		sb.append(docPath);
		sb.append(", departmentName=");
		sb.append(departmentName);
		sb.append(", status=");
		sb.append(status);
		sb.append(", ward=");
		sb.append(ward);
		sb.append(", bedClass=");
		sb.append(bedClass);
		sb.append(", dischargeDate=");
		sb.append(dischargeDate);
		sb.append(", admissionDate=");
		sb.append(admissionDate);
		sb.append(", primaryDoctor=");
		sb.append(primaryDoctor);
		sb.append(", chiefComplaint=");
		sb.append(chiefComplaint);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public DischargeSummary toEntityModel() {
		DischargeSummaryImpl dischargeSummaryImpl = new DischargeSummaryImpl();

		dischargeSummaryImpl.setDischargeSummaryId(dischargeSummaryId);

		if (mrNumber == null) {
			dischargeSummaryImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setMrNumber(mrNumber);
		}

		if (ipNumber == null) {
			dischargeSummaryImpl.setIpNumber(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setIpNumber(ipNumber);
		}

		if (docPath == null) {
			dischargeSummaryImpl.setDocPath(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setDocPath(docPath);
		}

		if (departmentName == null) {
			dischargeSummaryImpl.setDepartmentName(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setDepartmentName(departmentName);
		}

		dischargeSummaryImpl.setStatus(status);

		if (ward == null) {
			dischargeSummaryImpl.setWard(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setWard(ward);
		}

		if (bedClass == null) {
			dischargeSummaryImpl.setBedClass(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setBedClass(bedClass);
		}

		if (dischargeDate == Long.MIN_VALUE) {
			dischargeSummaryImpl.setDischargeDate(null);
		}
		else {
			dischargeSummaryImpl.setDischargeDate(new Date(dischargeDate));
		}

		if (admissionDate == Long.MIN_VALUE) {
			dischargeSummaryImpl.setAdmissionDate(null);
		}
		else {
			dischargeSummaryImpl.setAdmissionDate(new Date(admissionDate));
		}

		if (primaryDoctor == null) {
			dischargeSummaryImpl.setPrimaryDoctor(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setPrimaryDoctor(primaryDoctor);
		}

		if (chiefComplaint == null) {
			dischargeSummaryImpl.setChiefComplaint(StringPool.BLANK);
		}
		else {
			dischargeSummaryImpl.setChiefComplaint(chiefComplaint);
		}

		dischargeSummaryImpl.resetOriginalValues();

		return dischargeSummaryImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		dischargeSummaryId = objectInput.readLong();
		mrNumber = objectInput.readUTF();
		ipNumber = objectInput.readUTF();
		docPath = objectInput.readUTF();
		departmentName = objectInput.readUTF();
		status = objectInput.readBoolean();
		ward = objectInput.readUTF();
		bedClass = objectInput.readUTF();
		dischargeDate = objectInput.readLong();
		admissionDate = objectInput.readLong();
		primaryDoctor = objectInput.readUTF();
		chiefComplaint = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(dischargeSummaryId);

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		if (ipNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ipNumber);
		}

		if (docPath == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(docPath);
		}

		if (departmentName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(departmentName);
		}

		objectOutput.writeBoolean(status);

		if (ward == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ward);
		}

		if (bedClass == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bedClass);
		}

		objectOutput.writeLong(dischargeDate);
		objectOutput.writeLong(admissionDate);

		if (primaryDoctor == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(primaryDoctor);
		}

		if (chiefComplaint == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(chiefComplaint);
		}
	}

	public long dischargeSummaryId;
	public String mrNumber;
	public String ipNumber;
	public String docPath;
	public String departmentName;
	public boolean status;
	public String ward;
	public String bedClass;
	public long dischargeDate;
	public long admissionDate;
	public String primaryDoctor;
	public String chiefComplaint;
}