/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.impl;

import java.util.List;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.napier.portal.db.model.BedReservation;
import com.napier.portal.db.service.base.BedReservationLocalServiceBaseImpl;
import com.napier.portal.db.service.persistence.BedReservationUtil;

/**
 * The implementation of the bed reservation local service.
 * 
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the
 * {@link com.napier.portal.db.service.BedReservationLocalService} interface.
 * 
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 * </p>
 * 
 * @author Brian Wing Shun Chan
 * @see com.napier.portal.db.service.base.BedReservationLocalServiceBaseImpl
 * @see com.napier.portal.db.service.BedReservationLocalServiceUtil
 */
public class BedReservationLocalServiceImpl extends BedReservationLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     * 
     * Never reference this interface directly. Always use {@link com.napier.portal.db.service.BedReservationLocalServiceUtil} to access the bed reservation
     * local service.
     */

    public List<BedReservation> getAll() throws SystemException {

        return BedReservationUtil.findAll();
    }

    public List<BedReservation> getBybedClass(String bedClass) throws SystemException {

        return BedReservationUtil.findBybedClass(bedClass);
    }

    public List<BedReservation> getBybedClass(String bedClass, int start, int end) throws SystemException {

        return BedReservationUtil.findBybedClass(bedClass, start, end);
    }

    public List<BedReservation> getBybedClass(String bedClass, int start, int end, OrderByComparator orderByComparator) throws SystemException {

        return BedReservationUtil.findBybedClass(bedClass, start, end, orderByComparator);
    }
}