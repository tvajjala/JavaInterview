/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.NapierUser;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing NapierUser in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see NapierUser
 * @generated
 */
public class NapierUserCacheModel implements CacheModel<NapierUser>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(35);

		sb.append("{napierUserId=");
		sb.append(napierUserId);
		sb.append(", portalUserId=");
		sb.append(portalUserId);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", tpaId=");
		sb.append(tpaId);
		sb.append(", coroporateId=");
		sb.append(coroporateId);
		sb.append(", doctorId=");
		sb.append(doctorId);
		sb.append(", age=");
		sb.append(age);
		sb.append(", mobile=");
		sb.append(mobile);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", specialization=");
		sb.append(specialization);
		sb.append(", userType=");
		sb.append(userType);
		sb.append(", email=");
		sb.append(email);
		sb.append(", name=");
		sb.append(name);
		sb.append(", address=");
		sb.append(address);
		sb.append(", street1=");
		sb.append(street1);
		sb.append(", street2=");
		sb.append(street2);
		sb.append(", postalCode=");
		sb.append(postalCode);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public NapierUser toEntityModel() {
		NapierUserImpl napierUserImpl = new NapierUserImpl();

		napierUserImpl.setNapierUserId(napierUserId);
		napierUserImpl.setPortalUserId(portalUserId);

		if (mrNumber == null) {
			napierUserImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			napierUserImpl.setMrNumber(mrNumber);
		}

		if (tpaId == null) {
			napierUserImpl.setTpaId(StringPool.BLANK);
		}
		else {
			napierUserImpl.setTpaId(tpaId);
		}

		if (coroporateId == null) {
			napierUserImpl.setCoroporateId(StringPool.BLANK);
		}
		else {
			napierUserImpl.setCoroporateId(coroporateId);
		}

		if (doctorId == null) {
			napierUserImpl.setDoctorId(StringPool.BLANK);
		}
		else {
			napierUserImpl.setDoctorId(doctorId);
		}

		napierUserImpl.setAge(age);

		if (mobile == null) {
			napierUserImpl.setMobile(StringPool.BLANK);
		}
		else {
			napierUserImpl.setMobile(mobile);
		}

		if (gender == null) {
			napierUserImpl.setGender(StringPool.BLANK);
		}
		else {
			napierUserImpl.setGender(gender);
		}

		if (specialization == null) {
			napierUserImpl.setSpecialization(StringPool.BLANK);
		}
		else {
			napierUserImpl.setSpecialization(specialization);
		}

		if (userType == null) {
			napierUserImpl.setUserType(StringPool.BLANK);
		}
		else {
			napierUserImpl.setUserType(userType);
		}

		if (email == null) {
			napierUserImpl.setEmail(StringPool.BLANK);
		}
		else {
			napierUserImpl.setEmail(email);
		}

		if (name == null) {
			napierUserImpl.setName(StringPool.BLANK);
		}
		else {
			napierUserImpl.setName(name);
		}

		if (address == null) {
			napierUserImpl.setAddress(StringPool.BLANK);
		}
		else {
			napierUserImpl.setAddress(address);
		}

		if (street1 == null) {
			napierUserImpl.setStreet1(StringPool.BLANK);
		}
		else {
			napierUserImpl.setStreet1(street1);
		}

		if (street2 == null) {
			napierUserImpl.setStreet2(StringPool.BLANK);
		}
		else {
			napierUserImpl.setStreet2(street2);
		}

		if (postalCode == null) {
			napierUserImpl.setPostalCode(StringPool.BLANK);
		}
		else {
			napierUserImpl.setPostalCode(postalCode);
		}

		napierUserImpl.resetOriginalValues();

		return napierUserImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		napierUserId = objectInput.readLong();
		portalUserId = objectInput.readLong();
		mrNumber = objectInput.readUTF();
		tpaId = objectInput.readUTF();
		coroporateId = objectInput.readUTF();
		doctorId = objectInput.readUTF();
		age = objectInput.readInt();
		mobile = objectInput.readUTF();
		gender = objectInput.readUTF();
		specialization = objectInput.readUTF();
		userType = objectInput.readUTF();
		email = objectInput.readUTF();
		name = objectInput.readUTF();
		address = objectInput.readUTF();
		street1 = objectInput.readUTF();
		street2 = objectInput.readUTF();
		postalCode = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(napierUserId);
		objectOutput.writeLong(portalUserId);

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		if (tpaId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(tpaId);
		}

		if (coroporateId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(coroporateId);
		}

		if (doctorId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(doctorId);
		}

		objectOutput.writeInt(age);

		if (mobile == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mobile);
		}

		if (gender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(gender);
		}

		if (specialization == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(specialization);
		}

		if (userType == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userType);
		}

		if (email == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (name == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(name);
		}

		if (address == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(address);
		}

		if (street1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(street1);
		}

		if (street2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(street2);
		}

		if (postalCode == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(postalCode);
		}
	}

	public long napierUserId;
	public long portalUserId;
	public String mrNumber;
	public String tpaId;
	public String coroporateId;
	public String doctorId;
	public int age;
	public String mobile;
	public String gender;
	public String specialization;
	public String userType;
	public String email;
	public String name;
	public String address;
	public String street1;
	public String street2;
	public String postalCode;
}