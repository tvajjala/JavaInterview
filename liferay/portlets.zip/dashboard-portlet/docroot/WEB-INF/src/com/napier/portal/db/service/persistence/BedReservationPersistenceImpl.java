/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchBedReservationException;
import com.napier.portal.db.model.BedReservation;
import com.napier.portal.db.model.impl.BedReservationImpl;
import com.napier.portal.db.model.impl.BedReservationModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the bed reservation service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see BedReservationPersistence
 * @see BedReservationUtil
 * @generated
 */
public class BedReservationPersistenceImpl extends BasePersistenceImpl<BedReservation>
	implements BedReservationPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link BedReservationUtil} to access the bed reservation persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = BedReservationImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED,
			BedReservationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED,
			BedReservationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BEDCLASS = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED,
			BedReservationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBybedClass",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BEDCLASS =
		new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED,
			BedReservationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybedClass",
			new String[] { String.class.getName() },
			BedReservationModelImpl.BEDCLASS_COLUMN_BITMASK |
			BedReservationModelImpl.HOSPITALTARIFF_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BEDCLASS = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybedClass",
			new String[] { String.class.getName() });

	/**
	 * Returns all the bed reservations where bedClass = &#63;.
	 *
	 * @param bedClass the bed class
	 * @return the matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findBybedClass(String bedClass)
		throws SystemException {
		return findBybedClass(bedClass, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the bed reservations where bedClass = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bedClass the bed class
	 * @param start the lower bound of the range of bed reservations
	 * @param end the upper bound of the range of bed reservations (not inclusive)
	 * @return the range of matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findBybedClass(String bedClass, int start,
		int end) throws SystemException {
		return findBybedClass(bedClass, start, end, null);
	}

	/**
	 * Returns an ordered range of all the bed reservations where bedClass = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bedClass the bed class
	 * @param start the lower bound of the range of bed reservations
	 * @param end the upper bound of the range of bed reservations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findBybedClass(String bedClass, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BEDCLASS;
			finderArgs = new Object[] { bedClass };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BEDCLASS;
			finderArgs = new Object[] { bedClass, start, end, orderByComparator };
		}

		List<BedReservation> list = (List<BedReservation>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (BedReservation bedReservation : list) {
				if (!Validator.equals(bedClass, bedReservation.getBedClass())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_BEDRESERVATION_WHERE);

			boolean bindBedClass = false;

			if (bedClass == null) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_1);
			}
			else if (bedClass.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_3);
			}
			else {
				bindBedClass = true;

				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(BedReservationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindBedClass) {
					qPos.add(bedClass);
				}

				if (!pagination) {
					list = (List<BedReservation>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BedReservation>(list);
				}
				else {
					list = (List<BedReservation>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first bed reservation in the ordered set where bedClass = &#63;.
	 *
	 * @param bedClass the bed class
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation findBybedClass_First(String bedClass,
		OrderByComparator orderByComparator)
		throws NoSuchBedReservationException, SystemException {
		BedReservation bedReservation = fetchBybedClass_First(bedClass,
				orderByComparator);

		if (bedReservation != null) {
			return bedReservation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bedClass=");
		msg.append(bedClass);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedReservationException(msg.toString());
	}

	/**
	 * Returns the first bed reservation in the ordered set where bedClass = &#63;.
	 *
	 * @param bedClass the bed class
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation fetchBybedClass_First(String bedClass,
		OrderByComparator orderByComparator) throws SystemException {
		List<BedReservation> list = findBybedClass(bedClass, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last bed reservation in the ordered set where bedClass = &#63;.
	 *
	 * @param bedClass the bed class
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation findBybedClass_Last(String bedClass,
		OrderByComparator orderByComparator)
		throws NoSuchBedReservationException, SystemException {
		BedReservation bedReservation = fetchBybedClass_Last(bedClass,
				orderByComparator);

		if (bedReservation != null) {
			return bedReservation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bedClass=");
		msg.append(bedClass);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedReservationException(msg.toString());
	}

	/**
	 * Returns the last bed reservation in the ordered set where bedClass = &#63;.
	 *
	 * @param bedClass the bed class
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation fetchBybedClass_Last(String bedClass,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybedClass(bedClass);

		if (count == 0) {
			return null;
		}

		List<BedReservation> list = findBybedClass(bedClass, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the bed reservations before and after the current bed reservation in the ordered set where bedClass = &#63;.
	 *
	 * @param bedReservationId the primary key of the current bed reservation
	 * @param bedClass the bed class
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation[] findBybedClass_PrevAndNext(long bedReservationId,
		String bedClass, OrderByComparator orderByComparator)
		throws NoSuchBedReservationException, SystemException {
		BedReservation bedReservation = findByPrimaryKey(bedReservationId);

		Session session = null;

		try {
			session = openSession();

			BedReservation[] array = new BedReservationImpl[3];

			array[0] = getBybedClass_PrevAndNext(session, bedReservation,
					bedClass, orderByComparator, true);

			array[1] = bedReservation;

			array[2] = getBybedClass_PrevAndNext(session, bedReservation,
					bedClass, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected BedReservation getBybedClass_PrevAndNext(Session session,
		BedReservation bedReservation, String bedClass,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_BEDRESERVATION_WHERE);

		boolean bindBedClass = false;

		if (bedClass == null) {
			query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_1);
		}
		else if (bedClass.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_3);
		}
		else {
			bindBedClass = true;

			query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(BedReservationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindBedClass) {
			qPos.add(bedClass);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(bedReservation);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<BedReservation> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the bed reservations where bedClass = &#63; from the database.
	 *
	 * @param bedClass the bed class
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybedClass(String bedClass) throws SystemException {
		for (BedReservation bedReservation : findBybedClass(bedClass,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(bedReservation);
		}
	}

	/**
	 * Returns the number of bed reservations where bedClass = &#63;.
	 *
	 * @param bedClass the bed class
	 * @return the number of matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybedClass(String bedClass) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BEDCLASS;

		Object[] finderArgs = new Object[] { bedClass };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_BEDRESERVATION_WHERE);

			boolean bindBedClass = false;

			if (bedClass == null) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_1);
			}
			else if (bedClass.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_3);
			}
			else {
				bindBedClass = true;

				query.append(_FINDER_COLUMN_BEDCLASS_BEDCLASS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindBedClass) {
					qPos.add(bedClass);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BEDCLASS_BEDCLASS_1 = "bedReservation.bedClass IS NULL";
	private static final String _FINDER_COLUMN_BEDCLASS_BEDCLASS_2 = "bedReservation.bedClass = ?";
	private static final String _FINDER_COLUMN_BEDCLASS_BEDCLASS_3 = "(bedReservation.bedClass IS NULL OR bedReservation.bedClass = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_WARD = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED,
			BedReservationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByward",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED,
			BedReservationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByward",
			new String[] { String.class.getName() },
			BedReservationModelImpl.WARD_COLUMN_BITMASK |
			BedReservationModelImpl.HOSPITALTARIFF_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_WARD = new FinderPath(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByward",
			new String[] { String.class.getName() });

	/**
	 * Returns all the bed reservations where ward = &#63;.
	 *
	 * @param ward the ward
	 * @return the matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findByward(String ward)
		throws SystemException {
		return findByward(ward, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the bed reservations where ward = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ward the ward
	 * @param start the lower bound of the range of bed reservations
	 * @param end the upper bound of the range of bed reservations (not inclusive)
	 * @return the range of matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findByward(String ward, int start, int end)
		throws SystemException {
		return findByward(ward, start, end, null);
	}

	/**
	 * Returns an ordered range of all the bed reservations where ward = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ward the ward
	 * @param start the lower bound of the range of bed reservations
	 * @param end the upper bound of the range of bed reservations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findByward(String ward, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD;
			finderArgs = new Object[] { ward };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_WARD;
			finderArgs = new Object[] { ward, start, end, orderByComparator };
		}

		List<BedReservation> list = (List<BedReservation>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (BedReservation bedReservation : list) {
				if (!Validator.equals(ward, bedReservation.getWard())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_BEDRESERVATION_WHERE);

			boolean bindWard = false;

			if (ward == null) {
				query.append(_FINDER_COLUMN_WARD_WARD_1);
			}
			else if (ward.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARD_WARD_3);
			}
			else {
				bindWard = true;

				query.append(_FINDER_COLUMN_WARD_WARD_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(BedReservationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindWard) {
					qPos.add(ward);
				}

				if (!pagination) {
					list = (List<BedReservation>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BedReservation>(list);
				}
				else {
					list = (List<BedReservation>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first bed reservation in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation findByward_First(String ward,
		OrderByComparator orderByComparator)
		throws NoSuchBedReservationException, SystemException {
		BedReservation bedReservation = fetchByward_First(ward,
				orderByComparator);

		if (bedReservation != null) {
			return bedReservation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ward=");
		msg.append(ward);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedReservationException(msg.toString());
	}

	/**
	 * Returns the first bed reservation in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation fetchByward_First(String ward,
		OrderByComparator orderByComparator) throws SystemException {
		List<BedReservation> list = findByward(ward, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last bed reservation in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation findByward_Last(String ward,
		OrderByComparator orderByComparator)
		throws NoSuchBedReservationException, SystemException {
		BedReservation bedReservation = fetchByward_Last(ward, orderByComparator);

		if (bedReservation != null) {
			return bedReservation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ward=");
		msg.append(ward);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedReservationException(msg.toString());
	}

	/**
	 * Returns the last bed reservation in the ordered set where ward = &#63;.
	 *
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation fetchByward_Last(String ward,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByward(ward);

		if (count == 0) {
			return null;
		}

		List<BedReservation> list = findByward(ward, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the bed reservations before and after the current bed reservation in the ordered set where ward = &#63;.
	 *
	 * @param bedReservationId the primary key of the current bed reservation
	 * @param ward the ward
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation[] findByward_PrevAndNext(long bedReservationId,
		String ward, OrderByComparator orderByComparator)
		throws NoSuchBedReservationException, SystemException {
		BedReservation bedReservation = findByPrimaryKey(bedReservationId);

		Session session = null;

		try {
			session = openSession();

			BedReservation[] array = new BedReservationImpl[3];

			array[0] = getByward_PrevAndNext(session, bedReservation, ward,
					orderByComparator, true);

			array[1] = bedReservation;

			array[2] = getByward_PrevAndNext(session, bedReservation, ward,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected BedReservation getByward_PrevAndNext(Session session,
		BedReservation bedReservation, String ward,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_BEDRESERVATION_WHERE);

		boolean bindWard = false;

		if (ward == null) {
			query.append(_FINDER_COLUMN_WARD_WARD_1);
		}
		else if (ward.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_WARD_WARD_3);
		}
		else {
			bindWard = true;

			query.append(_FINDER_COLUMN_WARD_WARD_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(BedReservationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindWard) {
			qPos.add(ward);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(bedReservation);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<BedReservation> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the bed reservations where ward = &#63; from the database.
	 *
	 * @param ward the ward
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByward(String ward) throws SystemException {
		for (BedReservation bedReservation : findByward(ward,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(bedReservation);
		}
	}

	/**
	 * Returns the number of bed reservations where ward = &#63;.
	 *
	 * @param ward the ward
	 * @return the number of matching bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByward(String ward) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_WARD;

		Object[] finderArgs = new Object[] { ward };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_BEDRESERVATION_WHERE);

			boolean bindWard = false;

			if (ward == null) {
				query.append(_FINDER_COLUMN_WARD_WARD_1);
			}
			else if (ward.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_WARD_WARD_3);
			}
			else {
				bindWard = true;

				query.append(_FINDER_COLUMN_WARD_WARD_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindWard) {
					qPos.add(ward);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_WARD_WARD_1 = "bedReservation.ward IS NULL";
	private static final String _FINDER_COLUMN_WARD_WARD_2 = "bedReservation.ward = ?";
	private static final String _FINDER_COLUMN_WARD_WARD_3 = "(bedReservation.ward IS NULL OR bedReservation.ward = '')";

	public BedReservationPersistenceImpl() {
		setModelClass(BedReservation.class);
	}

	/**
	 * Caches the bed reservation in the entity cache if it is enabled.
	 *
	 * @param bedReservation the bed reservation
	 */
	@Override
	public void cacheResult(BedReservation bedReservation) {
		EntityCacheUtil.putResult(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationImpl.class, bedReservation.getPrimaryKey(),
			bedReservation);

		bedReservation.resetOriginalValues();
	}

	/**
	 * Caches the bed reservations in the entity cache if it is enabled.
	 *
	 * @param bedReservations the bed reservations
	 */
	@Override
	public void cacheResult(List<BedReservation> bedReservations) {
		for (BedReservation bedReservation : bedReservations) {
			if (EntityCacheUtil.getResult(
						BedReservationModelImpl.ENTITY_CACHE_ENABLED,
						BedReservationImpl.class, bedReservation.getPrimaryKey()) == null) {
				cacheResult(bedReservation);
			}
			else {
				bedReservation.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all bed reservations.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(BedReservationImpl.class.getName());
		}

		EntityCacheUtil.clearCache(BedReservationImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the bed reservation.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(BedReservation bedReservation) {
		EntityCacheUtil.removeResult(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationImpl.class, bedReservation.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<BedReservation> bedReservations) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (BedReservation bedReservation : bedReservations) {
			EntityCacheUtil.removeResult(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
				BedReservationImpl.class, bedReservation.getPrimaryKey());
		}
	}

	/**
	 * Creates a new bed reservation with the primary key. Does not add the bed reservation to the database.
	 *
	 * @param bedReservationId the primary key for the new bed reservation
	 * @return the new bed reservation
	 */
	@Override
	public BedReservation create(long bedReservationId) {
		BedReservation bedReservation = new BedReservationImpl();

		bedReservation.setNew(true);
		bedReservation.setPrimaryKey(bedReservationId);

		return bedReservation;
	}

	/**
	 * Removes the bed reservation with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param bedReservationId the primary key of the bed reservation
	 * @return the bed reservation that was removed
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation remove(long bedReservationId)
		throws NoSuchBedReservationException, SystemException {
		return remove((Serializable)bedReservationId);
	}

	/**
	 * Removes the bed reservation with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the bed reservation
	 * @return the bed reservation that was removed
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation remove(Serializable primaryKey)
		throws NoSuchBedReservationException, SystemException {
		Session session = null;

		try {
			session = openSession();

			BedReservation bedReservation = (BedReservation)session.get(BedReservationImpl.class,
					primaryKey);

			if (bedReservation == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchBedReservationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(bedReservation);
		}
		catch (NoSuchBedReservationException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected BedReservation removeImpl(BedReservation bedReservation)
		throws SystemException {
		bedReservation = toUnwrappedModel(bedReservation);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(bedReservation)) {
				bedReservation = (BedReservation)session.get(BedReservationImpl.class,
						bedReservation.getPrimaryKeyObj());
			}

			if (bedReservation != null) {
				session.delete(bedReservation);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (bedReservation != null) {
			clearCache(bedReservation);
		}

		return bedReservation;
	}

	@Override
	public BedReservation updateImpl(
		com.napier.portal.db.model.BedReservation bedReservation)
		throws SystemException {
		bedReservation = toUnwrappedModel(bedReservation);

		boolean isNew = bedReservation.isNew();

		BedReservationModelImpl bedReservationModelImpl = (BedReservationModelImpl)bedReservation;

		Session session = null;

		try {
			session = openSession();

			if (bedReservation.isNew()) {
				session.save(bedReservation);

				bedReservation.setNew(false);
			}
			else {
				session.merge(bedReservation);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !BedReservationModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((bedReservationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BEDCLASS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						bedReservationModelImpl.getOriginalBedClass()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BEDCLASS, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BEDCLASS,
					args);

				args = new Object[] { bedReservationModelImpl.getBedClass() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BEDCLASS, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BEDCLASS,
					args);
			}

			if ((bedReservationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						bedReservationModelImpl.getOriginalWard()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_WARD, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD,
					args);

				args = new Object[] { bedReservationModelImpl.getWard() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_WARD, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_WARD,
					args);
			}
		}

		EntityCacheUtil.putResult(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
			BedReservationImpl.class, bedReservation.getPrimaryKey(),
			bedReservation);

		return bedReservation;
	}

	protected BedReservation toUnwrappedModel(BedReservation bedReservation) {
		if (bedReservation instanceof BedReservationImpl) {
			return bedReservation;
		}

		BedReservationImpl bedReservationImpl = new BedReservationImpl();

		bedReservationImpl.setNew(bedReservation.isNew());
		bedReservationImpl.setPrimaryKey(bedReservation.getPrimaryKey());

		bedReservationImpl.setBedReservationId(bedReservation.getBedReservationId());
		bedReservationImpl.setBedClass(bedReservation.getBedClass());
		bedReservationImpl.setWard(bedReservation.getWard());
		bedReservationImpl.setTotalBedCount(bedReservation.getTotalBedCount());
		bedReservationImpl.setVacantBedCount(bedReservation.getVacantBedCount());
		bedReservationImpl.setHospitalTariff(bedReservation.getHospitalTariff());
		bedReservationImpl.setGender(bedReservation.getGender());

		return bedReservationImpl;
	}

	/**
	 * Returns the bed reservation with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the bed reservation
	 * @return the bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation findByPrimaryKey(Serializable primaryKey)
		throws NoSuchBedReservationException, SystemException {
		BedReservation bedReservation = fetchByPrimaryKey(primaryKey);

		if (bedReservation == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchBedReservationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return bedReservation;
	}

	/**
	 * Returns the bed reservation with the primary key or throws a {@link com.napier.portal.db.NoSuchBedReservationException} if it could not be found.
	 *
	 * @param bedReservationId the primary key of the bed reservation
	 * @return the bed reservation
	 * @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation findByPrimaryKey(long bedReservationId)
		throws NoSuchBedReservationException, SystemException {
		return findByPrimaryKey((Serializable)bedReservationId);
	}

	/**
	 * Returns the bed reservation with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the bed reservation
	 * @return the bed reservation, or <code>null</code> if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		BedReservation bedReservation = (BedReservation)EntityCacheUtil.getResult(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
				BedReservationImpl.class, primaryKey);

		if (bedReservation == _nullBedReservation) {
			return null;
		}

		if (bedReservation == null) {
			Session session = null;

			try {
				session = openSession();

				bedReservation = (BedReservation)session.get(BedReservationImpl.class,
						primaryKey);

				if (bedReservation != null) {
					cacheResult(bedReservation);
				}
				else {
					EntityCacheUtil.putResult(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
						BedReservationImpl.class, primaryKey,
						_nullBedReservation);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(BedReservationModelImpl.ENTITY_CACHE_ENABLED,
					BedReservationImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return bedReservation;
	}

	/**
	 * Returns the bed reservation with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param bedReservationId the primary key of the bed reservation
	 * @return the bed reservation, or <code>null</code> if a bed reservation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedReservation fetchByPrimaryKey(long bedReservationId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)bedReservationId);
	}

	/**
	 * Returns all the bed reservations.
	 *
	 * @return the bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the bed reservations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of bed reservations
	 * @param end the upper bound of the range of bed reservations (not inclusive)
	 * @return the range of bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the bed reservations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of bed reservations
	 * @param end the upper bound of the range of bed reservations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedReservation> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<BedReservation> list = (List<BedReservation>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_BEDRESERVATION);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_BEDRESERVATION;

				if (pagination) {
					sql = sql.concat(BedReservationModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<BedReservation>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BedReservation>(list);
				}
				else {
					list = (List<BedReservation>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the bed reservations from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (BedReservation bedReservation : findAll()) {
			remove(bedReservation);
		}
	}

	/**
	 * Returns the number of bed reservations.
	 *
	 * @return the number of bed reservations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_BEDRESERVATION);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the bed reservation persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.BedReservation")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<BedReservation>> listenersList = new ArrayList<ModelListener<BedReservation>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<BedReservation>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(BedReservationImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_BEDRESERVATION = "SELECT bedReservation FROM BedReservation bedReservation";
	private static final String _SQL_SELECT_BEDRESERVATION_WHERE = "SELECT bedReservation FROM BedReservation bedReservation WHERE ";
	private static final String _SQL_COUNT_BEDRESERVATION = "SELECT COUNT(bedReservation) FROM BedReservation bedReservation";
	private static final String _SQL_COUNT_BEDRESERVATION_WHERE = "SELECT COUNT(bedReservation) FROM BedReservation bedReservation WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "bedReservation.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No BedReservation exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No BedReservation exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(BedReservationPersistenceImpl.class);
	private static BedReservation _nullBedReservation = new BedReservationImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<BedReservation> toCacheModel() {
				return _nullBedReservationCacheModel;
			}
		};

	private static CacheModel<BedReservation> _nullBedReservationCacheModel = new CacheModel<BedReservation>() {
			@Override
			public BedReservation toEntityModel() {
				return _nullBedReservation;
			}
		};
}