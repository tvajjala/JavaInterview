/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchNapierUserException;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.model.impl.NapierUserImpl;
import com.napier.portal.db.model.impl.NapierUserModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the napier user service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see NapierUserPersistence
 * @see NapierUserUtil
 * @generated
 */
public class NapierUserPersistenceImpl extends BasePersistenceImpl<NapierUser>
	implements NapierUserPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link NapierUserUtil} to access the napier user persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = NapierUserImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, NapierUserImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, NapierUserImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_FETCH_BY_PORTALUSERID = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, NapierUserImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByportalUserId",
			new String[] { Long.class.getName() },
			NapierUserModelImpl.PORTALUSERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_PORTALUSERID = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByportalUserId",
			new String[] { Long.class.getName() });

	/**
	 * Returns the napier user where portalUserId = &#63; or throws a {@link com.napier.portal.db.NoSuchNapierUserException} if it could not be found.
	 *
	 * @param portalUserId the portal user ID
	 * @return the matching napier user
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser findByportalUserId(long portalUserId)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = fetchByportalUserId(portalUserId);

		if (napierUser == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("portalUserId=");
			msg.append(portalUserId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchNapierUserException(msg.toString());
		}

		return napierUser;
	}

	/**
	 * Returns the napier user where portalUserId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param portalUserId the portal user ID
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchByportalUserId(long portalUserId)
		throws SystemException {
		return fetchByportalUserId(portalUserId, true);
	}

	/**
	 * Returns the napier user where portalUserId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param portalUserId the portal user ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchByportalUserId(long portalUserId,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { portalUserId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_PORTALUSERID,
					finderArgs, this);
		}

		if (result instanceof NapierUser) {
			NapierUser napierUser = (NapierUser)result;

			if ((portalUserId != napierUser.getPortalUserId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_NAPIERUSER_WHERE);

			query.append(_FINDER_COLUMN_PORTALUSERID_PORTALUSERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(portalUserId);

				List<NapierUser> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_PORTALUSERID,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"NapierUserPersistenceImpl.fetchByportalUserId(long, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					NapierUser napierUser = list.get(0);

					result = napierUser;

					cacheResult(napierUser);

					if ((napierUser.getPortalUserId() != portalUserId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_PORTALUSERID,
							finderArgs, napierUser);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_PORTALUSERID,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (NapierUser)result;
		}
	}

	/**
	 * Removes the napier user where portalUserId = &#63; from the database.
	 *
	 * @param portalUserId the portal user ID
	 * @return the napier user that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser removeByportalUserId(long portalUserId)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = findByportalUserId(portalUserId);

		return remove(napierUser);
	}

	/**
	 * Returns the number of napier users where portalUserId = &#63;.
	 *
	 * @param portalUserId the portal user ID
	 * @return the number of matching napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByportalUserId(long portalUserId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_PORTALUSERID;

		Object[] finderArgs = new Object[] { portalUserId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NAPIERUSER_WHERE);

			query.append(_FINDER_COLUMN_PORTALUSERID_PORTALUSERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(portalUserId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PORTALUSERID_PORTALUSERID_2 = "napierUser.portalUserId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_TPAID = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, NapierUserImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchBytpaId",
			new String[] { String.class.getName() },
			NapierUserModelImpl.TPAID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TPAID = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBytpaId",
			new String[] { String.class.getName() });

	/**
	 * Returns the napier user where tpaId = &#63; or throws a {@link com.napier.portal.db.NoSuchNapierUserException} if it could not be found.
	 *
	 * @param tpaId the tpa ID
	 * @return the matching napier user
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser findBytpaId(String tpaId)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = fetchBytpaId(tpaId);

		if (napierUser == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("tpaId=");
			msg.append(tpaId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchNapierUserException(msg.toString());
		}

		return napierUser;
	}

	/**
	 * Returns the napier user where tpaId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param tpaId the tpa ID
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchBytpaId(String tpaId) throws SystemException {
		return fetchBytpaId(tpaId, true);
	}

	/**
	 * Returns the napier user where tpaId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param tpaId the tpa ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchBytpaId(String tpaId, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { tpaId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_TPAID,
					finderArgs, this);
		}

		if (result instanceof NapierUser) {
			NapierUser napierUser = (NapierUser)result;

			if (!Validator.equals(tpaId, napierUser.getTpaId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_NAPIERUSER_WHERE);

			boolean bindTpaId = false;

			if (tpaId == null) {
				query.append(_FINDER_COLUMN_TPAID_TPAID_1);
			}
			else if (tpaId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TPAID_TPAID_3);
			}
			else {
				bindTpaId = true;

				query.append(_FINDER_COLUMN_TPAID_TPAID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTpaId) {
					qPos.add(tpaId);
				}

				List<NapierUser> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TPAID,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"NapierUserPersistenceImpl.fetchBytpaId(String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					NapierUser napierUser = list.get(0);

					result = napierUser;

					cacheResult(napierUser);

					if ((napierUser.getTpaId() == null) ||
							!napierUser.getTpaId().equals(tpaId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TPAID,
							finderArgs, napierUser);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TPAID,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (NapierUser)result;
		}
	}

	/**
	 * Removes the napier user where tpaId = &#63; from the database.
	 *
	 * @param tpaId the tpa ID
	 * @return the napier user that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser removeBytpaId(String tpaId)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = findBytpaId(tpaId);

		return remove(napierUser);
	}

	/**
	 * Returns the number of napier users where tpaId = &#63;.
	 *
	 * @param tpaId the tpa ID
	 * @return the number of matching napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBytpaId(String tpaId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TPAID;

		Object[] finderArgs = new Object[] { tpaId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NAPIERUSER_WHERE);

			boolean bindTpaId = false;

			if (tpaId == null) {
				query.append(_FINDER_COLUMN_TPAID_TPAID_1);
			}
			else if (tpaId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TPAID_TPAID_3);
			}
			else {
				bindTpaId = true;

				query.append(_FINDER_COLUMN_TPAID_TPAID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTpaId) {
					qPos.add(tpaId);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TPAID_TPAID_1 = "napierUser.tpaId IS NULL";
	private static final String _FINDER_COLUMN_TPAID_TPAID_2 = "napierUser.tpaId = ?";
	private static final String _FINDER_COLUMN_TPAID_TPAID_3 = "(napierUser.tpaId IS NULL OR napierUser.tpaId = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_DOCTORID = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, NapierUserImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchBydoctorId",
			new String[] { String.class.getName() },
			NapierUserModelImpl.DOCTORID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DOCTORID = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBydoctorId",
			new String[] { String.class.getName() });

	/**
	 * Returns the napier user where doctorId = &#63; or throws a {@link com.napier.portal.db.NoSuchNapierUserException} if it could not be found.
	 *
	 * @param doctorId the doctor ID
	 * @return the matching napier user
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser findBydoctorId(String doctorId)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = fetchBydoctorId(doctorId);

		if (napierUser == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("doctorId=");
			msg.append(doctorId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchNapierUserException(msg.toString());
		}

		return napierUser;
	}

	/**
	 * Returns the napier user where doctorId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param doctorId the doctor ID
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchBydoctorId(String doctorId)
		throws SystemException {
		return fetchBydoctorId(doctorId, true);
	}

	/**
	 * Returns the napier user where doctorId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param doctorId the doctor ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchBydoctorId(String doctorId, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { doctorId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_DOCTORID,
					finderArgs, this);
		}

		if (result instanceof NapierUser) {
			NapierUser napierUser = (NapierUser)result;

			if (!Validator.equals(doctorId, napierUser.getDoctorId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_NAPIERUSER_WHERE);

			boolean bindDoctorId = false;

			if (doctorId == null) {
				query.append(_FINDER_COLUMN_DOCTORID_DOCTORID_1);
			}
			else if (doctorId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DOCTORID_DOCTORID_3);
			}
			else {
				bindDoctorId = true;

				query.append(_FINDER_COLUMN_DOCTORID_DOCTORID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDoctorId) {
					qPos.add(doctorId);
				}

				List<NapierUser> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DOCTORID,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"NapierUserPersistenceImpl.fetchBydoctorId(String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					NapierUser napierUser = list.get(0);

					result = napierUser;

					cacheResult(napierUser);

					if ((napierUser.getDoctorId() == null) ||
							!napierUser.getDoctorId().equals(doctorId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DOCTORID,
							finderArgs, napierUser);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_DOCTORID,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (NapierUser)result;
		}
	}

	/**
	 * Removes the napier user where doctorId = &#63; from the database.
	 *
	 * @param doctorId the doctor ID
	 * @return the napier user that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser removeBydoctorId(String doctorId)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = findBydoctorId(doctorId);

		return remove(napierUser);
	}

	/**
	 * Returns the number of napier users where doctorId = &#63;.
	 *
	 * @param doctorId the doctor ID
	 * @return the number of matching napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBydoctorId(String doctorId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DOCTORID;

		Object[] finderArgs = new Object[] { doctorId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NAPIERUSER_WHERE);

			boolean bindDoctorId = false;

			if (doctorId == null) {
				query.append(_FINDER_COLUMN_DOCTORID_DOCTORID_1);
			}
			else if (doctorId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DOCTORID_DOCTORID_3);
			}
			else {
				bindDoctorId = true;

				query.append(_FINDER_COLUMN_DOCTORID_DOCTORID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDoctorId) {
					qPos.add(doctorId);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DOCTORID_DOCTORID_1 = "napierUser.doctorId IS NULL";
	private static final String _FINDER_COLUMN_DOCTORID_DOCTORID_2 = "napierUser.doctorId = ?";
	private static final String _FINDER_COLUMN_DOCTORID_DOCTORID_3 = "(napierUser.doctorId IS NULL OR napierUser.doctorId = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_MRNUMBER = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, NapierUserImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchBymrNumber",
			new String[] { String.class.getName() },
			NapierUserModelImpl.MRNUMBER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MRNUMBER = new FinderPath(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymrNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns the napier user where mrNumber = &#63; or throws a {@link com.napier.portal.db.NoSuchNapierUserException} if it could not be found.
	 *
	 * @param mrNumber the mr number
	 * @return the matching napier user
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser findBymrNumber(String mrNumber)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = fetchBymrNumber(mrNumber);

		if (napierUser == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("mrNumber=");
			msg.append(mrNumber);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchNapierUserException(msg.toString());
		}

		return napierUser;
	}

	/**
	 * Returns the napier user where mrNumber = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param mrNumber the mr number
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchBymrNumber(String mrNumber)
		throws SystemException {
		return fetchBymrNumber(mrNumber, true);
	}

	/**
	 * Returns the napier user where mrNumber = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param mrNumber the mr number
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching napier user, or <code>null</code> if a matching napier user could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchBymrNumber(String mrNumber, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { mrNumber };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_MRNUMBER,
					finderArgs, this);
		}

		if (result instanceof NapierUser) {
			NapierUser napierUser = (NapierUser)result;

			if (!Validator.equals(mrNumber, napierUser.getMrNumber())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_NAPIERUSER_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				List<NapierUser> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_MRNUMBER,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"NapierUserPersistenceImpl.fetchBymrNumber(String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					NapierUser napierUser = list.get(0);

					result = napierUser;

					cacheResult(napierUser);

					if ((napierUser.getMrNumber() == null) ||
							!napierUser.getMrNumber().equals(mrNumber)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_MRNUMBER,
							finderArgs, napierUser);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_MRNUMBER,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (NapierUser)result;
		}
	}

	/**
	 * Removes the napier user where mrNumber = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @return the napier user that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser removeBymrNumber(String mrNumber)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = findBymrNumber(mrNumber);

		return remove(napierUser);
	}

	/**
	 * Returns the number of napier users where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the number of matching napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymrNumber(String mrNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MRNUMBER;

		Object[] finderArgs = new Object[] { mrNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NAPIERUSER_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_1 = "napierUser.mrNumber IS NULL";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_2 = "napierUser.mrNumber = ?";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_3 = "(napierUser.mrNumber IS NULL OR napierUser.mrNumber = '')";

	public NapierUserPersistenceImpl() {
		setModelClass(NapierUser.class);
	}

	/**
	 * Caches the napier user in the entity cache if it is enabled.
	 *
	 * @param napierUser the napier user
	 */
	@Override
	public void cacheResult(NapierUser napierUser) {
		EntityCacheUtil.putResult(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserImpl.class, napierUser.getPrimaryKey(), napierUser);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_PORTALUSERID,
			new Object[] { napierUser.getPortalUserId() }, napierUser);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TPAID,
			new Object[] { napierUser.getTpaId() }, napierUser);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DOCTORID,
			new Object[] { napierUser.getDoctorId() }, napierUser);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_MRNUMBER,
			new Object[] { napierUser.getMrNumber() }, napierUser);

		napierUser.resetOriginalValues();
	}

	/**
	 * Caches the napier users in the entity cache if it is enabled.
	 *
	 * @param napierUsers the napier users
	 */
	@Override
	public void cacheResult(List<NapierUser> napierUsers) {
		for (NapierUser napierUser : napierUsers) {
			if (EntityCacheUtil.getResult(
						NapierUserModelImpl.ENTITY_CACHE_ENABLED,
						NapierUserImpl.class, napierUser.getPrimaryKey()) == null) {
				cacheResult(napierUser);
			}
			else {
				napierUser.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all napier users.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(NapierUserImpl.class.getName());
		}

		EntityCacheUtil.clearCache(NapierUserImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the napier user.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(NapierUser napierUser) {
		EntityCacheUtil.removeResult(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserImpl.class, napierUser.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(napierUser);
	}

	@Override
	public void clearCache(List<NapierUser> napierUsers) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (NapierUser napierUser : napierUsers) {
			EntityCacheUtil.removeResult(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
				NapierUserImpl.class, napierUser.getPrimaryKey());

			clearUniqueFindersCache(napierUser);
		}
	}

	protected void cacheUniqueFindersCache(NapierUser napierUser) {
		if (napierUser.isNew()) {
			Object[] args = new Object[] { napierUser.getPortalUserId() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_PORTALUSERID, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_PORTALUSERID, args,
				napierUser);

			args = new Object[] { napierUser.getTpaId() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_TPAID, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TPAID, args,
				napierUser);

			args = new Object[] { napierUser.getDoctorId() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_DOCTORID, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DOCTORID, args,
				napierUser);

			args = new Object[] { napierUser.getMrNumber() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_MRNUMBER, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_MRNUMBER, args,
				napierUser);
		}
		else {
			NapierUserModelImpl napierUserModelImpl = (NapierUserModelImpl)napierUser;

			if ((napierUserModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_PORTALUSERID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { napierUser.getPortalUserId() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_PORTALUSERID,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_PORTALUSERID,
					args, napierUser);
			}

			if ((napierUserModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_TPAID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { napierUser.getTpaId() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_TPAID, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TPAID, args,
					napierUser);
			}

			if ((napierUserModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_DOCTORID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { napierUser.getDoctorId() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_DOCTORID, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_DOCTORID, args,
					napierUser);
			}

			if ((napierUserModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_MRNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { napierUser.getMrNumber() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_MRNUMBER, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_MRNUMBER, args,
					napierUser);
			}
		}
	}

	protected void clearUniqueFindersCache(NapierUser napierUser) {
		NapierUserModelImpl napierUserModelImpl = (NapierUserModelImpl)napierUser;

		Object[] args = new Object[] { napierUser.getPortalUserId() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PORTALUSERID, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_PORTALUSERID, args);

		if ((napierUserModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_PORTALUSERID.getColumnBitmask()) != 0) {
			args = new Object[] { napierUserModelImpl.getOriginalPortalUserId() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PORTALUSERID, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_PORTALUSERID, args);
		}

		args = new Object[] { napierUser.getTpaId() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TPAID, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TPAID, args);

		if ((napierUserModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_TPAID.getColumnBitmask()) != 0) {
			args = new Object[] { napierUserModelImpl.getOriginalTpaId() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TPAID, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TPAID, args);
		}

		args = new Object[] { napierUser.getDoctorId() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DOCTORID, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_DOCTORID, args);

		if ((napierUserModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_DOCTORID.getColumnBitmask()) != 0) {
			args = new Object[] { napierUserModelImpl.getOriginalDoctorId() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DOCTORID, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_DOCTORID, args);
		}

		args = new Object[] { napierUser.getMrNumber() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_MRNUMBER, args);

		if ((napierUserModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_MRNUMBER.getColumnBitmask()) != 0) {
			args = new Object[] { napierUserModelImpl.getOriginalMrNumber() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_MRNUMBER, args);
		}
	}

	/**
	 * Creates a new napier user with the primary key. Does not add the napier user to the database.
	 *
	 * @param napierUserId the primary key for the new napier user
	 * @return the new napier user
	 */
	@Override
	public NapierUser create(long napierUserId) {
		NapierUser napierUser = new NapierUserImpl();

		napierUser.setNew(true);
		napierUser.setPrimaryKey(napierUserId);

		return napierUser;
	}

	/**
	 * Removes the napier user with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param napierUserId the primary key of the napier user
	 * @return the napier user that was removed
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a napier user with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser remove(long napierUserId)
		throws NoSuchNapierUserException, SystemException {
		return remove((Serializable)napierUserId);
	}

	/**
	 * Removes the napier user with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the napier user
	 * @return the napier user that was removed
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a napier user with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser remove(Serializable primaryKey)
		throws NoSuchNapierUserException, SystemException {
		Session session = null;

		try {
			session = openSession();

			NapierUser napierUser = (NapierUser)session.get(NapierUserImpl.class,
					primaryKey);

			if (napierUser == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchNapierUserException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(napierUser);
		}
		catch (NoSuchNapierUserException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected NapierUser removeImpl(NapierUser napierUser)
		throws SystemException {
		napierUser = toUnwrappedModel(napierUser);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(napierUser)) {
				napierUser = (NapierUser)session.get(NapierUserImpl.class,
						napierUser.getPrimaryKeyObj());
			}

			if (napierUser != null) {
				session.delete(napierUser);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (napierUser != null) {
			clearCache(napierUser);
		}

		return napierUser;
	}

	@Override
	public NapierUser updateImpl(
		com.napier.portal.db.model.NapierUser napierUser)
		throws SystemException {
		napierUser = toUnwrappedModel(napierUser);

		boolean isNew = napierUser.isNew();

		Session session = null;

		try {
			session = openSession();

			if (napierUser.isNew()) {
				session.save(napierUser);

				napierUser.setNew(false);
			}
			else {
				session.merge(napierUser);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !NapierUserModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
			NapierUserImpl.class, napierUser.getPrimaryKey(), napierUser);

		clearUniqueFindersCache(napierUser);
		cacheUniqueFindersCache(napierUser);

		return napierUser;
	}

	protected NapierUser toUnwrappedModel(NapierUser napierUser) {
		if (napierUser instanceof NapierUserImpl) {
			return napierUser;
		}

		NapierUserImpl napierUserImpl = new NapierUserImpl();

		napierUserImpl.setNew(napierUser.isNew());
		napierUserImpl.setPrimaryKey(napierUser.getPrimaryKey());

		napierUserImpl.setNapierUserId(napierUser.getNapierUserId());
		napierUserImpl.setPortalUserId(napierUser.getPortalUserId());
		napierUserImpl.setMrNumber(napierUser.getMrNumber());
		napierUserImpl.setTpaId(napierUser.getTpaId());
		napierUserImpl.setCoroporateId(napierUser.getCoroporateId());
		napierUserImpl.setDoctorId(napierUser.getDoctorId());
		napierUserImpl.setAge(napierUser.getAge());
		napierUserImpl.setMobile(napierUser.getMobile());
		napierUserImpl.setGender(napierUser.getGender());
		napierUserImpl.setSpecialization(napierUser.getSpecialization());
		napierUserImpl.setUserType(napierUser.getUserType());
		napierUserImpl.setEmail(napierUser.getEmail());
		napierUserImpl.setName(napierUser.getName());
		napierUserImpl.setAddress(napierUser.getAddress());
		napierUserImpl.setStreet1(napierUser.getStreet1());
		napierUserImpl.setStreet2(napierUser.getStreet2());
		napierUserImpl.setPostalCode(napierUser.getPostalCode());

		return napierUserImpl;
	}

	/**
	 * Returns the napier user with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the napier user
	 * @return the napier user
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a napier user with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser findByPrimaryKey(Serializable primaryKey)
		throws NoSuchNapierUserException, SystemException {
		NapierUser napierUser = fetchByPrimaryKey(primaryKey);

		if (napierUser == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchNapierUserException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return napierUser;
	}

	/**
	 * Returns the napier user with the primary key or throws a {@link com.napier.portal.db.NoSuchNapierUserException} if it could not be found.
	 *
	 * @param napierUserId the primary key of the napier user
	 * @return the napier user
	 * @throws com.napier.portal.db.NoSuchNapierUserException if a napier user with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser findByPrimaryKey(long napierUserId)
		throws NoSuchNapierUserException, SystemException {
		return findByPrimaryKey((Serializable)napierUserId);
	}

	/**
	 * Returns the napier user with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the napier user
	 * @return the napier user, or <code>null</code> if a napier user with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		NapierUser napierUser = (NapierUser)EntityCacheUtil.getResult(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
				NapierUserImpl.class, primaryKey);

		if (napierUser == _nullNapierUser) {
			return null;
		}

		if (napierUser == null) {
			Session session = null;

			try {
				session = openSession();

				napierUser = (NapierUser)session.get(NapierUserImpl.class,
						primaryKey);

				if (napierUser != null) {
					cacheResult(napierUser);
				}
				else {
					EntityCacheUtil.putResult(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
						NapierUserImpl.class, primaryKey, _nullNapierUser);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(NapierUserModelImpl.ENTITY_CACHE_ENABLED,
					NapierUserImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return napierUser;
	}

	/**
	 * Returns the napier user with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param napierUserId the primary key of the napier user
	 * @return the napier user, or <code>null</code> if a napier user with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public NapierUser fetchByPrimaryKey(long napierUserId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)napierUserId);
	}

	/**
	 * Returns all the napier users.
	 *
	 * @return the napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<NapierUser> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the napier users.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.NapierUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of napier users
	 * @param end the upper bound of the range of napier users (not inclusive)
	 * @return the range of napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<NapierUser> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the napier users.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.NapierUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of napier users
	 * @param end the upper bound of the range of napier users (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<NapierUser> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<NapierUser> list = (List<NapierUser>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_NAPIERUSER);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_NAPIERUSER;

				if (pagination) {
					sql = sql.concat(NapierUserModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<NapierUser>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<NapierUser>(list);
				}
				else {
					list = (List<NapierUser>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the napier users from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (NapierUser napierUser : findAll()) {
			remove(napierUser);
		}
	}

	/**
	 * Returns the number of napier users.
	 *
	 * @return the number of napier users
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_NAPIERUSER);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the napier user persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.NapierUser")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<NapierUser>> listenersList = new ArrayList<ModelListener<NapierUser>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<NapierUser>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(NapierUserImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_NAPIERUSER = "SELECT napierUser FROM NapierUser napierUser";
	private static final String _SQL_SELECT_NAPIERUSER_WHERE = "SELECT napierUser FROM NapierUser napierUser WHERE ";
	private static final String _SQL_COUNT_NAPIERUSER = "SELECT COUNT(napierUser) FROM NapierUser napierUser";
	private static final String _SQL_COUNT_NAPIERUSER_WHERE = "SELECT COUNT(napierUser) FROM NapierUser napierUser WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "napierUser.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No NapierUser exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No NapierUser exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(NapierUserPersistenceImpl.class);
	private static NapierUser _nullNapierUser = new NapierUserImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<NapierUser> toCacheModel() {
				return _nullNapierUserCacheModel;
			}
		};

	private static CacheModel<NapierUser> _nullNapierUserCacheModel = new CacheModel<NapierUser>() {
			@Override
			public NapierUser toEntityModel() {
				return _nullNapierUser;
			}
		};
}