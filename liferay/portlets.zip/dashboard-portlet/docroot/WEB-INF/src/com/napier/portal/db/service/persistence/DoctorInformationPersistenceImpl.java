/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchDoctorInformationException;
import com.napier.portal.db.model.DoctorInformation;
import com.napier.portal.db.model.impl.DoctorInformationImpl;
import com.napier.portal.db.model.impl.DoctorInformationModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the doctor information service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DoctorInformationPersistence
 * @see DoctorInformationUtil
 * @generated
 */
public class DoctorInformationPersistenceImpl extends BasePersistenceImpl<DoctorInformation>
	implements DoctorInformationPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link DoctorInformationUtil} to access the doctor information persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = DoctorInformationImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
			DoctorInformationModelImpl.FINDER_CACHE_ENABLED,
			DoctorInformationImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
			DoctorInformationModelImpl.FINDER_CACHE_ENABLED,
			DoctorInformationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
			DoctorInformationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public DoctorInformationPersistenceImpl() {
		setModelClass(DoctorInformation.class);
	}

	/**
	 * Caches the doctor information in the entity cache if it is enabled.
	 *
	 * @param doctorInformation the doctor information
	 */
	@Override
	public void cacheResult(DoctorInformation doctorInformation) {
		EntityCacheUtil.putResult(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
			DoctorInformationImpl.class, doctorInformation.getPrimaryKey(),
			doctorInformation);

		doctorInformation.resetOriginalValues();
	}

	/**
	 * Caches the doctor informations in the entity cache if it is enabled.
	 *
	 * @param doctorInformations the doctor informations
	 */
	@Override
	public void cacheResult(List<DoctorInformation> doctorInformations) {
		for (DoctorInformation doctorInformation : doctorInformations) {
			if (EntityCacheUtil.getResult(
						DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
						DoctorInformationImpl.class,
						doctorInformation.getPrimaryKey()) == null) {
				cacheResult(doctorInformation);
			}
			else {
				doctorInformation.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all doctor informations.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(DoctorInformationImpl.class.getName());
		}

		EntityCacheUtil.clearCache(DoctorInformationImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the doctor information.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(DoctorInformation doctorInformation) {
		EntityCacheUtil.removeResult(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
			DoctorInformationImpl.class, doctorInformation.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<DoctorInformation> doctorInformations) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (DoctorInformation doctorInformation : doctorInformations) {
			EntityCacheUtil.removeResult(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
				DoctorInformationImpl.class, doctorInformation.getPrimaryKey());
		}
	}

	/**
	 * Creates a new doctor information with the primary key. Does not add the doctor information to the database.
	 *
	 * @param doctorInfoId the primary key for the new doctor information
	 * @return the new doctor information
	 */
	@Override
	public DoctorInformation create(long doctorInfoId) {
		DoctorInformation doctorInformation = new DoctorInformationImpl();

		doctorInformation.setNew(true);
		doctorInformation.setPrimaryKey(doctorInfoId);

		return doctorInformation;
	}

	/**
	 * Removes the doctor information with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param doctorInfoId the primary key of the doctor information
	 * @return the doctor information that was removed
	 * @throws com.napier.portal.db.NoSuchDoctorInformationException if a doctor information with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorInformation remove(long doctorInfoId)
		throws NoSuchDoctorInformationException, SystemException {
		return remove((Serializable)doctorInfoId);
	}

	/**
	 * Removes the doctor information with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the doctor information
	 * @return the doctor information that was removed
	 * @throws com.napier.portal.db.NoSuchDoctorInformationException if a doctor information with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorInformation remove(Serializable primaryKey)
		throws NoSuchDoctorInformationException, SystemException {
		Session session = null;

		try {
			session = openSession();

			DoctorInformation doctorInformation = (DoctorInformation)session.get(DoctorInformationImpl.class,
					primaryKey);

			if (doctorInformation == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDoctorInformationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(doctorInformation);
		}
		catch (NoSuchDoctorInformationException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected DoctorInformation removeImpl(DoctorInformation doctorInformation)
		throws SystemException {
		doctorInformation = toUnwrappedModel(doctorInformation);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(doctorInformation)) {
				doctorInformation = (DoctorInformation)session.get(DoctorInformationImpl.class,
						doctorInformation.getPrimaryKeyObj());
			}

			if (doctorInformation != null) {
				session.delete(doctorInformation);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (doctorInformation != null) {
			clearCache(doctorInformation);
		}

		return doctorInformation;
	}

	@Override
	public DoctorInformation updateImpl(
		com.napier.portal.db.model.DoctorInformation doctorInformation)
		throws SystemException {
		doctorInformation = toUnwrappedModel(doctorInformation);

		boolean isNew = doctorInformation.isNew();

		Session session = null;

		try {
			session = openSession();

			if (doctorInformation.isNew()) {
				session.save(doctorInformation);

				doctorInformation.setNew(false);
			}
			else {
				session.merge(doctorInformation);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
			DoctorInformationImpl.class, doctorInformation.getPrimaryKey(),
			doctorInformation);

		return doctorInformation;
	}

	protected DoctorInformation toUnwrappedModel(
		DoctorInformation doctorInformation) {
		if (doctorInformation instanceof DoctorInformationImpl) {
			return doctorInformation;
		}

		DoctorInformationImpl doctorInformationImpl = new DoctorInformationImpl();

		doctorInformationImpl.setNew(doctorInformation.isNew());
		doctorInformationImpl.setPrimaryKey(doctorInformation.getPrimaryKey());

		doctorInformationImpl.setDoctorInfoId(doctorInformation.getDoctorInfoId());
		doctorInformationImpl.setSpecialization(doctorInformation.getSpecialization());
		doctorInformationImpl.setDoctorName(doctorInformation.getDoctorName());

		return doctorInformationImpl;
	}

	/**
	 * Returns the doctor information with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the doctor information
	 * @return the doctor information
	 * @throws com.napier.portal.db.NoSuchDoctorInformationException if a doctor information with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorInformation findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDoctorInformationException, SystemException {
		DoctorInformation doctorInformation = fetchByPrimaryKey(primaryKey);

		if (doctorInformation == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDoctorInformationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return doctorInformation;
	}

	/**
	 * Returns the doctor information with the primary key or throws a {@link com.napier.portal.db.NoSuchDoctorInformationException} if it could not be found.
	 *
	 * @param doctorInfoId the primary key of the doctor information
	 * @return the doctor information
	 * @throws com.napier.portal.db.NoSuchDoctorInformationException if a doctor information with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorInformation findByPrimaryKey(long doctorInfoId)
		throws NoSuchDoctorInformationException, SystemException {
		return findByPrimaryKey((Serializable)doctorInfoId);
	}

	/**
	 * Returns the doctor information with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the doctor information
	 * @return the doctor information, or <code>null</code> if a doctor information with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorInformation fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		DoctorInformation doctorInformation = (DoctorInformation)EntityCacheUtil.getResult(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
				DoctorInformationImpl.class, primaryKey);

		if (doctorInformation == _nullDoctorInformation) {
			return null;
		}

		if (doctorInformation == null) {
			Session session = null;

			try {
				session = openSession();

				doctorInformation = (DoctorInformation)session.get(DoctorInformationImpl.class,
						primaryKey);

				if (doctorInformation != null) {
					cacheResult(doctorInformation);
				}
				else {
					EntityCacheUtil.putResult(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
						DoctorInformationImpl.class, primaryKey,
						_nullDoctorInformation);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(DoctorInformationModelImpl.ENTITY_CACHE_ENABLED,
					DoctorInformationImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return doctorInformation;
	}

	/**
	 * Returns the doctor information with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param doctorInfoId the primary key of the doctor information
	 * @return the doctor information, or <code>null</code> if a doctor information with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DoctorInformation fetchByPrimaryKey(long doctorInfoId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)doctorInfoId);
	}

	/**
	 * Returns all the doctor informations.
	 *
	 * @return the doctor informations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DoctorInformation> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the doctor informations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorInformationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of doctor informations
	 * @param end the upper bound of the range of doctor informations (not inclusive)
	 * @return the range of doctor informations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DoctorInformation> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the doctor informations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorInformationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of doctor informations
	 * @param end the upper bound of the range of doctor informations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of doctor informations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DoctorInformation> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<DoctorInformation> list = (List<DoctorInformation>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_DOCTORINFORMATION);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DOCTORINFORMATION;

				if (pagination) {
					sql = sql.concat(DoctorInformationModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<DoctorInformation>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DoctorInformation>(list);
				}
				else {
					list = (List<DoctorInformation>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the doctor informations from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (DoctorInformation doctorInformation : findAll()) {
			remove(doctorInformation);
		}
	}

	/**
	 * Returns the number of doctor informations.
	 *
	 * @return the number of doctor informations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DOCTORINFORMATION);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the doctor information persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.DoctorInformation")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<DoctorInformation>> listenersList = new ArrayList<ModelListener<DoctorInformation>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<DoctorInformation>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(DoctorInformationImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_DOCTORINFORMATION = "SELECT doctorInformation FROM DoctorInformation doctorInformation";
	private static final String _SQL_COUNT_DOCTORINFORMATION = "SELECT COUNT(doctorInformation) FROM DoctorInformation doctorInformation";
	private static final String _ORDER_BY_ENTITY_ALIAS = "doctorInformation.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No DoctorInformation exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(DoctorInformationPersistenceImpl.class);
	private static DoctorInformation _nullDoctorInformation = new DoctorInformationImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<DoctorInformation> toCacheModel() {
				return _nullDoctorInformationCacheModel;
			}
		};

	private static CacheModel<DoctorInformation> _nullDoctorInformationCacheModel =
		new CacheModel<DoctorInformation>() {
			@Override
			public DoctorInformation toEntityModel() {
				return _nullDoctorInformation;
			}
		};
}