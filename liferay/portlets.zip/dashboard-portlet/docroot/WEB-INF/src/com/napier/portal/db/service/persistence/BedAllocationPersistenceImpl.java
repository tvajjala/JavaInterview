/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.napier.portal.db.NoSuchBedAllocationException;
import com.napier.portal.db.model.BedAllocation;
import com.napier.portal.db.model.impl.BedAllocationImpl;
import com.napier.portal.db.model.impl.BedAllocationModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the bed allocation service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see BedAllocationPersistence
 * @see BedAllocationUtil
 * @generated
 */
public class BedAllocationPersistenceImpl extends BasePersistenceImpl<BedAllocation>
	implements BedAllocationPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link BedAllocationUtil} to access the bed allocation persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = BedAllocationImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED,
			BedAllocationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED,
			BedAllocationImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER = new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED,
			BedAllocationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBymrNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER =
		new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED,
			BedAllocationImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findBymrNumber", new String[] { String.class.getName() },
			BedAllocationModelImpl.MRNUMBER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_MRNUMBER = new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymrNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the bed allocations where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findBymrNumber(String mrNumber)
		throws SystemException {
		return findBymrNumber(mrNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the bed allocations where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of bed allocations
	 * @param end the upper bound of the range of bed allocations (not inclusive)
	 * @return the range of matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findBymrNumber(String mrNumber, int start,
		int end) throws SystemException {
		return findBymrNumber(mrNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the bed allocations where mrNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param mrNumber the mr number
	 * @param start the lower bound of the range of bed allocations
	 * @param end the upper bound of the range of bed allocations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findBymrNumber(String mrNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_MRNUMBER;
			finderArgs = new Object[] { mrNumber, start, end, orderByComparator };
		}

		List<BedAllocation> list = (List<BedAllocation>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (BedAllocation bedAllocation : list) {
				if (!Validator.equals(mrNumber, bedAllocation.getMrNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_BEDALLOCATION_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(BedAllocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				if (!pagination) {
					list = (List<BedAllocation>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BedAllocation>(list);
				}
				else {
					list = (List<BedAllocation>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first bed allocation in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation findBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchBedAllocationException, SystemException {
		BedAllocation bedAllocation = fetchBymrNumber_First(mrNumber,
				orderByComparator);

		if (bedAllocation != null) {
			return bedAllocation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedAllocationException(msg.toString());
	}

	/**
	 * Returns the first bed allocation in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation fetchBymrNumber_First(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<BedAllocation> list = findBymrNumber(mrNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last bed allocation in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation findBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator)
		throws NoSuchBedAllocationException, SystemException {
		BedAllocation bedAllocation = fetchBymrNumber_Last(mrNumber,
				orderByComparator);

		if (bedAllocation != null) {
			return bedAllocation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("mrNumber=");
		msg.append(mrNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedAllocationException(msg.toString());
	}

	/**
	 * Returns the last bed allocation in the ordered set where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation fetchBymrNumber_Last(String mrNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBymrNumber(mrNumber);

		if (count == 0) {
			return null;
		}

		List<BedAllocation> list = findBymrNumber(mrNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the bed allocations before and after the current bed allocation in the ordered set where mrNumber = &#63;.
	 *
	 * @param bedAllocationId the primary key of the current bed allocation
	 * @param mrNumber the mr number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation[] findBymrNumber_PrevAndNext(long bedAllocationId,
		String mrNumber, OrderByComparator orderByComparator)
		throws NoSuchBedAllocationException, SystemException {
		BedAllocation bedAllocation = findByPrimaryKey(bedAllocationId);

		Session session = null;

		try {
			session = openSession();

			BedAllocation[] array = new BedAllocationImpl[3];

			array[0] = getBymrNumber_PrevAndNext(session, bedAllocation,
					mrNumber, orderByComparator, true);

			array[1] = bedAllocation;

			array[2] = getBymrNumber_PrevAndNext(session, bedAllocation,
					mrNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected BedAllocation getBymrNumber_PrevAndNext(Session session,
		BedAllocation bedAllocation, String mrNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_BEDALLOCATION_WHERE);

		boolean bindMrNumber = false;

		if (mrNumber == null) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
		}
		else if (mrNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
		}
		else {
			bindMrNumber = true;

			query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(BedAllocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMrNumber) {
			qPos.add(mrNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(bedAllocation);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<BedAllocation> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the bed allocations where mrNumber = &#63; from the database.
	 *
	 * @param mrNumber the mr number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBymrNumber(String mrNumber) throws SystemException {
		for (BedAllocation bedAllocation : findBymrNumber(mrNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(bedAllocation);
		}
	}

	/**
	 * Returns the number of bed allocations where mrNumber = &#63;.
	 *
	 * @param mrNumber the mr number
	 * @return the number of matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymrNumber(String mrNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_MRNUMBER;

		Object[] finderArgs = new Object[] { mrNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_BEDALLOCATION_WHERE);

			boolean bindMrNumber = false;

			if (mrNumber == null) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_1);
			}
			else if (mrNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_3);
			}
			else {
				bindMrNumber = true;

				query.append(_FINDER_COLUMN_MRNUMBER_MRNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMrNumber) {
					qPos.add(mrNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_1 = "bedAllocation.mrNumber IS NULL";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_2 = "bedAllocation.mrNumber = ?";
	private static final String _FINDER_COLUMN_MRNUMBER_MRNUMBER_3 = "(bedAllocation.mrNumber IS NULL OR bedAllocation.mrNumber = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER = new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED,
			BedAllocationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByipNumber",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER =
		new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED,
			BedAllocationImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByipNumber", new String[] { String.class.getName() },
			BedAllocationModelImpl.IPNUMBER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_IPNUMBER = new FinderPath(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByipNumber",
			new String[] { String.class.getName() });

	/**
	 * Returns all the bed allocations where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findByipNumber(String ipNumber)
		throws SystemException {
		return findByipNumber(ipNumber, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the bed allocations where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of bed allocations
	 * @param end the upper bound of the range of bed allocations (not inclusive)
	 * @return the range of matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findByipNumber(String ipNumber, int start,
		int end) throws SystemException {
		return findByipNumber(ipNumber, start, end, null);
	}

	/**
	 * Returns an ordered range of all the bed allocations where ipNumber = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ipNumber the ip number
	 * @param start the lower bound of the range of bed allocations
	 * @param end the upper bound of the range of bed allocations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findByipNumber(String ipNumber, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_IPNUMBER;
			finderArgs = new Object[] { ipNumber, start, end, orderByComparator };
		}

		List<BedAllocation> list = (List<BedAllocation>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (BedAllocation bedAllocation : list) {
				if (!Validator.equals(ipNumber, bedAllocation.getIpNumber())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_BEDALLOCATION_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(BedAllocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				if (!pagination) {
					list = (List<BedAllocation>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BedAllocation>(list);
				}
				else {
					list = (List<BedAllocation>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first bed allocation in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation findByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchBedAllocationException, SystemException {
		BedAllocation bedAllocation = fetchByipNumber_First(ipNumber,
				orderByComparator);

		if (bedAllocation != null) {
			return bedAllocation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedAllocationException(msg.toString());
	}

	/**
	 * Returns the first bed allocation in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation fetchByipNumber_First(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		List<BedAllocation> list = findByipNumber(ipNumber, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last bed allocation in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation findByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator)
		throws NoSuchBedAllocationException, SystemException {
		BedAllocation bedAllocation = fetchByipNumber_Last(ipNumber,
				orderByComparator);

		if (bedAllocation != null) {
			return bedAllocation;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ipNumber=");
		msg.append(ipNumber);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBedAllocationException(msg.toString());
	}

	/**
	 * Returns the last bed allocation in the ordered set where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation fetchByipNumber_Last(String ipNumber,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByipNumber(ipNumber);

		if (count == 0) {
			return null;
		}

		List<BedAllocation> list = findByipNumber(ipNumber, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the bed allocations before and after the current bed allocation in the ordered set where ipNumber = &#63;.
	 *
	 * @param bedAllocationId the primary key of the current bed allocation
	 * @param ipNumber the ip number
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation[] findByipNumber_PrevAndNext(long bedAllocationId,
		String ipNumber, OrderByComparator orderByComparator)
		throws NoSuchBedAllocationException, SystemException {
		BedAllocation bedAllocation = findByPrimaryKey(bedAllocationId);

		Session session = null;

		try {
			session = openSession();

			BedAllocation[] array = new BedAllocationImpl[3];

			array[0] = getByipNumber_PrevAndNext(session, bedAllocation,
					ipNumber, orderByComparator, true);

			array[1] = bedAllocation;

			array[2] = getByipNumber_PrevAndNext(session, bedAllocation,
					ipNumber, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected BedAllocation getByipNumber_PrevAndNext(Session session,
		BedAllocation bedAllocation, String ipNumber,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_BEDALLOCATION_WHERE);

		boolean bindIpNumber = false;

		if (ipNumber == null) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
		}
		else if (ipNumber.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
		}
		else {
			bindIpNumber = true;

			query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(BedAllocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindIpNumber) {
			qPos.add(ipNumber);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(bedAllocation);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<BedAllocation> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the bed allocations where ipNumber = &#63; from the database.
	 *
	 * @param ipNumber the ip number
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByipNumber(String ipNumber) throws SystemException {
		for (BedAllocation bedAllocation : findByipNumber(ipNumber,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(bedAllocation);
		}
	}

	/**
	 * Returns the number of bed allocations where ipNumber = &#63;.
	 *
	 * @param ipNumber the ip number
	 * @return the number of matching bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByipNumber(String ipNumber) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_IPNUMBER;

		Object[] finderArgs = new Object[] { ipNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_BEDALLOCATION_WHERE);

			boolean bindIpNumber = false;

			if (ipNumber == null) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_1);
			}
			else if (ipNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_3);
			}
			else {
				bindIpNumber = true;

				query.append(_FINDER_COLUMN_IPNUMBER_IPNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindIpNumber) {
					qPos.add(ipNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_1 = "bedAllocation.ipNumber IS NULL";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_2 = "bedAllocation.ipNumber = ?";
	private static final String _FINDER_COLUMN_IPNUMBER_IPNUMBER_3 = "(bedAllocation.ipNumber IS NULL OR bedAllocation.ipNumber = '')";

	public BedAllocationPersistenceImpl() {
		setModelClass(BedAllocation.class);
	}

	/**
	 * Caches the bed allocation in the entity cache if it is enabled.
	 *
	 * @param bedAllocation the bed allocation
	 */
	@Override
	public void cacheResult(BedAllocation bedAllocation) {
		EntityCacheUtil.putResult(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationImpl.class, bedAllocation.getPrimaryKey(),
			bedAllocation);

		bedAllocation.resetOriginalValues();
	}

	/**
	 * Caches the bed allocations in the entity cache if it is enabled.
	 *
	 * @param bedAllocations the bed allocations
	 */
	@Override
	public void cacheResult(List<BedAllocation> bedAllocations) {
		for (BedAllocation bedAllocation : bedAllocations) {
			if (EntityCacheUtil.getResult(
						BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
						BedAllocationImpl.class, bedAllocation.getPrimaryKey()) == null) {
				cacheResult(bedAllocation);
			}
			else {
				bedAllocation.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all bed allocations.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(BedAllocationImpl.class.getName());
		}

		EntityCacheUtil.clearCache(BedAllocationImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the bed allocation.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(BedAllocation bedAllocation) {
		EntityCacheUtil.removeResult(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationImpl.class, bedAllocation.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<BedAllocation> bedAllocations) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (BedAllocation bedAllocation : bedAllocations) {
			EntityCacheUtil.removeResult(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
				BedAllocationImpl.class, bedAllocation.getPrimaryKey());
		}
	}

	/**
	 * Creates a new bed allocation with the primary key. Does not add the bed allocation to the database.
	 *
	 * @param bedAllocationId the primary key for the new bed allocation
	 * @return the new bed allocation
	 */
	@Override
	public BedAllocation create(long bedAllocationId) {
		BedAllocation bedAllocation = new BedAllocationImpl();

		bedAllocation.setNew(true);
		bedAllocation.setPrimaryKey(bedAllocationId);

		return bedAllocation;
	}

	/**
	 * Removes the bed allocation with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param bedAllocationId the primary key of the bed allocation
	 * @return the bed allocation that was removed
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation remove(long bedAllocationId)
		throws NoSuchBedAllocationException, SystemException {
		return remove((Serializable)bedAllocationId);
	}

	/**
	 * Removes the bed allocation with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the bed allocation
	 * @return the bed allocation that was removed
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation remove(Serializable primaryKey)
		throws NoSuchBedAllocationException, SystemException {
		Session session = null;

		try {
			session = openSession();

			BedAllocation bedAllocation = (BedAllocation)session.get(BedAllocationImpl.class,
					primaryKey);

			if (bedAllocation == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchBedAllocationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(bedAllocation);
		}
		catch (NoSuchBedAllocationException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected BedAllocation removeImpl(BedAllocation bedAllocation)
		throws SystemException {
		bedAllocation = toUnwrappedModel(bedAllocation);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(bedAllocation)) {
				bedAllocation = (BedAllocation)session.get(BedAllocationImpl.class,
						bedAllocation.getPrimaryKeyObj());
			}

			if (bedAllocation != null) {
				session.delete(bedAllocation);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (bedAllocation != null) {
			clearCache(bedAllocation);
		}

		return bedAllocation;
	}

	@Override
	public BedAllocation updateImpl(
		com.napier.portal.db.model.BedAllocation bedAllocation)
		throws SystemException {
		bedAllocation = toUnwrappedModel(bedAllocation);

		boolean isNew = bedAllocation.isNew();

		BedAllocationModelImpl bedAllocationModelImpl = (BedAllocationModelImpl)bedAllocation;

		Session session = null;

		try {
			session = openSession();

			if (bedAllocation.isNew()) {
				session.save(bedAllocation);

				bedAllocation.setNew(false);
			}
			else {
				session.merge(bedAllocation);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !BedAllocationModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((bedAllocationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						bedAllocationModelImpl.getOriginalMrNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);

				args = new Object[] { bedAllocationModelImpl.getMrNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_MRNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_MRNUMBER,
					args);
			}

			if ((bedAllocationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						bedAllocationModelImpl.getOriginalIpNumber()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);

				args = new Object[] { bedAllocationModelImpl.getIpNumber() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_IPNUMBER, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_IPNUMBER,
					args);
			}
		}

		EntityCacheUtil.putResult(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
			BedAllocationImpl.class, bedAllocation.getPrimaryKey(),
			bedAllocation);

		return bedAllocation;
	}

	protected BedAllocation toUnwrappedModel(BedAllocation bedAllocation) {
		if (bedAllocation instanceof BedAllocationImpl) {
			return bedAllocation;
		}

		BedAllocationImpl bedAllocationImpl = new BedAllocationImpl();

		bedAllocationImpl.setNew(bedAllocation.isNew());
		bedAllocationImpl.setPrimaryKey(bedAllocation.getPrimaryKey());

		bedAllocationImpl.setBedAllocationId(bedAllocation.getBedAllocationId());
		bedAllocationImpl.setBedReservationNumber(bedAllocation.getBedReservationNumber());
		bedAllocationImpl.setBedReservationDate(bedAllocation.getBedReservationDate());
		bedAllocationImpl.setMrNumber(bedAllocation.getMrNumber());
		bedAllocationImpl.setIpNumber(bedAllocation.getIpNumber());
		bedAllocationImpl.setBedNumber(bedAllocation.getBedNumber());
		bedAllocationImpl.setJoiningDate(bedAllocation.getJoiningDate());
		bedAllocationImpl.setAdmissionDate(bedAllocation.getAdmissionDate());
		bedAllocationImpl.setPatientName(bedAllocation.getPatientName());
		bedAllocationImpl.setAge(bedAllocation.getAge());
		bedAllocationImpl.setGender(bedAllocation.getGender());
		bedAllocationImpl.setMobile(bedAllocation.getMobile());
		bedAllocationImpl.setEmail(bedAllocation.getEmail());
		bedAllocationImpl.setStatus(bedAllocation.getStatus());
		bedAllocationImpl.setCreatedUserId(bedAllocation.getCreatedUserId());

		return bedAllocationImpl;
	}

	/**
	 * Returns the bed allocation with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the bed allocation
	 * @return the bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation findByPrimaryKey(Serializable primaryKey)
		throws NoSuchBedAllocationException, SystemException {
		BedAllocation bedAllocation = fetchByPrimaryKey(primaryKey);

		if (bedAllocation == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchBedAllocationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return bedAllocation;
	}

	/**
	 * Returns the bed allocation with the primary key or throws a {@link com.napier.portal.db.NoSuchBedAllocationException} if it could not be found.
	 *
	 * @param bedAllocationId the primary key of the bed allocation
	 * @return the bed allocation
	 * @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation findByPrimaryKey(long bedAllocationId)
		throws NoSuchBedAllocationException, SystemException {
		return findByPrimaryKey((Serializable)bedAllocationId);
	}

	/**
	 * Returns the bed allocation with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the bed allocation
	 * @return the bed allocation, or <code>null</code> if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		BedAllocation bedAllocation = (BedAllocation)EntityCacheUtil.getResult(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
				BedAllocationImpl.class, primaryKey);

		if (bedAllocation == _nullBedAllocation) {
			return null;
		}

		if (bedAllocation == null) {
			Session session = null;

			try {
				session = openSession();

				bedAllocation = (BedAllocation)session.get(BedAllocationImpl.class,
						primaryKey);

				if (bedAllocation != null) {
					cacheResult(bedAllocation);
				}
				else {
					EntityCacheUtil.putResult(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
						BedAllocationImpl.class, primaryKey, _nullBedAllocation);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(BedAllocationModelImpl.ENTITY_CACHE_ENABLED,
					BedAllocationImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return bedAllocation;
	}

	/**
	 * Returns the bed allocation with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param bedAllocationId the primary key of the bed allocation
	 * @return the bed allocation, or <code>null</code> if a bed allocation with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BedAllocation fetchByPrimaryKey(long bedAllocationId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)bedAllocationId);
	}

	/**
	 * Returns all the bed allocations.
	 *
	 * @return the bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the bed allocations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of bed allocations
	 * @param end the upper bound of the range of bed allocations (not inclusive)
	 * @return the range of bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the bed allocations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of bed allocations
	 * @param end the upper bound of the range of bed allocations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BedAllocation> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<BedAllocation> list = (List<BedAllocation>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_BEDALLOCATION);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_BEDALLOCATION;

				if (pagination) {
					sql = sql.concat(BedAllocationModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<BedAllocation>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BedAllocation>(list);
				}
				else {
					list = (List<BedAllocation>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the bed allocations from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (BedAllocation bedAllocation : findAll()) {
			remove(bedAllocation);
		}
	}

	/**
	 * Returns the number of bed allocations.
	 *
	 * @return the number of bed allocations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_BEDALLOCATION);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the bed allocation persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.napier.portal.db.model.BedAllocation")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<BedAllocation>> listenersList = new ArrayList<ModelListener<BedAllocation>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<BedAllocation>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(BedAllocationImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_BEDALLOCATION = "SELECT bedAllocation FROM BedAllocation bedAllocation";
	private static final String _SQL_SELECT_BEDALLOCATION_WHERE = "SELECT bedAllocation FROM BedAllocation bedAllocation WHERE ";
	private static final String _SQL_COUNT_BEDALLOCATION = "SELECT COUNT(bedAllocation) FROM BedAllocation bedAllocation";
	private static final String _SQL_COUNT_BEDALLOCATION_WHERE = "SELECT COUNT(bedAllocation) FROM BedAllocation bedAllocation WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "bedAllocation.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No BedAllocation exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No BedAllocation exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(BedAllocationPersistenceImpl.class);
	private static BedAllocation _nullBedAllocation = new BedAllocationImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<BedAllocation> toCacheModel() {
				return _nullBedAllocationCacheModel;
			}
		};

	private static CacheModel<BedAllocation> _nullBedAllocationCacheModel = new CacheModel<BedAllocation>() {
			@Override
			public BedAllocation toEntityModel() {
				return _nullBedAllocation;
			}
		};
}