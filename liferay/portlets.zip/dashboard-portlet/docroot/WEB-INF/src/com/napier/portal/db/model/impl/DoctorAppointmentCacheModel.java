/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.napier.portal.db.model.DoctorAppointment;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing DoctorAppointment in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see DoctorAppointment
 * @generated
 */
public class DoctorAppointmentCacheModel implements CacheModel<DoctorAppointment>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{appointmentId=");
		sb.append(appointmentId);
		sb.append(", appointmentNumber=");
		sb.append(appointmentNumber);
		sb.append(", appointmentDate=");
		sb.append(appointmentDate);
		sb.append(", doctorId=");
		sb.append(doctorId);
		sb.append(", mrNumber=");
		sb.append(mrNumber);
		sb.append(", creationDate=");
		sb.append(creationDate);
		sb.append(", fromTime=");
		sb.append(fromTime);
		sb.append(", toTime=");
		sb.append(toTime);
		sb.append(", status=");
		sb.append(status);
		sb.append(", patientName=");
		sb.append(patientName);
		sb.append(", age=");
		sb.append(age);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", mobile=");
		sb.append(mobile);
		sb.append(", email=");
		sb.append(email);
		sb.append(", complaint=");
		sb.append(complaint);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public DoctorAppointment toEntityModel() {
		DoctorAppointmentImpl doctorAppointmentImpl = new DoctorAppointmentImpl();

		doctorAppointmentImpl.setAppointmentId(appointmentId);

		if (appointmentNumber == null) {
			doctorAppointmentImpl.setAppointmentNumber(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setAppointmentNumber(appointmentNumber);
		}

		if (appointmentDate == Long.MIN_VALUE) {
			doctorAppointmentImpl.setAppointmentDate(null);
		}
		else {
			doctorAppointmentImpl.setAppointmentDate(new Date(appointmentDate));
		}

		if (doctorId == null) {
			doctorAppointmentImpl.setDoctorId(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setDoctorId(doctorId);
		}

		if (mrNumber == null) {
			doctorAppointmentImpl.setMrNumber(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setMrNumber(mrNumber);
		}

		if (creationDate == Long.MIN_VALUE) {
			doctorAppointmentImpl.setCreationDate(null);
		}
		else {
			doctorAppointmentImpl.setCreationDate(new Date(creationDate));
		}

		if (fromTime == null) {
			doctorAppointmentImpl.setFromTime(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setFromTime(fromTime);
		}

		if (toTime == null) {
			doctorAppointmentImpl.setToTime(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setToTime(toTime);
		}

		if (status == null) {
			doctorAppointmentImpl.setStatus(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setStatus(status);
		}

		if (patientName == null) {
			doctorAppointmentImpl.setPatientName(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setPatientName(patientName);
		}

		doctorAppointmentImpl.setAge(age);

		if (gender == null) {
			doctorAppointmentImpl.setGender(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setGender(gender);
		}

		if (mobile == null) {
			doctorAppointmentImpl.setMobile(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setMobile(mobile);
		}

		if (email == null) {
			doctorAppointmentImpl.setEmail(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setEmail(email);
		}

		if (complaint == null) {
			doctorAppointmentImpl.setComplaint(StringPool.BLANK);
		}
		else {
			doctorAppointmentImpl.setComplaint(complaint);
		}

		doctorAppointmentImpl.resetOriginalValues();

		return doctorAppointmentImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		appointmentId = objectInput.readLong();
		appointmentNumber = objectInput.readUTF();
		appointmentDate = objectInput.readLong();
		doctorId = objectInput.readUTF();
		mrNumber = objectInput.readUTF();
		creationDate = objectInput.readLong();
		fromTime = objectInput.readUTF();
		toTime = objectInput.readUTF();
		status = objectInput.readUTF();
		patientName = objectInput.readUTF();
		age = objectInput.readInt();
		gender = objectInput.readUTF();
		mobile = objectInput.readUTF();
		email = objectInput.readUTF();
		complaint = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(appointmentId);

		if (appointmentNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(appointmentNumber);
		}

		objectOutput.writeLong(appointmentDate);

		if (doctorId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(doctorId);
		}

		if (mrNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mrNumber);
		}

		objectOutput.writeLong(creationDate);

		if (fromTime == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(fromTime);
		}

		if (toTime == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(toTime);
		}

		if (status == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(status);
		}

		if (patientName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(patientName);
		}

		objectOutput.writeInt(age);

		if (gender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(gender);
		}

		if (mobile == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(mobile);
		}

		if (email == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (complaint == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(complaint);
		}
	}

	public long appointmentId;
	public String appointmentNumber;
	public long appointmentDate;
	public String doctorId;
	public String mrNumber;
	public long creationDate;
	public String fromTime;
	public String toTime;
	public String status;
	public String patientName;
	public int age;
	public String gender;
	public String mobile;
	public String email;
	public String complaint;
}