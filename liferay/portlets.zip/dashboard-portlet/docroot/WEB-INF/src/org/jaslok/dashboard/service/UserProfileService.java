package org.jaslok.dashboard.service;

import java.util.Date;

import org.apache.log4j.Logger;
import org.jaslok.dashboard.model.UserProfile;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.User;
import com.liferay.portal.service.AddressLocalServiceUtil;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.DiagnosticReportLocalServiceUtil;
import com.napier.portal.db.service.DischargeSummaryLocalServiceUtil;
import com.napier.portal.db.service.LabReportLocalServiceUtil;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;
import com.napier.portal.db.service.PatientBillLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */

@Service
@SuppressWarnings("all")
public class UserProfileService {

    private static Logger logger = Logger.getLogger(UserProfileService.class.getSimpleName());

    public NapierUser createDummyUser(User user) throws SystemException {

        try {
            return NapierUserLocalServiceUtil.getByportalUserId(user.getUserId());

        } catch (Exception e) {
            return crateUser(user);
        }
    }

    public NapierUser crateUser(User user) throws SystemException {
        long napierUserId = CounterLocalServiceUtil.increment(NapierUser.class.getSimpleName());

        NapierUser napierUser = NapierUserLocalServiceUtil.createNapierUser(napierUserId);
        napierUser.setPortalUserId(user.getUserId());
        napierUser.setGender("Male");
        napierUser.setAge(20);
        napierUser.setEmail(user.getEmailAddress());
        napierUser.setName(user.getFirstName());
        napierUser.setMrNumber("MR0002992392");
        napierUser.setMobile("9000211000");
        napierUser.setAddress("FLAT NO : 101 , SREE NILAYAM ,MUMBAI");

        napierUser = NapierUserLocalServiceUtil.updateNapierUser(napierUser);

        return napierUser;
    }

    /* not using this for now */
    public void createAddress(User user) throws SystemException {
        long addressId = CounterLocalServiceUtil.increment(Address.class.getSimpleName());
        Address address = AddressLocalServiceUtil.createAddress(addressId);
        address.setCompanyId(user.getCompanyId());
        address.setMailing(true);
        address.setPrimary(true);
        address.setCity("KPHB");
        address.setStreet1("FLAT No 103, Sree Nilayam ");
        address.setStreet2("Sai ram colony ");
        address.setStreet3("NEAR HAFEEZPET ");
        address.setZip("500049");
        address = AddressLocalServiceUtil.updateAddress(address);
        // user.getAddresses().add(address);
    }

    public UserProfile prepatePortalUser(NapierUser napierUser, User user) throws PortalException, SystemException {

        UserProfile userProfile = new UserProfile();

        userProfile.setFirstname(user.getFirstName());
        userProfile.setLastname(user.getLastName());
        userProfile.setAge(napierUser.getAge());
        userProfile.setMrNumber(napierUser.getMrNumber());
        userProfile.setGender(napierUser.getGender());
        userProfile.setDob(new Date());// user.getBirthday()
        userProfile.setMobile(napierUser.getMobile());
        userProfile.setAddress(napierUser.getAddress());

        return userProfile;

    }

    public void prepateReportCount(String mrNumber, Model model) {

        try {
            int labReportCount = LabReportLocalServiceUtil.getBymrNumber(mrNumber).size();

            model.addAttribute("labReportCount", labReportCount);

            int dischargeSummaryCount = DischargeSummaryLocalServiceUtil.getBymrNumber(mrNumber).size();

            model.addAttribute("dischargeSummaryCount", dischargeSummaryCount);

            int diagnosticReportCount = DiagnosticReportLocalServiceUtil.getBymrNumber(mrNumber).size();

            model.addAttribute("diagnosticReportCount", diagnosticReportCount);

            int patientBillCount = PatientBillLocalServiceUtil.getBymrNumber(mrNumber).size();

            model.addAttribute("patientBillCount", patientBillCount);
        } catch (SystemException exception) {
            logger.error(exception.getMessage());
        }

    }

}
