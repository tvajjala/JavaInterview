package org.jaslok.dashboard.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.napier.portal.db.model.BedAllocation;
import com.napier.portal.db.model.DoctorAppointment;
import com.napier.portal.db.service.BedAllocationLocalServiceUtil;
import com.napier.portal.db.service.DoctorAppointmentLocalServiceUtil;

@Service
@SuppressWarnings("all")
public class DoctorAppointmentService {

    private static Logger logger = Logger.getLogger(DoctorAppointmentService.class.getSimpleName());

    public void prepateDummyData(long createdByUserId) throws SystemException {

        List<DoctorAppointment> reports = DoctorAppointmentLocalServiceUtil.getByuserId(createdByUserId);

        if (reports.isEmpty()) {
            for (int i = 0; i < 20; i++) {
                long appointmentId = CounterLocalServiceUtil.increment(DoctorAppointment.class.getSimpleName());
                DoctorAppointment labReport = DoctorAppointmentLocalServiceUtil.createDoctorAppointment(appointmentId);
                labReport.setAppointmentNumber("APP01 " + i);
                labReport.setAppointmentDate(new Date());

                if (i % 2 == 0) {
                    labReport.setDoctorName("Dr. Ajay");
                    labReport.setSpecialization("Orthopedist");
                    labReport.setStatus("Due");
                } else if (i % 3 == 0) {
                    labReport.setDoctorName("Dr. Samuel");
                    labReport.setSpecialization("Cardiologist");
                    labReport.setStatus("Cancelled");
                } else {
                    labReport.setDoctorName("Dr. kiran");
                    labReport.setSpecialization("General Surgen");
                    labReport.setStatus("Completed");
                }

                labReport.setCreatedByUserId(createdByUserId);

                DoctorAppointmentLocalServiceUtil.updateDoctorAppointment(labReport);
            }
        }
    }

    public void prepareResults(RenderRequest renderRequest, RenderResponse renderResponse, Model model) throws SystemException {
        List<String> headerNames = new ArrayList<String>();

        headerNames.add("Appointment No.");
        headerNames.add("Appointment Date");
        headerNames.add("Doctor Name");
        headerNames.add("Specialization");
        headerNames.add("Status");

        PortletURL portletURL = renderResponse.createRenderURL();

        try {
            portletURL.setWindowState(WindowState.MAXIMIZED);
        } catch (WindowStateException e) {
            logger.error(e.getMessage());
        }
        
        SearchContainer<DoctorAppointment> searchContainer = new SearchContainer<DoctorAppointment>(renderRequest, null, null,
                SearchContainer.DEFAULT_CUR_PARAM, 3, portletURL, headerNames, "you don't any doctot appointments");
        logger.info(searchContainer.getCurParam()+"  doctor Appointments =  "+ String.valueOf(searchContainer.getCur())+"== "+ renderRequest.getParameter("daParam"));
        
        portletURL.setParameter("daParam", (renderRequest.getParameter("daParam")==null)?String.valueOf(1):renderRequest.getParameter("daParam"));
        
        User user = (User) renderRequest.getAttribute(WebKeys.USER);
        long createdUserId = user.getUserId();

        // searchContainer.setOrderByComparator(new BedOrderComparator());

        List<DoctorAppointment> list = DoctorAppointmentLocalServiceUtil.getByuserId(createdUserId, searchContainer.getStart(), searchContainer.getEnd());

        int total = DoctorAppointmentLocalServiceUtil.getByuserId(createdUserId).size();
        searchContainer.setTotal(total);
        searchContainer.setResults(list);
        searchContainer.setDeltaConfigurable(true);
        List<ResultRow> resultRows = searchContainer.getResultRows();
        /*
         * int i = 0; for (DoctorAppointment labReport : list) { ResultRow row = new ResultRow(labReport, labReport.getAppointmentId(), i++);
         * row.addText(labReport.getAppointmentNumber()); row.addText((labReport.getAppointmentDate()==null)?"-":labReport.getAppointmentDate().toString());
         * row.addText(labReport.getDoctorName()); row.addText(labReport.getSpecialization()); row.addText(labReport.getStatus()); resultRows.add(row); }
         */

        logger.info("viewing  " + list.size() + " of " + total);

        model.addAttribute("doctorAppointmentSearchContainer", searchContainer);
    }
}
