package org.jaslok.dashboard.processor;

import org.apache.log4j.Logger;
import org.jaslok.dashboard.service.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;

import com.liferay.portal.kernel.exception.SystemException;

/**
 * 
 * @author tvajjala
 * 
 *         creates dummy data in napier user table
 */
public class DataLoader {

    private static Logger logger = Logger.getLogger(DataLoader.class.getSimpleName());
    @Autowired
    UserProfileService userProfileService;

    public void init() {

        try {

            logger.info("inserting dummy data into Napier user table ");

            userProfileService.insertDummyData();
        } catch (SystemException e) {

            e.printStackTrace();
        }

    }

}
