package org.jaslok.dashboard.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.napier.portal.db.model.BedAllocation;
import com.napier.portal.db.model.BedReservation;
import com.napier.portal.db.model.LabReport;
import com.napier.portal.db.service.BedAllocationLocalServiceUtil;
import com.napier.portal.db.service.BedReservationLocalServiceUtil;
import com.napier.portal.db.service.LabReportLocalServiceUtil;

@Service
@SuppressWarnings("all")
public class BedAllocationService {

    private static Logger logger = Logger.getLogger(BedAllocationService.class.getSimpleName());

    public void prepateDummyData(long createdUserId) throws SystemException {

        List<BedAllocation> reports = BedAllocationLocalServiceUtil.getByuserId(createdUserId);
        if (reports.isEmpty()) {
            for (int i = 0; i < 20; i++) {
                long bedAllocationId = CounterLocalServiceUtil.increment(BedAllocation.class.getSimpleName());
                BedAllocation labReport = BedAllocationLocalServiceUtil.createBedAllocation(bedAllocationId);
                labReport.setBedNumber("Master");
                labReport.setAdmissionDate(new Date());
                labReport.setBedReservationDate(new Date());
                labReport.setBedReservationNumber("RES " + i);
                labReport.setStatus("Requested");
                labReport.setPatientName("Sagar Srinivas");
                labReport.setCreatedUserId(createdUserId);
                labReport.setAge(i + 20);
                labReport.setGender("MALE");
                BedAllocationLocalServiceUtil.updateBedAllocation(labReport);
            }
        }
    }

    public void prepareResults(RenderRequest renderRequest, RenderResponse renderResponse, Model model) throws SystemException {
        List<String> headerNames = new ArrayList<String>();

        headerNames.add("Bed Registration Number");
        headerNames.add("Bed Reservation Date");
        headerNames.add("Patient Name");
        headerNames.add("Age / Gender");
        headerNames.add("Bed Class");
        headerNames.add("Status");

        PortletURL portletURL = renderResponse.createRenderURL();

        try {
            portletURL.setWindowState(WindowState.MAXIMIZED);
        } catch (WindowStateException e) {
            logger.error(e.getMessage());
        }

        SearchContainer<BedAllocation> searchContainer = new SearchContainer<BedAllocation>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM, 3,
                portletURL, headerNames, "you haven't raised any bed requests");

        portletURL.setParameter(searchContainer.getCurParam(), String.valueOf(searchContainer.getCur()));
        User user = (User) renderRequest.getAttribute(WebKeys.USER);
        long createdUserId = user.getUserId();

        // searchContainer.setOrderByComparator(new BedOrderComparator());

        List<BedAllocation> list = BedAllocationLocalServiceUtil.getByuserId(createdUserId, searchContainer.getStart(), searchContainer.getEnd());

        int total = BedAllocationLocalServiceUtil.getByuserId(createdUserId).size();
        searchContainer.setTotal(total);
        searchContainer.setResults(list);
        searchContainer.setDeltaConfigurable(true);
        List<ResultRow> resultRows = searchContainer.getResultRows();

      /*  int i = 0;
        for (BedAllocation labReport : list) {
            ResultRow row = new ResultRow(labReport, labReport.getBedAllocationId(), i++);
            row.addText(labReport.getBedReservationNumber());
            row.addText((labReport.getBedReservationDate() != null) ? labReport.getBedReservationDate().toString() : labReport.getAdmissionDate().toString());
            row.addText(labReport.getPatientName());
            row.addText(labReport.getAge() + " / " + labReport.getGender());
            row.addText(labReport.getBedNumber());
            row.addText(labReport.getStatus());
            resultRows.add(row);
        }*/

        logger.info("viewing  " + list.size() + " of " + total);

        model.addAttribute("bedAllocationSearchContainer", searchContainer);

    }
}
