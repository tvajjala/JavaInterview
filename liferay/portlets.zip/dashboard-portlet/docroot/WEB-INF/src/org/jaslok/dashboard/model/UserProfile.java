package org.jaslok.dashboard.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author tvajjala
 * 
 */
/*
 * this bean properties should match napier db
 */
public class UserProfile implements Serializable {

    private static final long serialVersionUID = 1092416193138914488L;

    private String firstname;
    private String lastname;
    private String mrNumber;
    private String gender;
    private String mobile;
    private String address;

    private Date dob;
    private Integer age;

    private String practiceID;

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMrNumber(String mrNumber) {
        this.mrNumber = mrNumber;
    }

    public String getMrNumber() {
        return mrNumber;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getPracticeID() {
        return practiceID;
    }

    public void setPracticeID(String practiceID) {
        this.practiceID = practiceID;
    }

}
