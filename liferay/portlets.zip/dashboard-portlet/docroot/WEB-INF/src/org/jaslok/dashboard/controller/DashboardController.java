package org.jaslok.dashboard.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.log4j.Logger;
import org.jaslok.dashboard.model.UserProfile;
import org.jaslok.dashboard.service.BedAllocationService;
import org.jaslok.dashboard.service.DoctorAppointmentService;
import org.jaslok.dashboard.service.UserProfileService;
import org.jaslok.dashboard.util.PasswordValidator;
import org.jaslok.dashboard.util.UserType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.portal.UserPasswordException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.napier.portal.db.NoSuchNapierUserException;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */
@Controller
public class DashboardController {

    private static Logger logger = Logger.getLogger(DashboardController.class.getSimpleName());

    @Autowired
    UserProfileService userProfileService;

    @Autowired
    BedAllocationService bedAllocationService;

    @Autowired
    DoctorAppointmentService doctorAppointmentService;

    @RenderMapping
    public String defaultView(RenderRequest renderRequest, RenderResponse renderResponse, Model model) {
        try {

            User user = (User) renderRequest.getAttribute(WebKeys.USER);

            NapierUser napierUser = userProfileService.createDummyUser(user);
            UserProfile userProfile = userProfileService.prepatePortalUser(napierUser, user);
            model.addAttribute("userProfile", userProfile);

            userProfileService.prepateReportCount(napierUser.getMrNumber(), model);
            bedAllocationService.prepateDummyData(user.getUserId());

            bedAllocationService.prepareResults(renderRequest, renderResponse, model);

            doctorAppointmentService.prepateDummyData(user.getUserId());
            doctorAppointmentService.prepareResults(renderRequest, renderResponse, model);

            String userType = UserType.PATIENT.getTitle().toLowerCase();

            return userType + "/dashboard";

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());

        }
        return "empty";
    }

    @RenderMapping(params = "action=myProfilePage")
    public String myProfile(RenderRequest renderRequest, RenderResponse renderResponse, Model model) {
        logger.info("my profile page ");

        User user = (User) renderRequest.getAttribute(WebKeys.USER);

        try {
            NapierUser napierUser = NapierUserLocalServiceUtil.getByportalUserId(user.getUserId());

            model.addAttribute("myProfile", napierUser);
        } catch (NoSuchNapierUserException e) {

            e.printStackTrace();
        } catch (SystemException e) {

            e.printStackTrace();
        }

        return "myprofile";
    }

    @RenderMapping(params = "action=changePasswordPage")
    public String changePassword(RenderRequest renderRequest, RenderResponse renderResponse, Model model) {
        logger.info("changePassword");

        User user = (User) renderRequest.getAttribute(WebKeys.USER);
        model.addAttribute("username", user.getEmailAddress());

        return "changepassword";
    }

    @ResourceMapping(value = "updateProfile")
    public void updateProfile(ResourceRequest request, ResourceResponse response) throws IOException, PortletException {
        logger.info("updateProfile");
        JSONObject object = JSONFactoryUtil.createJSONObject();
        long napierUserId = ParamUtil.getLong(request, "napierId");
        try {

            NapierUser napierUser = NapierUserLocalServiceUtil.getNapierUser(napierUserId);
            napierUser.setStreet1(ParamUtil.getString(request, "street1"));
            napierUser.setStreet2(ParamUtil.getString(request, "street2"));
            napierUser.setAddress(ParamUtil.getString(request, "address"));
            napierUser.setEmail(ParamUtil.getString(request, "email"));
            napierUser.setMobile(ParamUtil.getString(request, "mobile"));
            napierUser.setPostalCode(ParamUtil.getString(request, "postalCode"));
            NapierUserLocalServiceUtil.updateNapierUser(napierUser);

            object.put("status", "success");
            object.put("message", "profile updated successfully");

        } catch (Exception e) {
            object.put("status", "fail");
            object.put("message", "profile updation failed.  Reason: " + e.getMessage());
        }

        response.setContentType("application/json");

        PrintWriter out = response.getWriter();
        out.write(object.toString());
        out.flush();
        out.close();
    }

    @ResourceMapping(value = "updatePassword")
    public void updatePassword(ResourceRequest request, ResourceResponse response) throws IOException, PortletException {
        logger.info("           updatePassword          ");
        JSONObject object = JSONFactoryUtil.createJSONObject();

        try {
            User user = (User) request.getAttribute(WebKeys.USER);

            String oldPassword = ParamUtil.getString(request, "oldPassword");
            String newPassword = ParamUtil.getString(request, "newPassword");
            String confirmPassword = ParamUtil.getString(request, "confirmPassword");

            // validate existing password
            int flag = UserLocalServiceUtil.authenticateByEmailAddress(user.getCompanyId(), user.getEmailAddress(), oldPassword, null, null, null);

            if (flag == 1) {//

                // verify password policy
                if (!PasswordValidator.validatePassword(newPassword)) {
                    object.put("status", "fail");
                    object.put("message", "password updation failed.Reason:<b> password not matching password policy.</b>");
                } else {
                    UserLocalServiceUtil.updatePassword(user.getUserId(), newPassword, confirmPassword, false);
                    object.put("status", "success");
                    object.put("message", "password updated successfully");
                }
            } else {
                object.put("status", "fail");
                object.put("message", "password updation failed.Reason:<b> Invalid existing password. </b>");
            }

        } catch (Exception e) {

            if (e instanceof UserPasswordException) {
                object.put("status", "fail");
                object.put("message", "<b> please enter all mandatory fields.</b>");
            } else {
                object.put("status", "fail");
                object.put("message", "password updation failed.Reason:<b>  Password not matching. </b>");
            }
        }

        response.setContentType("application/json");

        PrintWriter out = response.getWriter();
        out.write(object.toString());
        out.flush();
        out.close();
    }

}