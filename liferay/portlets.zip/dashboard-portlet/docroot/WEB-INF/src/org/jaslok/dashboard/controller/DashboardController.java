package org.jaslok.dashboard.controller;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.log4j.Logger;
import org.jaslok.dashboard.model.UserProfile;
import org.jaslok.dashboard.service.BedAllocationService;
import org.jaslok.dashboard.service.DoctorAppointmentService;
import org.jaslok.dashboard.service.UserProfileService;
import org.jaslok.dashboard.util.UserType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.napier.portal.db.model.NapierUser;

/**
 * 
 * @author tvajjala
 * 
 */
@Controller
public class DashboardController {

    private static Logger logger = Logger.getLogger(DashboardController.class.getSimpleName());

    @Autowired
    UserProfileService userProfileService;

    @Autowired
    BedAllocationService bedAllocationService;

    @Autowired
    DoctorAppointmentService doctorAppointmentService;

    @RenderMapping
    public String defaultView(RenderRequest renderRequest, RenderResponse renderResponse, Model model) {
        try {

            User user = (User) renderRequest.getAttribute(WebKeys.USER);

            logger.info("user.getEmailAddress() :  " + user.getEmailAddress());

            NapierUser napierUser = userProfileService.createDummyUser(user);
            UserProfile userProfile = userProfileService.prepatePortalUser(napierUser, user);
            model.addAttribute("userProfile", userProfile);

            userProfileService.prepateReportCount(napierUser.getMrNumber(), model);
            bedAllocationService.prepateDummyData(user.getUserId());
            
            bedAllocationService.prepareResults(renderRequest, renderResponse, model);

            doctorAppointmentService.prepateDummyData(user.getUserId());
            doctorAppointmentService.prepareResults(renderRequest, renderResponse, model);

            String userType = UserType.PATIENT.getTitle().toLowerCase();

            return userType + "/dashboard";

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());

        }
        return "empty";

    }

}