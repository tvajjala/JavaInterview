/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.napier.portal.db.model.Deposit;

/**
 * The persistence interface for the deposit service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DepositPersistenceImpl
 * @see DepositUtil
 * @generated
 */
public interface DepositPersistence extends BasePersistence<Deposit> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link DepositUtil} to access the deposit persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the deposits where patientBillId = &#63;.
	*
	* @param patientBillId the patient bill ID
	* @return the matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findBypatientBillId(
		long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the deposits where patientBillId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param patientBillId the patient bill ID
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @return the range of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findBypatientBillId(
		long patientBillId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the deposits where patientBillId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param patientBillId the patient bill ID
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findBypatientBillId(
		long patientBillId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first deposit in the ordered set where patientBillId = &#63;.
	*
	* @param patientBillId the patient bill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findBypatientBillId_First(
		long patientBillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the first deposit in the ordered set where patientBillId = &#63;.
	*
	* @param patientBillId the patient bill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchBypatientBillId_First(
		long patientBillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last deposit in the ordered set where patientBillId = &#63;.
	*
	* @param patientBillId the patient bill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findBypatientBillId_Last(
		long patientBillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the last deposit in the ordered set where patientBillId = &#63;.
	*
	* @param patientBillId the patient bill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchBypatientBillId_Last(
		long patientBillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the deposits before and after the current deposit in the ordered set where patientBillId = &#63;.
	*
	* @param depositId the primary key of the current deposit
	* @param patientBillId the patient bill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit[] findBypatientBillId_PrevAndNext(
		long depositId, long patientBillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Removes all the deposits where patientBillId = &#63; from the database.
	*
	* @param patientBillId the patient bill ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBypatientBillId(long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of deposits where patientBillId = &#63;.
	*
	* @param patientBillId the patient bill ID
	* @return the number of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public int countBypatientBillId(long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the deposit where depositNumber = &#63; or throws a {@link com.napier.portal.db.NoSuchDepositException} if it could not be found.
	*
	* @param depositNumber the deposit number
	* @return the matching deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findBydepositNumber(
		java.lang.String depositNumber)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the deposit where depositNumber = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param depositNumber the deposit number
	* @return the matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchBydepositNumber(
		java.lang.String depositNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the deposit where depositNumber = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param depositNumber the deposit number
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchBydepositNumber(
		java.lang.String depositNumber, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the deposit where depositNumber = &#63; from the database.
	*
	* @param depositNumber the deposit number
	* @return the deposit that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit removeBydepositNumber(
		java.lang.String depositNumber)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the number of deposits where depositNumber = &#63;.
	*
	* @param depositNumber the deposit number
	* @return the number of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public int countBydepositNumber(java.lang.String depositNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the deposits where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the deposits where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @return the range of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the deposits where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first deposit in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the first deposit in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last deposit in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the last deposit in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the deposits before and after the current deposit in the ordered set where mrNumber = &#63;.
	*
	* @param depositId the primary key of the current deposit
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit[] findBymrNumber_PrevAndNext(
		long depositId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Removes all the deposits where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of deposits where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the deposits where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the deposits where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @return the range of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the deposits where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first deposit in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the first deposit in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last deposit in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the last deposit in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching deposit, or <code>null</code> if a matching deposit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the deposits before and after the current deposit in the ordered set where ipNumber = &#63;.
	*
	* @param depositId the primary key of the current deposit
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit[] findByipNumber_PrevAndNext(
		long depositId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Removes all the deposits where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of deposits where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching deposits
	* @throws SystemException if a system exception occurred
	*/
	public int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the deposit in the entity cache if it is enabled.
	*
	* @param deposit the deposit
	*/
	public void cacheResult(com.napier.portal.db.model.Deposit deposit);

	/**
	* Caches the deposits in the entity cache if it is enabled.
	*
	* @param deposits the deposits
	*/
	public void cacheResult(
		java.util.List<com.napier.portal.db.model.Deposit> deposits);

	/**
	* Creates a new deposit with the primary key. Does not add the deposit to the database.
	*
	* @param depositId the primary key for the new deposit
	* @return the new deposit
	*/
	public com.napier.portal.db.model.Deposit create(long depositId);

	/**
	* Removes the deposit with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param depositId the primary key of the deposit
	* @return the deposit that was removed
	* @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit remove(long depositId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	public com.napier.portal.db.model.Deposit updateImpl(
		com.napier.portal.db.model.Deposit deposit)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the deposit with the primary key or throws a {@link com.napier.portal.db.NoSuchDepositException} if it could not be found.
	*
	* @param depositId the primary key of the deposit
	* @return the deposit
	* @throws com.napier.portal.db.NoSuchDepositException if a deposit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit findByPrimaryKey(long depositId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDepositException;

	/**
	* Returns the deposit with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param depositId the primary key of the deposit
	* @return the deposit, or <code>null</code> if a deposit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.Deposit fetchByPrimaryKey(long depositId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the deposits.
	*
	* @return the deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the deposits.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @return the range of deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the deposits.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DepositModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of deposits
	* @param end the upper bound of the range of deposits (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of deposits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.Deposit> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the deposits from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of deposits.
	*
	* @return the number of deposits
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}