/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class NapierUserSoap implements Serializable {
	public static NapierUserSoap toSoapModel(NapierUser model) {
		NapierUserSoap soapModel = new NapierUserSoap();

		soapModel.setNapierUserId(model.getNapierUserId());
		soapModel.setPortalUserId(model.getPortalUserId());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setTpaId(model.getTpaId());
		soapModel.setCoroporateId(model.getCoroporateId());
		soapModel.setDoctorId(model.getDoctorId());
		soapModel.setAge(model.getAge());
		soapModel.setMobile(model.getMobile());
		soapModel.setGender(model.getGender());
		soapModel.setSpecialization(model.getSpecialization());
		soapModel.setUserType(model.getUserType());
		soapModel.setEmail(model.getEmail());
		soapModel.setName(model.getName());
		soapModel.setAddress(model.getAddress());
		soapModel.setStreet1(model.getStreet1());
		soapModel.setStreet2(model.getStreet2());
		soapModel.setPostalCode(model.getPostalCode());

		return soapModel;
	}

	public static NapierUserSoap[] toSoapModels(NapierUser[] models) {
		NapierUserSoap[] soapModels = new NapierUserSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static NapierUserSoap[][] toSoapModels(NapierUser[][] models) {
		NapierUserSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new NapierUserSoap[models.length][models[0].length];
		}
		else {
			soapModels = new NapierUserSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static NapierUserSoap[] toSoapModels(List<NapierUser> models) {
		List<NapierUserSoap> soapModels = new ArrayList<NapierUserSoap>(models.size());

		for (NapierUser model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new NapierUserSoap[soapModels.size()]);
	}

	public NapierUserSoap() {
	}

	public long getPrimaryKey() {
		return _napierUserId;
	}

	public void setPrimaryKey(long pk) {
		setNapierUserId(pk);
	}

	public long getNapierUserId() {
		return _napierUserId;
	}

	public void setNapierUserId(long napierUserId) {
		_napierUserId = napierUserId;
	}

	public long getPortalUserId() {
		return _portalUserId;
	}

	public void setPortalUserId(long portalUserId) {
		_portalUserId = portalUserId;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public String getTpaId() {
		return _tpaId;
	}

	public void setTpaId(String tpaId) {
		_tpaId = tpaId;
	}

	public String getCoroporateId() {
		return _coroporateId;
	}

	public void setCoroporateId(String coroporateId) {
		_coroporateId = coroporateId;
	}

	public String getDoctorId() {
		return _doctorId;
	}

	public void setDoctorId(String doctorId) {
		_doctorId = doctorId;
	}

	public int getAge() {
		return _age;
	}

	public void setAge(int age) {
		_age = age;
	}

	public String getMobile() {
		return _mobile;
	}

	public void setMobile(String mobile) {
		_mobile = mobile;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public String getSpecialization() {
		return _specialization;
	}

	public void setSpecialization(String specialization) {
		_specialization = specialization;
	}

	public String getUserType() {
		return _userType;
	}

	public void setUserType(String userType) {
		_userType = userType;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public String getAddress() {
		return _address;
	}

	public void setAddress(String address) {
		_address = address;
	}

	public String getStreet1() {
		return _street1;
	}

	public void setStreet1(String street1) {
		_street1 = street1;
	}

	public String getStreet2() {
		return _street2;
	}

	public void setStreet2(String street2) {
		_street2 = street2;
	}

	public String getPostalCode() {
		return _postalCode;
	}

	public void setPostalCode(String postalCode) {
		_postalCode = postalCode;
	}

	private long _napierUserId;
	private long _portalUserId;
	private String _mrNumber;
	private String _tpaId;
	private String _coroporateId;
	private String _doctorId;
	private int _age;
	private String _mobile;
	private String _gender;
	private String _specialization;
	private String _userType;
	private String _email;
	private String _name;
	private String _address;
	private String _street1;
	private String _street2;
	private String _postalCode;
}