/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class DiagnosticReportSoap implements Serializable {
	public static DiagnosticReportSoap toSoapModel(DiagnosticReport model) {
		DiagnosticReportSoap soapModel = new DiagnosticReportSoap();

		soapModel.setDiagnosticId(model.getDiagnosticId());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setOrderNumber(model.getOrderNumber());
		soapModel.setOrderDate(model.getOrderDate());
		soapModel.setReportedOn(model.getReportedOn());
		soapModel.setIpNumber(model.getIpNumber());
		soapModel.setTestName(model.getTestName());
		soapModel.setDepartmentName(model.getDepartmentName());
		soapModel.setStatus(model.getStatus());
		soapModel.setDocPath(model.getDocPath());

		return soapModel;
	}

	public static DiagnosticReportSoap[] toSoapModels(DiagnosticReport[] models) {
		DiagnosticReportSoap[] soapModels = new DiagnosticReportSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static DiagnosticReportSoap[][] toSoapModels(
		DiagnosticReport[][] models) {
		DiagnosticReportSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new DiagnosticReportSoap[models.length][models[0].length];
		}
		else {
			soapModels = new DiagnosticReportSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static DiagnosticReportSoap[] toSoapModels(
		List<DiagnosticReport> models) {
		List<DiagnosticReportSoap> soapModels = new ArrayList<DiagnosticReportSoap>(models.size());

		for (DiagnosticReport model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new DiagnosticReportSoap[soapModels.size()]);
	}

	public DiagnosticReportSoap() {
	}

	public long getPrimaryKey() {
		return _diagnosticId;
	}

	public void setPrimaryKey(long pk) {
		setDiagnosticId(pk);
	}

	public long getDiagnosticId() {
		return _diagnosticId;
	}

	public void setDiagnosticId(long diagnosticId) {
		_diagnosticId = diagnosticId;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public String getOrderNumber() {
		return _orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		_orderNumber = orderNumber;
	}

	public Date getOrderDate() {
		return _orderDate;
	}

	public void setOrderDate(Date orderDate) {
		_orderDate = orderDate;
	}

	public Date getReportedOn() {
		return _reportedOn;
	}

	public void setReportedOn(Date reportedOn) {
		_reportedOn = reportedOn;
	}

	public String getIpNumber() {
		return _ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;
	}

	public String getTestName() {
		return _testName;
	}

	public void setTestName(String testName) {
		_testName = testName;
	}

	public String getDepartmentName() {
		return _departmentName;
	}

	public void setDepartmentName(String departmentName) {
		_departmentName = departmentName;
	}

	public boolean getStatus() {
		return _status;
	}

	public boolean isStatus() {
		return _status;
	}

	public void setStatus(boolean status) {
		_status = status;
	}

	public String getDocPath() {
		return _docPath;
	}

	public void setDocPath(String docPath) {
		_docPath = docPath;
	}

	private long _diagnosticId;
	private String _mrNumber;
	private String _orderNumber;
	private Date _orderDate;
	private Date _reportedOn;
	private String _ipNumber;
	private String _testName;
	private String _departmentName;
	private boolean _status;
	private String _docPath;
}