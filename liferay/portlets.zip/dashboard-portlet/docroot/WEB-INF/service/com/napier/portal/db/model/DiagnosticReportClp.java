/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.DiagnosticReportLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class DiagnosticReportClp extends BaseModelImpl<DiagnosticReport>
	implements DiagnosticReport {
	public DiagnosticReportClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return DiagnosticReport.class;
	}

	@Override
	public String getModelClassName() {
		return DiagnosticReport.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _diagnosticId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDiagnosticId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _diagnosticId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("diagnosticId", getDiagnosticId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("orderNumber", getOrderNumber());
		attributes.put("orderDate", getOrderDate());
		attributes.put("reportedOn", getReportedOn());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("testName", getTestName());
		attributes.put("departmentName", getDepartmentName());
		attributes.put("status", getStatus());
		attributes.put("docPath", getDocPath());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long diagnosticId = (Long)attributes.get("diagnosticId");

		if (diagnosticId != null) {
			setDiagnosticId(diagnosticId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String orderNumber = (String)attributes.get("orderNumber");

		if (orderNumber != null) {
			setOrderNumber(orderNumber);
		}

		Date orderDate = (Date)attributes.get("orderDate");

		if (orderDate != null) {
			setOrderDate(orderDate);
		}

		Date reportedOn = (Date)attributes.get("reportedOn");

		if (reportedOn != null) {
			setReportedOn(reportedOn);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String testName = (String)attributes.get("testName");

		if (testName != null) {
			setTestName(testName);
		}

		String departmentName = (String)attributes.get("departmentName");

		if (departmentName != null) {
			setDepartmentName(departmentName);
		}

		Boolean status = (Boolean)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String docPath = (String)attributes.get("docPath");

		if (docPath != null) {
			setDocPath(docPath);
		}
	}

	@Override
	public long getDiagnosticId() {
		return _diagnosticId;
	}

	@Override
	public void setDiagnosticId(long diagnosticId) {
		_diagnosticId = diagnosticId;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setDiagnosticId", long.class);

				method.invoke(_diagnosticReportRemoteModel, diagnosticId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_diagnosticReportRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOrderNumber() {
		return _orderNumber;
	}

	@Override
	public void setOrderNumber(String orderNumber) {
		_orderNumber = orderNumber;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setOrderNumber", String.class);

				method.invoke(_diagnosticReportRemoteModel, orderNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getOrderDate() {
		return _orderDate;
	}

	@Override
	public void setOrderDate(Date orderDate) {
		_orderDate = orderDate;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setOrderDate", Date.class);

				method.invoke(_diagnosticReportRemoteModel, orderDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getReportedOn() {
		return _reportedOn;
	}

	@Override
	public void setReportedOn(Date reportedOn) {
		_reportedOn = reportedOn;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setReportedOn", Date.class);

				method.invoke(_diagnosticReportRemoteModel, reportedOn);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getIpNumber() {
		return _ipNumber;
	}

	@Override
	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setIpNumber", String.class);

				method.invoke(_diagnosticReportRemoteModel, ipNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTestName() {
		return _testName;
	}

	@Override
	public void setTestName(String testName) {
		_testName = testName;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setTestName", String.class);

				method.invoke(_diagnosticReportRemoteModel, testName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDepartmentName() {
		return _departmentName;
	}

	@Override
	public void setDepartmentName(String departmentName) {
		_departmentName = departmentName;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setDepartmentName",
						String.class);

				method.invoke(_diagnosticReportRemoteModel, departmentName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getStatus() {
		return _status;
	}

	@Override
	public boolean isStatus() {
		return _status;
	}

	@Override
	public void setStatus(boolean status) {
		_status = status;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", boolean.class);

				method.invoke(_diagnosticReportRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDocPath() {
		return _docPath;
	}

	@Override
	public void setDocPath(String docPath) {
		_docPath = docPath;

		if (_diagnosticReportRemoteModel != null) {
			try {
				Class<?> clazz = _diagnosticReportRemoteModel.getClass();

				Method method = clazz.getMethod("setDocPath", String.class);

				method.invoke(_diagnosticReportRemoteModel, docPath);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getDiagnosticReportRemoteModel() {
		return _diagnosticReportRemoteModel;
	}

	public void setDiagnosticReportRemoteModel(
		BaseModel<?> diagnosticReportRemoteModel) {
		_diagnosticReportRemoteModel = diagnosticReportRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _diagnosticReportRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_diagnosticReportRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DiagnosticReportLocalServiceUtil.addDiagnosticReport(this);
		}
		else {
			DiagnosticReportLocalServiceUtil.updateDiagnosticReport(this);
		}
	}

	@Override
	public DiagnosticReport toEscapedModel() {
		return (DiagnosticReport)ProxyUtil.newProxyInstance(DiagnosticReport.class.getClassLoader(),
			new Class[] { DiagnosticReport.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DiagnosticReportClp clone = new DiagnosticReportClp();

		clone.setDiagnosticId(getDiagnosticId());
		clone.setMrNumber(getMrNumber());
		clone.setOrderNumber(getOrderNumber());
		clone.setOrderDate(getOrderDate());
		clone.setReportedOn(getReportedOn());
		clone.setIpNumber(getIpNumber());
		clone.setTestName(getTestName());
		clone.setDepartmentName(getDepartmentName());
		clone.setStatus(getStatus());
		clone.setDocPath(getDocPath());

		return clone;
	}

	@Override
	public int compareTo(DiagnosticReport diagnosticReport) {
		int value = 0;

		value = DateUtil.compareTo(getOrderDate(),
				diagnosticReport.getOrderDate());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DiagnosticReportClp)) {
			return false;
		}

		DiagnosticReportClp diagnosticReport = (DiagnosticReportClp)obj;

		long primaryKey = diagnosticReport.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{diagnosticId=");
		sb.append(getDiagnosticId());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", orderNumber=");
		sb.append(getOrderNumber());
		sb.append(", orderDate=");
		sb.append(getOrderDate());
		sb.append(", reportedOn=");
		sb.append(getReportedOn());
		sb.append(", ipNumber=");
		sb.append(getIpNumber());
		sb.append(", testName=");
		sb.append(getTestName());
		sb.append(", departmentName=");
		sb.append(getDepartmentName());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", docPath=");
		sb.append(getDocPath());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(34);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.DiagnosticReport");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>diagnosticId</column-name><column-value><![CDATA[");
		sb.append(getDiagnosticId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>orderNumber</column-name><column-value><![CDATA[");
		sb.append(getOrderNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>orderDate</column-name><column-value><![CDATA[");
		sb.append(getOrderDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>reportedOn</column-name><column-value><![CDATA[");
		sb.append(getReportedOn());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ipNumber</column-name><column-value><![CDATA[");
		sb.append(getIpNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>testName</column-name><column-value><![CDATA[");
		sb.append(getTestName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>departmentName</column-name><column-value><![CDATA[");
		sb.append(getDepartmentName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>docPath</column-name><column-value><![CDATA[");
		sb.append(getDocPath());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _diagnosticId;
	private String _mrNumber;
	private String _orderNumber;
	private Date _orderDate;
	private Date _reportedOn;
	private String _ipNumber;
	private String _testName;
	private String _departmentName;
	private boolean _status;
	private String _docPath;
	private BaseModel<?> _diagnosticReportRemoteModel;
}