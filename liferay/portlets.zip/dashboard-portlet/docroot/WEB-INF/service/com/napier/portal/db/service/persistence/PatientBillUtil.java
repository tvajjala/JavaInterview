/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.napier.portal.db.model.PatientBill;

import java.util.List;

/**
 * The persistence utility for the patient bill service. This utility wraps {@link PatientBillPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PatientBillPersistence
 * @see PatientBillPersistenceImpl
 * @generated
 */
public class PatientBillUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(PatientBill patientBill) {
		getPersistence().clearCache(patientBill);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<PatientBill> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<PatientBill> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<PatientBill> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static PatientBill update(PatientBill patientBill)
		throws SystemException {
		return getPersistence().update(patientBill);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static PatientBill update(PatientBill patientBill,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(patientBill, serviceContext);
	}

	/**
	* Returns all the patient bills where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber);
	}

	/**
	* Returns a range of all the patient bills where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber, start, end);
	}

	/**
	* Returns an ordered range of all the patient bills where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBymrNumber(mrNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill[] findBymrNumber_PrevAndNext(
		long patientBillId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence()
				   .findBymrNumber_PrevAndNext(patientBillId, mrNumber,
			orderByComparator);
	}

	/**
	* Removes all the patient bills where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBymrNumber(mrNumber);
	}

	/**
	* Returns the number of patient bills where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBymrNumber(mrNumber);
	}

	/**
	* Returns all the patient bills where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber);
	}

	/**
	* Returns a range of all the patient bills where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber, start, end);
	}

	/**
	* Returns an ordered range of all the patient bills where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByipNumber(ipNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill[] findByipNumber_PrevAndNext(
		long patientBillId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence()
				   .findByipNumber_PrevAndNext(patientBillId, ipNumber,
			orderByComparator);
	}

	/**
	* Removes all the patient bills where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByipNumber(ipNumber);
	}

	/**
	* Returns the number of patient bills where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByipNumber(ipNumber);
	}

	/**
	* Returns all the patient bills where company = &#63;.
	*
	* @param company the company
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBycompany(
		java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycompany(company);
	}

	/**
	* Returns a range of all the patient bills where company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBycompany(
		java.lang.String company, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycompany(company, start, end);
	}

	/**
	* Returns an ordered range of all the patient bills where company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBycompany(
		java.lang.String company, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBycompany(company, start, end, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBycompany_First(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findBycompany_First(company, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBycompany_First(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBycompany_First(company, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBycompany_Last(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findBycompany_Last(company, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBycompany_Last(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBycompany_Last(company, orderByComparator);
	}

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where company = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill[] findBycompany_PrevAndNext(
		long patientBillId, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence()
				   .findBycompany_PrevAndNext(patientBillId, company,
			orderByComparator);
	}

	/**
	* Removes all the patient bills where company = &#63; from the database.
	*
	* @param company the company
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBycompany(java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBycompany(company);
	}

	/**
	* Returns the number of patient bills where company = &#63;.
	*
	* @param company the company
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static int countBycompany(java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBycompany(company);
	}

	/**
	* Returns all the patient bills where sponser = &#63;.
	*
	* @param sponser the sponser
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBysponser(
		java.lang.String sponser)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBysponser(sponser);
	}

	/**
	* Returns a range of all the patient bills where sponser = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBysponser(
		java.lang.String sponser, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBysponser(sponser, start, end);
	}

	/**
	* Returns an ordered range of all the patient bills where sponser = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBysponser(
		java.lang.String sponser, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBysponser(sponser, start, end, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBysponser_First(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findBysponser_First(sponser, orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBysponser_First(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBysponser_First(sponser, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBysponser_Last(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findBysponser_Last(sponser, orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBysponser_Last(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBysponser_Last(sponser, orderByComparator);
	}

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where sponser = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill[] findBysponser_PrevAndNext(
		long patientBillId, java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence()
				   .findBysponser_PrevAndNext(patientBillId, sponser,
			orderByComparator);
	}

	/**
	* Removes all the patient bills where sponser = &#63; from the database.
	*
	* @param sponser the sponser
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBysponser(java.lang.String sponser)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBysponser(sponser);
	}

	/**
	* Returns the number of patient bills where sponser = &#63;.
	*
	* @param sponser the sponser
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static int countBysponser(java.lang.String sponser)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBysponser(sponser);
	}

	/**
	* Returns all the patient bills where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBycompanySponser(
		java.lang.String sponser, java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycompanySponser(sponser, company);
	}

	/**
	* Returns a range of all the patient bills where sponser = &#63; and company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBycompanySponser(
		java.lang.String sponser, java.lang.String company, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBycompanySponser(sponser, company, start, end);
	}

	/**
	* Returns an ordered range of all the patient bills where sponser = &#63; and company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findBycompanySponser(
		java.lang.String sponser, java.lang.String company, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBycompanySponser(sponser, company, start, end,
			orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBycompanySponser_First(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence()
				   .findBycompanySponser_First(sponser, company,
			orderByComparator);
	}

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBycompanySponser_First(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycompanySponser_First(sponser, company,
			orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findBycompanySponser_Last(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence()
				   .findBycompanySponser_Last(sponser, company,
			orderByComparator);
	}

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchBycompanySponser_Last(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycompanySponser_Last(sponser, company,
			orderByComparator);
	}

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill[] findBycompanySponser_PrevAndNext(
		long patientBillId, java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence()
				   .findBycompanySponser_PrevAndNext(patientBillId, sponser,
			company, orderByComparator);
	}

	/**
	* Removes all the patient bills where sponser = &#63; and company = &#63; from the database.
	*
	* @param sponser the sponser
	* @param company the company
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBycompanySponser(java.lang.String sponser,
		java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBycompanySponser(sponser, company);
	}

	/**
	* Returns the number of patient bills where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static int countBycompanySponser(java.lang.String sponser,
		java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBycompanySponser(sponser, company);
	}

	/**
	* Caches the patient bill in the entity cache if it is enabled.
	*
	* @param patientBill the patient bill
	*/
	public static void cacheResult(
		com.napier.portal.db.model.PatientBill patientBill) {
		getPersistence().cacheResult(patientBill);
	}

	/**
	* Caches the patient bills in the entity cache if it is enabled.
	*
	* @param patientBills the patient bills
	*/
	public static void cacheResult(
		java.util.List<com.napier.portal.db.model.PatientBill> patientBills) {
		getPersistence().cacheResult(patientBills);
	}

	/**
	* Creates a new patient bill with the primary key. Does not add the patient bill to the database.
	*
	* @param patientBillId the primary key for the new patient bill
	* @return the new patient bill
	*/
	public static com.napier.portal.db.model.PatientBill create(
		long patientBillId) {
		return getPersistence().create(patientBillId);
	}

	/**
	* Removes the patient bill with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param patientBillId the primary key of the patient bill
	* @return the patient bill that was removed
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill remove(
		long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().remove(patientBillId);
	}

	public static com.napier.portal.db.model.PatientBill updateImpl(
		com.napier.portal.db.model.PatientBill patientBill)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(patientBill);
	}

	/**
	* Returns the patient bill with the primary key or throws a {@link com.napier.portal.db.NoSuchPatientBillException} if it could not be found.
	*
	* @param patientBillId the primary key of the patient bill
	* @return the patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill findByPrimaryKey(
		long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException {
		return getPersistence().findByPrimaryKey(patientBillId);
	}

	/**
	* Returns the patient bill with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param patientBillId the primary key of the patient bill
	* @return the patient bill, or <code>null</code> if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.PatientBill fetchByPrimaryKey(
		long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(patientBillId);
	}

	/**
	* Returns all the patient bills.
	*
	* @return the patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the patient bills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the patient bills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.PatientBill> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the patient bills from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of patient bills.
	*
	* @return the number of patient bills
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static PatientBillPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (PatientBillPersistence)PortletBeanLocatorUtil.locate(com.napier.portal.db.service.ClpSerializer.getServletContextName(),
					PatientBillPersistence.class.getName());

			ReferenceRegistry.registerReference(PatientBillUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(PatientBillPersistence persistence) {
	}

	private static PatientBillPersistence _persistence;
}