/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.napier.portal.db.model.BedReservation;

import java.util.List;

/**
 * The persistence utility for the bed reservation service. This utility wraps {@link BedReservationPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see BedReservationPersistence
 * @see BedReservationPersistenceImpl
 * @generated
 */
public class BedReservationUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(BedReservation bedReservation) {
		getPersistence().clearCache(bedReservation);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<BedReservation> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<BedReservation> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<BedReservation> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static BedReservation update(BedReservation bedReservation)
		throws SystemException {
		return getPersistence().update(bedReservation);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static BedReservation update(BedReservation bedReservation,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(bedReservation, serviceContext);
	}

	/**
	* Returns all the bed reservations where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @return the matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findBybedClass(
		java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybedClass(bedClass);
	}

	/**
	* Returns a range of all the bed reservations where bedClass = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bedClass the bed class
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @return the range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findBybedClass(
		java.lang.String bedClass, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybedClass(bedClass, start, end);
	}

	/**
	* Returns an ordered range of all the bed reservations where bedClass = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bedClass the bed class
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findBybedClass(
		java.lang.String bedClass, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBybedClass(bedClass, start, end, orderByComparator);
	}

	/**
	* Returns the first bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation findBybedClass_First(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence().findBybedClass_First(bedClass, orderByComparator);
	}

	/**
	* Returns the first bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation fetchBybedClass_First(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBybedClass_First(bedClass, orderByComparator);
	}

	/**
	* Returns the last bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation findBybedClass_Last(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence().findBybedClass_Last(bedClass, orderByComparator);
	}

	/**
	* Returns the last bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation fetchBybedClass_Last(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBybedClass_Last(bedClass, orderByComparator);
	}

	/**
	* Returns the bed reservations before and after the current bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedReservationId the primary key of the current bed reservation
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation[] findBybedClass_PrevAndNext(
		long bedReservationId, java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence()
				   .findBybedClass_PrevAndNext(bedReservationId, bedClass,
			orderByComparator);
	}

	/**
	* Removes all the bed reservations where bedClass = &#63; from the database.
	*
	* @param bedClass the bed class
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBybedClass(java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBybedClass(bedClass);
	}

	/**
	* Returns the number of bed reservations where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @return the number of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static int countBybedClass(java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBybedClass(bedClass);
	}

	/**
	* Returns all the bed reservations where ward = &#63;.
	*
	* @param ward the ward
	* @return the matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findByward(
		java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByward(ward);
	}

	/**
	* Returns a range of all the bed reservations where ward = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ward the ward
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @return the range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findByward(
		java.lang.String ward, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByward(ward, start, end);
	}

	/**
	* Returns an ordered range of all the bed reservations where ward = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ward the ward
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findByward(
		java.lang.String ward, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByward(ward, start, end, orderByComparator);
	}

	/**
	* Returns the first bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation findByward_First(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence().findByward_First(ward, orderByComparator);
	}

	/**
	* Returns the first bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation fetchByward_First(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByward_First(ward, orderByComparator);
	}

	/**
	* Returns the last bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation findByward_Last(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence().findByward_Last(ward, orderByComparator);
	}

	/**
	* Returns the last bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation fetchByward_Last(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByward_Last(ward, orderByComparator);
	}

	/**
	* Returns the bed reservations before and after the current bed reservation in the ordered set where ward = &#63;.
	*
	* @param bedReservationId the primary key of the current bed reservation
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation[] findByward_PrevAndNext(
		long bedReservationId, java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence()
				   .findByward_PrevAndNext(bedReservationId, ward,
			orderByComparator);
	}

	/**
	* Removes all the bed reservations where ward = &#63; from the database.
	*
	* @param ward the ward
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByward(java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByward(ward);
	}

	/**
	* Returns the number of bed reservations where ward = &#63;.
	*
	* @param ward the ward
	* @return the number of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static int countByward(java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByward(ward);
	}

	/**
	* Caches the bed reservation in the entity cache if it is enabled.
	*
	* @param bedReservation the bed reservation
	*/
	public static void cacheResult(
		com.napier.portal.db.model.BedReservation bedReservation) {
		getPersistence().cacheResult(bedReservation);
	}

	/**
	* Caches the bed reservations in the entity cache if it is enabled.
	*
	* @param bedReservations the bed reservations
	*/
	public static void cacheResult(
		java.util.List<com.napier.portal.db.model.BedReservation> bedReservations) {
		getPersistence().cacheResult(bedReservations);
	}

	/**
	* Creates a new bed reservation with the primary key. Does not add the bed reservation to the database.
	*
	* @param bedReservationId the primary key for the new bed reservation
	* @return the new bed reservation
	*/
	public static com.napier.portal.db.model.BedReservation create(
		long bedReservationId) {
		return getPersistence().create(bedReservationId);
	}

	/**
	* Removes the bed reservation with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param bedReservationId the primary key of the bed reservation
	* @return the bed reservation that was removed
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation remove(
		long bedReservationId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence().remove(bedReservationId);
	}

	public static com.napier.portal.db.model.BedReservation updateImpl(
		com.napier.portal.db.model.BedReservation bedReservation)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(bedReservation);
	}

	/**
	* Returns the bed reservation with the primary key or throws a {@link com.napier.portal.db.NoSuchBedReservationException} if it could not be found.
	*
	* @param bedReservationId the primary key of the bed reservation
	* @return the bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation findByPrimaryKey(
		long bedReservationId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException {
		return getPersistence().findByPrimaryKey(bedReservationId);
	}

	/**
	* Returns the bed reservation with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param bedReservationId the primary key of the bed reservation
	* @return the bed reservation, or <code>null</code> if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedReservation fetchByPrimaryKey(
		long bedReservationId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(bedReservationId);
	}

	/**
	* Returns all the bed reservations.
	*
	* @return the bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the bed reservations.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @return the range of bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the bed reservations.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedReservation> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the bed reservations from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of bed reservations.
	*
	* @return the number of bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static BedReservationPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (BedReservationPersistence)PortletBeanLocatorUtil.locate(com.napier.portal.db.service.ClpSerializer.getServletContextName(),
					BedReservationPersistence.class.getName());

			ReferenceRegistry.registerReference(BedReservationUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(BedReservationPersistence persistence) {
	}

	private static BedReservationPersistence _persistence;
}