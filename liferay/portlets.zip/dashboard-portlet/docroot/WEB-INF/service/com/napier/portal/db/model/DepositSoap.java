/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class DepositSoap implements Serializable {
	public static DepositSoap toSoapModel(Deposit model) {
		DepositSoap soapModel = new DepositSoap();

		soapModel.setDepositId(model.getDepositId());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setIpNumber(model.getIpNumber());
		soapModel.setDepositNumber(model.getDepositNumber());
		soapModel.setDepositAmount(model.getDepositAmount());
		soapModel.setDepositAgainst(model.getDepositAgainst());
		soapModel.setDepositDate(model.getDepositDate());
		soapModel.setPatientBillId(model.getPatientBillId());

		return soapModel;
	}

	public static DepositSoap[] toSoapModels(Deposit[] models) {
		DepositSoap[] soapModels = new DepositSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static DepositSoap[][] toSoapModels(Deposit[][] models) {
		DepositSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new DepositSoap[models.length][models[0].length];
		}
		else {
			soapModels = new DepositSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static DepositSoap[] toSoapModels(List<Deposit> models) {
		List<DepositSoap> soapModels = new ArrayList<DepositSoap>(models.size());

		for (Deposit model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new DepositSoap[soapModels.size()]);
	}

	public DepositSoap() {
	}

	public long getPrimaryKey() {
		return _depositId;
	}

	public void setPrimaryKey(long pk) {
		setDepositId(pk);
	}

	public long getDepositId() {
		return _depositId;
	}

	public void setDepositId(long depositId) {
		_depositId = depositId;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public String getIpNumber() {
		return _ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;
	}

	public String getDepositNumber() {
		return _depositNumber;
	}

	public void setDepositNumber(String depositNumber) {
		_depositNumber = depositNumber;
	}

	public double getDepositAmount() {
		return _depositAmount;
	}

	public void setDepositAmount(double depositAmount) {
		_depositAmount = depositAmount;
	}

	public String getDepositAgainst() {
		return _depositAgainst;
	}

	public void setDepositAgainst(String depositAgainst) {
		_depositAgainst = depositAgainst;
	}

	public Date getDepositDate() {
		return _depositDate;
	}

	public void setDepositDate(Date depositDate) {
		_depositDate = depositDate;
	}

	public long getPatientBillId() {
		return _patientBillId;
	}

	public void setPatientBillId(long patientBillId) {
		_patientBillId = patientBillId;
	}

	private long _depositId;
	private String _mrNumber;
	private String _ipNumber;
	private String _depositNumber;
	private double _depositAmount;
	private String _depositAgainst;
	private Date _depositDate;
	private long _patientBillId;
}