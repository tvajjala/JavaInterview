/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class DoctorAppointmentSoap implements Serializable {
	public static DoctorAppointmentSoap toSoapModel(DoctorAppointment model) {
		DoctorAppointmentSoap soapModel = new DoctorAppointmentSoap();

		soapModel.setAppointmentId(model.getAppointmentId());
		soapModel.setAppointmentNumber(model.getAppointmentNumber());
		soapModel.setAppointmentDate(model.getAppointmentDate());
		soapModel.setDoctorId(model.getDoctorId());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setCreationDate(model.getCreationDate());
		soapModel.setFromTime(model.getFromTime());
		soapModel.setToTime(model.getToTime());
		soapModel.setStatus(model.getStatus());
		soapModel.setPatientName(model.getPatientName());
		soapModel.setAge(model.getAge());
		soapModel.setGender(model.getGender());
		soapModel.setMobile(model.getMobile());
		soapModel.setEmail(model.getEmail());
		soapModel.setComplaint(model.getComplaint());

		return soapModel;
	}

	public static DoctorAppointmentSoap[] toSoapModels(
		DoctorAppointment[] models) {
		DoctorAppointmentSoap[] soapModels = new DoctorAppointmentSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static DoctorAppointmentSoap[][] toSoapModels(
		DoctorAppointment[][] models) {
		DoctorAppointmentSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new DoctorAppointmentSoap[models.length][models[0].length];
		}
		else {
			soapModels = new DoctorAppointmentSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static DoctorAppointmentSoap[] toSoapModels(
		List<DoctorAppointment> models) {
		List<DoctorAppointmentSoap> soapModels = new ArrayList<DoctorAppointmentSoap>(models.size());

		for (DoctorAppointment model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new DoctorAppointmentSoap[soapModels.size()]);
	}

	public DoctorAppointmentSoap() {
	}

	public long getPrimaryKey() {
		return _appointmentId;
	}

	public void setPrimaryKey(long pk) {
		setAppointmentId(pk);
	}

	public long getAppointmentId() {
		return _appointmentId;
	}

	public void setAppointmentId(long appointmentId) {
		_appointmentId = appointmentId;
	}

	public String getAppointmentNumber() {
		return _appointmentNumber;
	}

	public void setAppointmentNumber(String appointmentNumber) {
		_appointmentNumber = appointmentNumber;
	}

	public Date getAppointmentDate() {
		return _appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		_appointmentDate = appointmentDate;
	}

	public String getDoctorId() {
		return _doctorId;
	}

	public void setDoctorId(String doctorId) {
		_doctorId = doctorId;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public Date getCreationDate() {
		return _creationDate;
	}

	public void setCreationDate(Date creationDate) {
		_creationDate = creationDate;
	}

	public String getFromTime() {
		return _fromTime;
	}

	public void setFromTime(String fromTime) {
		_fromTime = fromTime;
	}

	public String getToTime() {
		return _toTime;
	}

	public void setToTime(String toTime) {
		_toTime = toTime;
	}

	public String getStatus() {
		return _status;
	}

	public void setStatus(String status) {
		_status = status;
	}

	public String getPatientName() {
		return _patientName;
	}

	public void setPatientName(String patientName) {
		_patientName = patientName;
	}

	public int getAge() {
		return _age;
	}

	public void setAge(int age) {
		_age = age;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public String getMobile() {
		return _mobile;
	}

	public void setMobile(String mobile) {
		_mobile = mobile;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getComplaint() {
		return _complaint;
	}

	public void setComplaint(String complaint) {
		_complaint = complaint;
	}

	private long _appointmentId;
	private String _appointmentNumber;
	private Date _appointmentDate;
	private String _doctorId;
	private String _mrNumber;
	private Date _creationDate;
	private String _fromTime;
	private String _toTime;
	private String _status;
	private String _patientName;
	private int _age;
	private String _gender;
	private String _mobile;
	private String _email;
	private String _complaint;
}