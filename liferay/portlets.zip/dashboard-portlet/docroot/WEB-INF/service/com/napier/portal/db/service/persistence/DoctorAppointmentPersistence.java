/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.napier.portal.db.model.DoctorAppointment;

/**
 * The persistence interface for the doctor appointment service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DoctorAppointmentPersistenceImpl
 * @see DoctorAppointmentUtil
 * @generated
 */
public interface DoctorAppointmentPersistence extends BasePersistence<DoctorAppointment> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link DoctorAppointmentUtil} to access the doctor appointment persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the doctor appointments where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @return the matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DoctorAppointment> findByuserId(
		long createdByUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the doctor appointments where createdByUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdByUserId the created by user ID
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @return the range of matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DoctorAppointment> findByuserId(
		long createdByUserId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the doctor appointments where createdByUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdByUserId the created by user ID
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DoctorAppointment> findByuserId(
		long createdByUserId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment findByuserId_First(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException;

	/**
	* Returns the first doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching doctor appointment, or <code>null</code> if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment fetchByuserId_First(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment findByuserId_Last(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException;

	/**
	* Returns the last doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching doctor appointment, or <code>null</code> if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment fetchByuserId_Last(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the doctor appointments before and after the current doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param appointmentId the primary key of the current doctor appointment
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment[] findByuserId_PrevAndNext(
		long appointmentId, long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException;

	/**
	* Removes all the doctor appointments where createdByUserId = &#63; from the database.
	*
	* @param createdByUserId the created by user ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByuserId(long createdByUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of doctor appointments where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @return the number of matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public int countByuserId(long createdByUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the doctor appointment in the entity cache if it is enabled.
	*
	* @param doctorAppointment the doctor appointment
	*/
	public void cacheResult(
		com.napier.portal.db.model.DoctorAppointment doctorAppointment);

	/**
	* Caches the doctor appointments in the entity cache if it is enabled.
	*
	* @param doctorAppointments the doctor appointments
	*/
	public void cacheResult(
		java.util.List<com.napier.portal.db.model.DoctorAppointment> doctorAppointments);

	/**
	* Creates a new doctor appointment with the primary key. Does not add the doctor appointment to the database.
	*
	* @param appointmentId the primary key for the new doctor appointment
	* @return the new doctor appointment
	*/
	public com.napier.portal.db.model.DoctorAppointment create(
		long appointmentId);

	/**
	* Removes the doctor appointment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param appointmentId the primary key of the doctor appointment
	* @return the doctor appointment that was removed
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment remove(
		long appointmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException;

	public com.napier.portal.db.model.DoctorAppointment updateImpl(
		com.napier.portal.db.model.DoctorAppointment doctorAppointment)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the doctor appointment with the primary key or throws a {@link com.napier.portal.db.NoSuchDoctorAppointmentException} if it could not be found.
	*
	* @param appointmentId the primary key of the doctor appointment
	* @return the doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment findByPrimaryKey(
		long appointmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException;

	/**
	* Returns the doctor appointment with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param appointmentId the primary key of the doctor appointment
	* @return the doctor appointment, or <code>null</code> if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DoctorAppointment fetchByPrimaryKey(
		long appointmentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the doctor appointments.
	*
	* @return the doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DoctorAppointment> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the doctor appointments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @return the range of doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DoctorAppointment> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the doctor appointments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DoctorAppointment> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the doctor appointments from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of doctor appointments.
	*
	* @return the number of doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}