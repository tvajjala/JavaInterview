/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.DepositLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class DepositClp extends BaseModelImpl<Deposit> implements Deposit {
	public DepositClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Deposit.class;
	}

	@Override
	public String getModelClassName() {
		return Deposit.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _depositId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDepositId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _depositId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("depositId", getDepositId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("depositNumber", getDepositNumber());
		attributes.put("depositAmount", getDepositAmount());
		attributes.put("depositAgainst", getDepositAgainst());
		attributes.put("depositDate", getDepositDate());
		attributes.put("patientBillId", getPatientBillId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long depositId = (Long)attributes.get("depositId");

		if (depositId != null) {
			setDepositId(depositId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String depositNumber = (String)attributes.get("depositNumber");

		if (depositNumber != null) {
			setDepositNumber(depositNumber);
		}

		Double depositAmount = (Double)attributes.get("depositAmount");

		if (depositAmount != null) {
			setDepositAmount(depositAmount);
		}

		String depositAgainst = (String)attributes.get("depositAgainst");

		if (depositAgainst != null) {
			setDepositAgainst(depositAgainst);
		}

		Date depositDate = (Date)attributes.get("depositDate");

		if (depositDate != null) {
			setDepositDate(depositDate);
		}

		Long patientBillId = (Long)attributes.get("patientBillId");

		if (patientBillId != null) {
			setPatientBillId(patientBillId);
		}
	}

	@Override
	public long getDepositId() {
		return _depositId;
	}

	@Override
	public void setDepositId(long depositId) {
		_depositId = depositId;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setDepositId", long.class);

				method.invoke(_depositRemoteModel, depositId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_depositRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getIpNumber() {
		return _ipNumber;
	}

	@Override
	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setIpNumber", String.class);

				method.invoke(_depositRemoteModel, ipNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDepositNumber() {
		return _depositNumber;
	}

	@Override
	public void setDepositNumber(String depositNumber) {
		_depositNumber = depositNumber;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setDepositNumber", String.class);

				method.invoke(_depositRemoteModel, depositNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getDepositAmount() {
		return _depositAmount;
	}

	@Override
	public void setDepositAmount(double depositAmount) {
		_depositAmount = depositAmount;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setDepositAmount", double.class);

				method.invoke(_depositRemoteModel, depositAmount);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDepositAgainst() {
		return _depositAgainst;
	}

	@Override
	public void setDepositAgainst(String depositAgainst) {
		_depositAgainst = depositAgainst;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setDepositAgainst",
						String.class);

				method.invoke(_depositRemoteModel, depositAgainst);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getDepositDate() {
		return _depositDate;
	}

	@Override
	public void setDepositDate(Date depositDate) {
		_depositDate = depositDate;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setDepositDate", Date.class);

				method.invoke(_depositRemoteModel, depositDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getPatientBillId() {
		return _patientBillId;
	}

	@Override
	public void setPatientBillId(long patientBillId) {
		_patientBillId = patientBillId;

		if (_depositRemoteModel != null) {
			try {
				Class<?> clazz = _depositRemoteModel.getClass();

				Method method = clazz.getMethod("setPatientBillId", long.class);

				method.invoke(_depositRemoteModel, patientBillId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getDepositRemoteModel() {
		return _depositRemoteModel;
	}

	public void setDepositRemoteModel(BaseModel<?> depositRemoteModel) {
		_depositRemoteModel = depositRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _depositRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_depositRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DepositLocalServiceUtil.addDeposit(this);
		}
		else {
			DepositLocalServiceUtil.updateDeposit(this);
		}
	}

	@Override
	public Deposit toEscapedModel() {
		return (Deposit)ProxyUtil.newProxyInstance(Deposit.class.getClassLoader(),
			new Class[] { Deposit.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DepositClp clone = new DepositClp();

		clone.setDepositId(getDepositId());
		clone.setMrNumber(getMrNumber());
		clone.setIpNumber(getIpNumber());
		clone.setDepositNumber(getDepositNumber());
		clone.setDepositAmount(getDepositAmount());
		clone.setDepositAgainst(getDepositAgainst());
		clone.setDepositDate(getDepositDate());
		clone.setPatientBillId(getPatientBillId());

		return clone;
	}

	@Override
	public int compareTo(Deposit deposit) {
		int value = 0;

		value = DateUtil.compareTo(getDepositDate(), deposit.getDepositDate());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DepositClp)) {
			return false;
		}

		DepositClp deposit = (DepositClp)obj;

		long primaryKey = deposit.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{depositId=");
		sb.append(getDepositId());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", ipNumber=");
		sb.append(getIpNumber());
		sb.append(", depositNumber=");
		sb.append(getDepositNumber());
		sb.append(", depositAmount=");
		sb.append(getDepositAmount());
		sb.append(", depositAgainst=");
		sb.append(getDepositAgainst());
		sb.append(", depositDate=");
		sb.append(getDepositDate());
		sb.append(", patientBillId=");
		sb.append(getPatientBillId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(28);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.Deposit");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>depositId</column-name><column-value><![CDATA[");
		sb.append(getDepositId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ipNumber</column-name><column-value><![CDATA[");
		sb.append(getIpNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>depositNumber</column-name><column-value><![CDATA[");
		sb.append(getDepositNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>depositAmount</column-name><column-value><![CDATA[");
		sb.append(getDepositAmount());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>depositAgainst</column-name><column-value><![CDATA[");
		sb.append(getDepositAgainst());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>depositDate</column-name><column-value><![CDATA[");
		sb.append(getDepositDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>patientBillId</column-name><column-value><![CDATA[");
		sb.append(getPatientBillId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _depositId;
	private String _mrNumber;
	private String _ipNumber;
	private String _depositNumber;
	private double _depositAmount;
	private String _depositAgainst;
	private Date _depositDate;
	private long _patientBillId;
	private BaseModel<?> _depositRemoteModel;
}