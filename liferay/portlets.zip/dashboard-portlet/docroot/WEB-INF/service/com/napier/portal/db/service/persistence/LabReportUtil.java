/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.napier.portal.db.model.LabReport;

import java.util.List;

/**
 * The persistence utility for the lab report service. This utility wraps {@link LabReportPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see LabReportPersistence
 * @see LabReportPersistenceImpl
 * @generated
 */
public class LabReportUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(LabReport labReport) {
		getPersistence().clearCache(labReport);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<LabReport> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<LabReport> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<LabReport> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static LabReport update(LabReport labReport)
		throws SystemException {
		return getPersistence().update(labReport);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static LabReport update(LabReport labReport,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(labReport, serviceContext);
	}

	/**
	* Returns all the lab reports where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber);
	}

	/**
	* Returns a range of all the lab reports where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber, start, end);
	}

	/**
	* Returns an ordered range of all the lab reports where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBymrNumber(mrNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where mrNumber = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport[] findBymrNumber_PrevAndNext(
		long labId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence()
				   .findBymrNumber_PrevAndNext(labId, mrNumber,
			orderByComparator);
	}

	/**
	* Removes all the lab reports where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBymrNumber(mrNumber);
	}

	/**
	* Returns the number of lab reports where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBymrNumber(mrNumber);
	}

	/**
	* Returns all the lab reports where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber);
	}

	/**
	* Returns a range of all the lab reports where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber, start, end);
	}

	/**
	* Returns an ordered range of all the lab reports where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByipNumber(ipNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where ipNumber = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport[] findByipNumber_PrevAndNext(
		long labId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence()
				   .findByipNumber_PrevAndNext(labId, ipNumber,
			orderByComparator);
	}

	/**
	* Removes all the lab reports where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByipNumber(ipNumber);
	}

	/**
	* Returns the number of lab reports where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByipNumber(ipNumber);
	}

	/**
	* Returns all the lab reports where testName = &#63;.
	*
	* @param testName the test name
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBytestName(
		java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBytestName(testName);
	}

	/**
	* Returns a range of all the lab reports where testName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param testName the test name
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBytestName(
		java.lang.String testName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBytestName(testName, start, end);
	}

	/**
	* Returns an ordered range of all the lab reports where testName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param testName the test name
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBytestName(
		java.lang.String testName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBytestName(testName, start, end, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findBytestName_First(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findBytestName_First(testName, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchBytestName_First(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBytestName_First(testName, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findBytestName_Last(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findBytestName_Last(testName, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchBytestName_Last(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBytestName_Last(testName, orderByComparator);
	}

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where testName = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport[] findBytestName_PrevAndNext(
		long labId, java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence()
				   .findBytestName_PrevAndNext(labId, testName,
			orderByComparator);
	}

	/**
	* Removes all the lab reports where testName = &#63; from the database.
	*
	* @param testName the test name
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBytestName(java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBytestName(testName);
	}

	/**
	* Returns the number of lab reports where testName = &#63;.
	*
	* @param testName the test name
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countBytestName(java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBytestName(testName);
	}

	/**
	* Returns all the lab reports where status = &#63;.
	*
	* @param status the status
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBystatus(
		boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatus(status);
	}

	/**
	* Returns a range of all the lab reports where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBystatus(
		boolean status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatus(status, start, end);
	}

	/**
	* Returns an ordered range of all the lab reports where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findBystatus(
		boolean status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBystatus(status, start, end, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findBystatus_First(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findBystatus_First(status, orderByComparator);
	}

	/**
	* Returns the first lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchBystatus_First(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatus_First(status, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findBystatus_Last(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findBystatus_Last(status, orderByComparator);
	}

	/**
	* Returns the last lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchBystatus_Last(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatus_Last(status, orderByComparator);
	}

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where status = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport[] findBystatus_PrevAndNext(
		long labId, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence()
				   .findBystatus_PrevAndNext(labId, status, orderByComparator);
	}

	/**
	* Removes all the lab reports where status = &#63; from the database.
	*
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystatus(boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystatus(status);
	}

	/**
	* Returns the number of lab reports where status = &#63;.
	*
	* @param status the status
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystatus(boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystatus(status);
	}

	/**
	* Caches the lab report in the entity cache if it is enabled.
	*
	* @param labReport the lab report
	*/
	public static void cacheResult(
		com.napier.portal.db.model.LabReport labReport) {
		getPersistence().cacheResult(labReport);
	}

	/**
	* Caches the lab reports in the entity cache if it is enabled.
	*
	* @param labReports the lab reports
	*/
	public static void cacheResult(
		java.util.List<com.napier.portal.db.model.LabReport> labReports) {
		getPersistence().cacheResult(labReports);
	}

	/**
	* Creates a new lab report with the primary key. Does not add the lab report to the database.
	*
	* @param labId the primary key for the new lab report
	* @return the new lab report
	*/
	public static com.napier.portal.db.model.LabReport create(long labId) {
		return getPersistence().create(labId);
	}

	/**
	* Removes the lab report with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param labId the primary key of the lab report
	* @return the lab report that was removed
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport remove(long labId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().remove(labId);
	}

	public static com.napier.portal.db.model.LabReport updateImpl(
		com.napier.portal.db.model.LabReport labReport)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(labReport);
	}

	/**
	* Returns the lab report with the primary key or throws a {@link com.napier.portal.db.NoSuchLabReportException} if it could not be found.
	*
	* @param labId the primary key of the lab report
	* @return the lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport findByPrimaryKey(
		long labId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException {
		return getPersistence().findByPrimaryKey(labId);
	}

	/**
	* Returns the lab report with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param labId the primary key of the lab report
	* @return the lab report, or <code>null</code> if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.LabReport fetchByPrimaryKey(
		long labId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(labId);
	}

	/**
	* Returns all the lab reports.
	*
	* @return the lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the lab reports.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the lab reports.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.LabReport> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the lab reports from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of lab reports.
	*
	* @return the number of lab reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static LabReportPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (LabReportPersistence)PortletBeanLocatorUtil.locate(com.napier.portal.db.service.ClpSerializer.getServletContextName(),
					LabReportPersistence.class.getName());

			ReferenceRegistry.registerReference(LabReportUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(LabReportPersistence persistence) {
	}

	private static LabReportPersistence _persistence;
}