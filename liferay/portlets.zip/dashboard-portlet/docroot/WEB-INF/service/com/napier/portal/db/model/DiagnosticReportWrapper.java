/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link DiagnosticReport}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DiagnosticReport
 * @generated
 */
public class DiagnosticReportWrapper implements DiagnosticReport,
	ModelWrapper<DiagnosticReport> {
	public DiagnosticReportWrapper(DiagnosticReport diagnosticReport) {
		_diagnosticReport = diagnosticReport;
	}

	@Override
	public Class<?> getModelClass() {
		return DiagnosticReport.class;
	}

	@Override
	public String getModelClassName() {
		return DiagnosticReport.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("diagnosticId", getDiagnosticId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("orderNumber", getOrderNumber());
		attributes.put("orderDate", getOrderDate());
		attributes.put("reportedOn", getReportedOn());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("testName", getTestName());
		attributes.put("departmentName", getDepartmentName());
		attributes.put("status", getStatus());
		attributes.put("docPath", getDocPath());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long diagnosticId = (Long)attributes.get("diagnosticId");

		if (diagnosticId != null) {
			setDiagnosticId(diagnosticId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String orderNumber = (String)attributes.get("orderNumber");

		if (orderNumber != null) {
			setOrderNumber(orderNumber);
		}

		Date orderDate = (Date)attributes.get("orderDate");

		if (orderDate != null) {
			setOrderDate(orderDate);
		}

		Date reportedOn = (Date)attributes.get("reportedOn");

		if (reportedOn != null) {
			setReportedOn(reportedOn);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String testName = (String)attributes.get("testName");

		if (testName != null) {
			setTestName(testName);
		}

		String departmentName = (String)attributes.get("departmentName");

		if (departmentName != null) {
			setDepartmentName(departmentName);
		}

		Boolean status = (Boolean)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String docPath = (String)attributes.get("docPath");

		if (docPath != null) {
			setDocPath(docPath);
		}
	}

	/**
	* Returns the primary key of this diagnostic report.
	*
	* @return the primary key of this diagnostic report
	*/
	@Override
	public long getPrimaryKey() {
		return _diagnosticReport.getPrimaryKey();
	}

	/**
	* Sets the primary key of this diagnostic report.
	*
	* @param primaryKey the primary key of this diagnostic report
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_diagnosticReport.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the diagnostic ID of this diagnostic report.
	*
	* @return the diagnostic ID of this diagnostic report
	*/
	@Override
	public long getDiagnosticId() {
		return _diagnosticReport.getDiagnosticId();
	}

	/**
	* Sets the diagnostic ID of this diagnostic report.
	*
	* @param diagnosticId the diagnostic ID of this diagnostic report
	*/
	@Override
	public void setDiagnosticId(long diagnosticId) {
		_diagnosticReport.setDiagnosticId(diagnosticId);
	}

	/**
	* Returns the mr number of this diagnostic report.
	*
	* @return the mr number of this diagnostic report
	*/
	@Override
	public java.lang.String getMrNumber() {
		return _diagnosticReport.getMrNumber();
	}

	/**
	* Sets the mr number of this diagnostic report.
	*
	* @param mrNumber the mr number of this diagnostic report
	*/
	@Override
	public void setMrNumber(java.lang.String mrNumber) {
		_diagnosticReport.setMrNumber(mrNumber);
	}

	/**
	* Returns the order number of this diagnostic report.
	*
	* @return the order number of this diagnostic report
	*/
	@Override
	public java.lang.String getOrderNumber() {
		return _diagnosticReport.getOrderNumber();
	}

	/**
	* Sets the order number of this diagnostic report.
	*
	* @param orderNumber the order number of this diagnostic report
	*/
	@Override
	public void setOrderNumber(java.lang.String orderNumber) {
		_diagnosticReport.setOrderNumber(orderNumber);
	}

	/**
	* Returns the order date of this diagnostic report.
	*
	* @return the order date of this diagnostic report
	*/
	@Override
	public java.util.Date getOrderDate() {
		return _diagnosticReport.getOrderDate();
	}

	/**
	* Sets the order date of this diagnostic report.
	*
	* @param orderDate the order date of this diagnostic report
	*/
	@Override
	public void setOrderDate(java.util.Date orderDate) {
		_diagnosticReport.setOrderDate(orderDate);
	}

	/**
	* Returns the reported on of this diagnostic report.
	*
	* @return the reported on of this diagnostic report
	*/
	@Override
	public java.util.Date getReportedOn() {
		return _diagnosticReport.getReportedOn();
	}

	/**
	* Sets the reported on of this diagnostic report.
	*
	* @param reportedOn the reported on of this diagnostic report
	*/
	@Override
	public void setReportedOn(java.util.Date reportedOn) {
		_diagnosticReport.setReportedOn(reportedOn);
	}

	/**
	* Returns the ip number of this diagnostic report.
	*
	* @return the ip number of this diagnostic report
	*/
	@Override
	public java.lang.String getIpNumber() {
		return _diagnosticReport.getIpNumber();
	}

	/**
	* Sets the ip number of this diagnostic report.
	*
	* @param ipNumber the ip number of this diagnostic report
	*/
	@Override
	public void setIpNumber(java.lang.String ipNumber) {
		_diagnosticReport.setIpNumber(ipNumber);
	}

	/**
	* Returns the test name of this diagnostic report.
	*
	* @return the test name of this diagnostic report
	*/
	@Override
	public java.lang.String getTestName() {
		return _diagnosticReport.getTestName();
	}

	/**
	* Sets the test name of this diagnostic report.
	*
	* @param testName the test name of this diagnostic report
	*/
	@Override
	public void setTestName(java.lang.String testName) {
		_diagnosticReport.setTestName(testName);
	}

	/**
	* Returns the department name of this diagnostic report.
	*
	* @return the department name of this diagnostic report
	*/
	@Override
	public java.lang.String getDepartmentName() {
		return _diagnosticReport.getDepartmentName();
	}

	/**
	* Sets the department name of this diagnostic report.
	*
	* @param departmentName the department name of this diagnostic report
	*/
	@Override
	public void setDepartmentName(java.lang.String departmentName) {
		_diagnosticReport.setDepartmentName(departmentName);
	}

	/**
	* Returns the status of this diagnostic report.
	*
	* @return the status of this diagnostic report
	*/
	@Override
	public boolean getStatus() {
		return _diagnosticReport.getStatus();
	}

	/**
	* Returns <code>true</code> if this diagnostic report is status.
	*
	* @return <code>true</code> if this diagnostic report is status; <code>false</code> otherwise
	*/
	@Override
	public boolean isStatus() {
		return _diagnosticReport.isStatus();
	}

	/**
	* Sets whether this diagnostic report is status.
	*
	* @param status the status of this diagnostic report
	*/
	@Override
	public void setStatus(boolean status) {
		_diagnosticReport.setStatus(status);
	}

	/**
	* Returns the doc path of this diagnostic report.
	*
	* @return the doc path of this diagnostic report
	*/
	@Override
	public java.lang.String getDocPath() {
		return _diagnosticReport.getDocPath();
	}

	/**
	* Sets the doc path of this diagnostic report.
	*
	* @param docPath the doc path of this diagnostic report
	*/
	@Override
	public void setDocPath(java.lang.String docPath) {
		_diagnosticReport.setDocPath(docPath);
	}

	@Override
	public boolean isNew() {
		return _diagnosticReport.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_diagnosticReport.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _diagnosticReport.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_diagnosticReport.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _diagnosticReport.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _diagnosticReport.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_diagnosticReport.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _diagnosticReport.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_diagnosticReport.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_diagnosticReport.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_diagnosticReport.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DiagnosticReportWrapper((DiagnosticReport)_diagnosticReport.clone());
	}

	@Override
	public int compareTo(
		com.napier.portal.db.model.DiagnosticReport diagnosticReport) {
		return _diagnosticReport.compareTo(diagnosticReport);
	}

	@Override
	public int hashCode() {
		return _diagnosticReport.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.DiagnosticReport> toCacheModel() {
		return _diagnosticReport.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.DiagnosticReport toEscapedModel() {
		return new DiagnosticReportWrapper(_diagnosticReport.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.DiagnosticReport toUnescapedModel() {
		return new DiagnosticReportWrapper(_diagnosticReport.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _diagnosticReport.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _diagnosticReport.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_diagnosticReport.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DiagnosticReportWrapper)) {
			return false;
		}

		DiagnosticReportWrapper diagnosticReportWrapper = (DiagnosticReportWrapper)obj;

		if (Validator.equals(_diagnosticReport,
					diagnosticReportWrapper._diagnosticReport)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public DiagnosticReport getWrappedDiagnosticReport() {
		return _diagnosticReport;
	}

	@Override
	public DiagnosticReport getWrappedModel() {
		return _diagnosticReport;
	}

	@Override
	public void resetOriginalValues() {
		_diagnosticReport.resetOriginalValues();
	}

	private DiagnosticReport _diagnosticReport;
}