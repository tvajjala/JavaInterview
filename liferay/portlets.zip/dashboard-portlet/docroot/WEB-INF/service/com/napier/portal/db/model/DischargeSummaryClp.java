/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.DischargeSummaryLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class DischargeSummaryClp extends BaseModelImpl<DischargeSummary>
	implements DischargeSummary {
	public DischargeSummaryClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return DischargeSummary.class;
	}

	@Override
	public String getModelClassName() {
		return DischargeSummary.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _dischargeSummaryId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDischargeSummaryId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _dischargeSummaryId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("dischargeSummaryId", getDischargeSummaryId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("docPath", getDocPath());
		attributes.put("departmentName", getDepartmentName());
		attributes.put("status", getStatus());
		attributes.put("ward", getWard());
		attributes.put("bedClass", getBedClass());
		attributes.put("dischargeDate", getDischargeDate());
		attributes.put("admissionDate", getAdmissionDate());
		attributes.put("primaryDoctor", getPrimaryDoctor());
		attributes.put("chiefComplaint", getChiefComplaint());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long dischargeSummaryId = (Long)attributes.get("dischargeSummaryId");

		if (dischargeSummaryId != null) {
			setDischargeSummaryId(dischargeSummaryId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String docPath = (String)attributes.get("docPath");

		if (docPath != null) {
			setDocPath(docPath);
		}

		String departmentName = (String)attributes.get("departmentName");

		if (departmentName != null) {
			setDepartmentName(departmentName);
		}

		Boolean status = (Boolean)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String ward = (String)attributes.get("ward");

		if (ward != null) {
			setWard(ward);
		}

		String bedClass = (String)attributes.get("bedClass");

		if (bedClass != null) {
			setBedClass(bedClass);
		}

		Date dischargeDate = (Date)attributes.get("dischargeDate");

		if (dischargeDate != null) {
			setDischargeDate(dischargeDate);
		}

		Date admissionDate = (Date)attributes.get("admissionDate");

		if (admissionDate != null) {
			setAdmissionDate(admissionDate);
		}

		String primaryDoctor = (String)attributes.get("primaryDoctor");

		if (primaryDoctor != null) {
			setPrimaryDoctor(primaryDoctor);
		}

		String chiefComplaint = (String)attributes.get("chiefComplaint");

		if (chiefComplaint != null) {
			setChiefComplaint(chiefComplaint);
		}
	}

	@Override
	public long getDischargeSummaryId() {
		return _dischargeSummaryId;
	}

	@Override
	public void setDischargeSummaryId(long dischargeSummaryId) {
		_dischargeSummaryId = dischargeSummaryId;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setDischargeSummaryId",
						long.class);

				method.invoke(_dischargeSummaryRemoteModel, dischargeSummaryId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_dischargeSummaryRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getIpNumber() {
		return _ipNumber;
	}

	@Override
	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setIpNumber", String.class);

				method.invoke(_dischargeSummaryRemoteModel, ipNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDocPath() {
		return _docPath;
	}

	@Override
	public void setDocPath(String docPath) {
		_docPath = docPath;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setDocPath", String.class);

				method.invoke(_dischargeSummaryRemoteModel, docPath);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDepartmentName() {
		return _departmentName;
	}

	@Override
	public void setDepartmentName(String departmentName) {
		_departmentName = departmentName;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setDepartmentName",
						String.class);

				method.invoke(_dischargeSummaryRemoteModel, departmentName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getStatus() {
		return _status;
	}

	@Override
	public boolean isStatus() {
		return _status;
	}

	@Override
	public void setStatus(boolean status) {
		_status = status;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", boolean.class);

				method.invoke(_dischargeSummaryRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getWard() {
		return _ward;
	}

	@Override
	public void setWard(String ward) {
		_ward = ward;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setWard", String.class);

				method.invoke(_dischargeSummaryRemoteModel, ward);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getBedClass() {
		return _bedClass;
	}

	@Override
	public void setBedClass(String bedClass) {
		_bedClass = bedClass;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setBedClass", String.class);

				method.invoke(_dischargeSummaryRemoteModel, bedClass);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getDischargeDate() {
		return _dischargeDate;
	}

	@Override
	public void setDischargeDate(Date dischargeDate) {
		_dischargeDate = dischargeDate;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setDischargeDate", Date.class);

				method.invoke(_dischargeSummaryRemoteModel, dischargeDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getAdmissionDate() {
		return _admissionDate;
	}

	@Override
	public void setAdmissionDate(Date admissionDate) {
		_admissionDate = admissionDate;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setAdmissionDate", Date.class);

				method.invoke(_dischargeSummaryRemoteModel, admissionDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPrimaryDoctor() {
		return _primaryDoctor;
	}

	@Override
	public void setPrimaryDoctor(String primaryDoctor) {
		_primaryDoctor = primaryDoctor;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setPrimaryDoctor", String.class);

				method.invoke(_dischargeSummaryRemoteModel, primaryDoctor);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getChiefComplaint() {
		return _chiefComplaint;
	}

	@Override
	public void setChiefComplaint(String chiefComplaint) {
		_chiefComplaint = chiefComplaint;

		if (_dischargeSummaryRemoteModel != null) {
			try {
				Class<?> clazz = _dischargeSummaryRemoteModel.getClass();

				Method method = clazz.getMethod("setChiefComplaint",
						String.class);

				method.invoke(_dischargeSummaryRemoteModel, chiefComplaint);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getDischargeSummaryRemoteModel() {
		return _dischargeSummaryRemoteModel;
	}

	public void setDischargeSummaryRemoteModel(
		BaseModel<?> dischargeSummaryRemoteModel) {
		_dischargeSummaryRemoteModel = dischargeSummaryRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _dischargeSummaryRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_dischargeSummaryRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DischargeSummaryLocalServiceUtil.addDischargeSummary(this);
		}
		else {
			DischargeSummaryLocalServiceUtil.updateDischargeSummary(this);
		}
	}

	@Override
	public DischargeSummary toEscapedModel() {
		return (DischargeSummary)ProxyUtil.newProxyInstance(DischargeSummary.class.getClassLoader(),
			new Class[] { DischargeSummary.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DischargeSummaryClp clone = new DischargeSummaryClp();

		clone.setDischargeSummaryId(getDischargeSummaryId());
		clone.setMrNumber(getMrNumber());
		clone.setIpNumber(getIpNumber());
		clone.setDocPath(getDocPath());
		clone.setDepartmentName(getDepartmentName());
		clone.setStatus(getStatus());
		clone.setWard(getWard());
		clone.setBedClass(getBedClass());
		clone.setDischargeDate(getDischargeDate());
		clone.setAdmissionDate(getAdmissionDate());
		clone.setPrimaryDoctor(getPrimaryDoctor());
		clone.setChiefComplaint(getChiefComplaint());

		return clone;
	}

	@Override
	public int compareTo(DischargeSummary dischargeSummary) {
		long primaryKey = dischargeSummary.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DischargeSummaryClp)) {
			return false;
		}

		DischargeSummaryClp dischargeSummary = (DischargeSummaryClp)obj;

		long primaryKey = dischargeSummary.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(25);

		sb.append("{dischargeSummaryId=");
		sb.append(getDischargeSummaryId());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", ipNumber=");
		sb.append(getIpNumber());
		sb.append(", docPath=");
		sb.append(getDocPath());
		sb.append(", departmentName=");
		sb.append(getDepartmentName());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", ward=");
		sb.append(getWard());
		sb.append(", bedClass=");
		sb.append(getBedClass());
		sb.append(", dischargeDate=");
		sb.append(getDischargeDate());
		sb.append(", admissionDate=");
		sb.append(getAdmissionDate());
		sb.append(", primaryDoctor=");
		sb.append(getPrimaryDoctor());
		sb.append(", chiefComplaint=");
		sb.append(getChiefComplaint());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(40);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.DischargeSummary");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>dischargeSummaryId</column-name><column-value><![CDATA[");
		sb.append(getDischargeSummaryId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ipNumber</column-name><column-value><![CDATA[");
		sb.append(getIpNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>docPath</column-name><column-value><![CDATA[");
		sb.append(getDocPath());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>departmentName</column-name><column-value><![CDATA[");
		sb.append(getDepartmentName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ward</column-name><column-value><![CDATA[");
		sb.append(getWard());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bedClass</column-name><column-value><![CDATA[");
		sb.append(getBedClass());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dischargeDate</column-name><column-value><![CDATA[");
		sb.append(getDischargeDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>admissionDate</column-name><column-value><![CDATA[");
		sb.append(getAdmissionDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>primaryDoctor</column-name><column-value><![CDATA[");
		sb.append(getPrimaryDoctor());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>chiefComplaint</column-name><column-value><![CDATA[");
		sb.append(getChiefComplaint());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _dischargeSummaryId;
	private String _mrNumber;
	private String _ipNumber;
	private String _docPath;
	private String _departmentName;
	private boolean _status;
	private String _ward;
	private String _bedClass;
	private Date _dischargeDate;
	private Date _admissionDate;
	private String _primaryDoctor;
	private String _chiefComplaint;
	private BaseModel<?> _dischargeSummaryRemoteModel;
}