/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link PatientBill}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PatientBill
 * @generated
 */
public class PatientBillWrapper implements PatientBill,
	ModelWrapper<PatientBill> {
	public PatientBillWrapper(PatientBill patientBill) {
		_patientBill = patientBill;
	}

	@Override
	public Class<?> getModelClass() {
		return PatientBill.class;
	}

	@Override
	public String getModelClassName() {
		return PatientBill.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("patientBillId", getPatientBillId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("billNumber", getBillNumber());
		attributes.put("company", getCompany());
		attributes.put("sponser", getSponser());
		attributes.put("planName", getPlanName());
		attributes.put("planExpiry", getPlanExpiry());
		attributes.put("admissionDate", getAdmissionDate());
		attributes.put("isBillgenerated", getIsBillgenerated());
		attributes.put("isBalanceAmount", getIsBalanceAmount());
		attributes.put("billAmount", getBillAmount());
		attributes.put("paidAmount", getPaidAmount());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long patientBillId = (Long)attributes.get("patientBillId");

		if (patientBillId != null) {
			setPatientBillId(patientBillId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String billNumber = (String)attributes.get("billNumber");

		if (billNumber != null) {
			setBillNumber(billNumber);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String sponser = (String)attributes.get("sponser");

		if (sponser != null) {
			setSponser(sponser);
		}

		String planName = (String)attributes.get("planName");

		if (planName != null) {
			setPlanName(planName);
		}

		Date planExpiry = (Date)attributes.get("planExpiry");

		if (planExpiry != null) {
			setPlanExpiry(planExpiry);
		}

		Date admissionDate = (Date)attributes.get("admissionDate");

		if (admissionDate != null) {
			setAdmissionDate(admissionDate);
		}

		Boolean isBillgenerated = (Boolean)attributes.get("isBillgenerated");

		if (isBillgenerated != null) {
			setIsBillgenerated(isBillgenerated);
		}

		Boolean isBalanceAmount = (Boolean)attributes.get("isBalanceAmount");

		if (isBalanceAmount != null) {
			setIsBalanceAmount(isBalanceAmount);
		}

		Double billAmount = (Double)attributes.get("billAmount");

		if (billAmount != null) {
			setBillAmount(billAmount);
		}

		Double paidAmount = (Double)attributes.get("paidAmount");

		if (paidAmount != null) {
			setPaidAmount(paidAmount);
		}
	}

	/**
	* Returns the primary key of this patient bill.
	*
	* @return the primary key of this patient bill
	*/
	@Override
	public long getPrimaryKey() {
		return _patientBill.getPrimaryKey();
	}

	/**
	* Sets the primary key of this patient bill.
	*
	* @param primaryKey the primary key of this patient bill
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_patientBill.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the patient bill ID of this patient bill.
	*
	* @return the patient bill ID of this patient bill
	*/
	@Override
	public long getPatientBillId() {
		return _patientBill.getPatientBillId();
	}

	/**
	* Sets the patient bill ID of this patient bill.
	*
	* @param patientBillId the patient bill ID of this patient bill
	*/
	@Override
	public void setPatientBillId(long patientBillId) {
		_patientBill.setPatientBillId(patientBillId);
	}

	/**
	* Returns the mr number of this patient bill.
	*
	* @return the mr number of this patient bill
	*/
	@Override
	public java.lang.String getMrNumber() {
		return _patientBill.getMrNumber();
	}

	/**
	* Sets the mr number of this patient bill.
	*
	* @param mrNumber the mr number of this patient bill
	*/
	@Override
	public void setMrNumber(java.lang.String mrNumber) {
		_patientBill.setMrNumber(mrNumber);
	}

	/**
	* Returns the ip number of this patient bill.
	*
	* @return the ip number of this patient bill
	*/
	@Override
	public java.lang.String getIpNumber() {
		return _patientBill.getIpNumber();
	}

	/**
	* Sets the ip number of this patient bill.
	*
	* @param ipNumber the ip number of this patient bill
	*/
	@Override
	public void setIpNumber(java.lang.String ipNumber) {
		_patientBill.setIpNumber(ipNumber);
	}

	/**
	* Returns the bill number of this patient bill.
	*
	* @return the bill number of this patient bill
	*/
	@Override
	public java.lang.String getBillNumber() {
		return _patientBill.getBillNumber();
	}

	/**
	* Sets the bill number of this patient bill.
	*
	* @param billNumber the bill number of this patient bill
	*/
	@Override
	public void setBillNumber(java.lang.String billNumber) {
		_patientBill.setBillNumber(billNumber);
	}

	/**
	* Returns the company of this patient bill.
	*
	* @return the company of this patient bill
	*/
	@Override
	public java.lang.String getCompany() {
		return _patientBill.getCompany();
	}

	/**
	* Sets the company of this patient bill.
	*
	* @param company the company of this patient bill
	*/
	@Override
	public void setCompany(java.lang.String company) {
		_patientBill.setCompany(company);
	}

	/**
	* Returns the sponser of this patient bill.
	*
	* @return the sponser of this patient bill
	*/
	@Override
	public java.lang.String getSponser() {
		return _patientBill.getSponser();
	}

	/**
	* Sets the sponser of this patient bill.
	*
	* @param sponser the sponser of this patient bill
	*/
	@Override
	public void setSponser(java.lang.String sponser) {
		_patientBill.setSponser(sponser);
	}

	/**
	* Returns the plan name of this patient bill.
	*
	* @return the plan name of this patient bill
	*/
	@Override
	public java.lang.String getPlanName() {
		return _patientBill.getPlanName();
	}

	/**
	* Sets the plan name of this patient bill.
	*
	* @param planName the plan name of this patient bill
	*/
	@Override
	public void setPlanName(java.lang.String planName) {
		_patientBill.setPlanName(planName);
	}

	/**
	* Returns the plan expiry of this patient bill.
	*
	* @return the plan expiry of this patient bill
	*/
	@Override
	public java.util.Date getPlanExpiry() {
		return _patientBill.getPlanExpiry();
	}

	/**
	* Sets the plan expiry of this patient bill.
	*
	* @param planExpiry the plan expiry of this patient bill
	*/
	@Override
	public void setPlanExpiry(java.util.Date planExpiry) {
		_patientBill.setPlanExpiry(planExpiry);
	}

	/**
	* Returns the admission date of this patient bill.
	*
	* @return the admission date of this patient bill
	*/
	@Override
	public java.util.Date getAdmissionDate() {
		return _patientBill.getAdmissionDate();
	}

	/**
	* Sets the admission date of this patient bill.
	*
	* @param admissionDate the admission date of this patient bill
	*/
	@Override
	public void setAdmissionDate(java.util.Date admissionDate) {
		_patientBill.setAdmissionDate(admissionDate);
	}

	/**
	* Returns the is billgenerated of this patient bill.
	*
	* @return the is billgenerated of this patient bill
	*/
	@Override
	public boolean getIsBillgenerated() {
		return _patientBill.getIsBillgenerated();
	}

	/**
	* Returns <code>true</code> if this patient bill is is billgenerated.
	*
	* @return <code>true</code> if this patient bill is is billgenerated; <code>false</code> otherwise
	*/
	@Override
	public boolean isIsBillgenerated() {
		return _patientBill.isIsBillgenerated();
	}

	/**
	* Sets whether this patient bill is is billgenerated.
	*
	* @param isBillgenerated the is billgenerated of this patient bill
	*/
	@Override
	public void setIsBillgenerated(boolean isBillgenerated) {
		_patientBill.setIsBillgenerated(isBillgenerated);
	}

	/**
	* Returns the is balance amount of this patient bill.
	*
	* @return the is balance amount of this patient bill
	*/
	@Override
	public boolean getIsBalanceAmount() {
		return _patientBill.getIsBalanceAmount();
	}

	/**
	* Returns <code>true</code> if this patient bill is is balance amount.
	*
	* @return <code>true</code> if this patient bill is is balance amount; <code>false</code> otherwise
	*/
	@Override
	public boolean isIsBalanceAmount() {
		return _patientBill.isIsBalanceAmount();
	}

	/**
	* Sets whether this patient bill is is balance amount.
	*
	* @param isBalanceAmount the is balance amount of this patient bill
	*/
	@Override
	public void setIsBalanceAmount(boolean isBalanceAmount) {
		_patientBill.setIsBalanceAmount(isBalanceAmount);
	}

	/**
	* Returns the bill amount of this patient bill.
	*
	* @return the bill amount of this patient bill
	*/
	@Override
	public double getBillAmount() {
		return _patientBill.getBillAmount();
	}

	/**
	* Sets the bill amount of this patient bill.
	*
	* @param billAmount the bill amount of this patient bill
	*/
	@Override
	public void setBillAmount(double billAmount) {
		_patientBill.setBillAmount(billAmount);
	}

	/**
	* Returns the paid amount of this patient bill.
	*
	* @return the paid amount of this patient bill
	*/
	@Override
	public double getPaidAmount() {
		return _patientBill.getPaidAmount();
	}

	/**
	* Sets the paid amount of this patient bill.
	*
	* @param paidAmount the paid amount of this patient bill
	*/
	@Override
	public void setPaidAmount(double paidAmount) {
		_patientBill.setPaidAmount(paidAmount);
	}

	@Override
	public boolean isNew() {
		return _patientBill.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_patientBill.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _patientBill.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_patientBill.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _patientBill.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _patientBill.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_patientBill.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _patientBill.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_patientBill.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_patientBill.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_patientBill.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new PatientBillWrapper((PatientBill)_patientBill.clone());
	}

	@Override
	public int compareTo(com.napier.portal.db.model.PatientBill patientBill) {
		return _patientBill.compareTo(patientBill);
	}

	@Override
	public int hashCode() {
		return _patientBill.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.PatientBill> toCacheModel() {
		return _patientBill.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.PatientBill toEscapedModel() {
		return new PatientBillWrapper(_patientBill.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.PatientBill toUnescapedModel() {
		return new PatientBillWrapper(_patientBill.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _patientBill.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _patientBill.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_patientBill.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof PatientBillWrapper)) {
			return false;
		}

		PatientBillWrapper patientBillWrapper = (PatientBillWrapper)obj;

		if (Validator.equals(_patientBill, patientBillWrapper._patientBill)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public PatientBill getWrappedPatientBill() {
		return _patientBill;
	}

	@Override
	public PatientBill getWrappedModel() {
		return _patientBill;
	}

	@Override
	public void resetOriginalValues() {
		_patientBill.resetOriginalValues();
	}

	private PatientBill _patientBill;
}