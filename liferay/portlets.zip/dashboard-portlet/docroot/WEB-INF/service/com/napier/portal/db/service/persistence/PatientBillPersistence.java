/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.napier.portal.db.model.PatientBill;

/**
 * The persistence interface for the patient bill service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PatientBillPersistenceImpl
 * @see PatientBillUtil
 * @generated
 */
public interface PatientBillPersistence extends BasePersistence<PatientBill> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link PatientBillUtil} to access the patient bill persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the patient bills where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the patient bills where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the patient bills where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the first patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the last patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where mrNumber = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill[] findBymrNumber_PrevAndNext(
		long patientBillId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Removes all the patient bills where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of patient bills where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the patient bills where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the patient bills where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the patient bills where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the first patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the last patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where ipNumber = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill[] findByipNumber_PrevAndNext(
		long patientBillId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Removes all the patient bills where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of patient bills where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the patient bills where company = &#63;.
	*
	* @param company the company
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBycompany(
		java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the patient bills where company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBycompany(
		java.lang.String company, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the patient bills where company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBycompany(
		java.lang.String company, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBycompany_First(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the first patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBycompany_First(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBycompany_Last(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the last patient bill in the ordered set where company = &#63;.
	*
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBycompany_Last(
		java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where company = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill[] findBycompany_PrevAndNext(
		long patientBillId, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Removes all the patient bills where company = &#63; from the database.
	*
	* @param company the company
	* @throws SystemException if a system exception occurred
	*/
	public void removeBycompany(java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of patient bills where company = &#63;.
	*
	* @param company the company
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public int countBycompany(java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the patient bills where sponser = &#63;.
	*
	* @param sponser the sponser
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBysponser(
		java.lang.String sponser)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the patient bills where sponser = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBysponser(
		java.lang.String sponser, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the patient bills where sponser = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBysponser(
		java.lang.String sponser, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBysponser_First(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBysponser_First(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBysponser_Last(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63;.
	*
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBysponser_Last(
		java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where sponser = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param sponser the sponser
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill[] findBysponser_PrevAndNext(
		long patientBillId, java.lang.String sponser,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Removes all the patient bills where sponser = &#63; from the database.
	*
	* @param sponser the sponser
	* @throws SystemException if a system exception occurred
	*/
	public void removeBysponser(java.lang.String sponser)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of patient bills where sponser = &#63;.
	*
	* @param sponser the sponser
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public int countBysponser(java.lang.String sponser)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the patient bills where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @return the matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBycompanySponser(
		java.lang.String sponser, java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the patient bills where sponser = &#63; and company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBycompanySponser(
		java.lang.String sponser, java.lang.String company, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the patient bills where sponser = &#63; and company = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param sponser the sponser
	* @param company the company
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findBycompanySponser(
		java.lang.String sponser, java.lang.String company, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBycompanySponser_First(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the first patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBycompanySponser_First(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findBycompanySponser_Last(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the last patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching patient bill, or <code>null</code> if a matching patient bill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchBycompanySponser_Last(
		java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the patient bills before and after the current patient bill in the ordered set where sponser = &#63; and company = &#63;.
	*
	* @param patientBillId the primary key of the current patient bill
	* @param sponser the sponser
	* @param company the company
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill[] findBycompanySponser_PrevAndNext(
		long patientBillId, java.lang.String sponser, java.lang.String company,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Removes all the patient bills where sponser = &#63; and company = &#63; from the database.
	*
	* @param sponser the sponser
	* @param company the company
	* @throws SystemException if a system exception occurred
	*/
	public void removeBycompanySponser(java.lang.String sponser,
		java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of patient bills where sponser = &#63; and company = &#63;.
	*
	* @param sponser the sponser
	* @param company the company
	* @return the number of matching patient bills
	* @throws SystemException if a system exception occurred
	*/
	public int countBycompanySponser(java.lang.String sponser,
		java.lang.String company)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the patient bill in the entity cache if it is enabled.
	*
	* @param patientBill the patient bill
	*/
	public void cacheResult(com.napier.portal.db.model.PatientBill patientBill);

	/**
	* Caches the patient bills in the entity cache if it is enabled.
	*
	* @param patientBills the patient bills
	*/
	public void cacheResult(
		java.util.List<com.napier.portal.db.model.PatientBill> patientBills);

	/**
	* Creates a new patient bill with the primary key. Does not add the patient bill to the database.
	*
	* @param patientBillId the primary key for the new patient bill
	* @return the new patient bill
	*/
	public com.napier.portal.db.model.PatientBill create(long patientBillId);

	/**
	* Removes the patient bill with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param patientBillId the primary key of the patient bill
	* @return the patient bill that was removed
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill remove(long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	public com.napier.portal.db.model.PatientBill updateImpl(
		com.napier.portal.db.model.PatientBill patientBill)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the patient bill with the primary key or throws a {@link com.napier.portal.db.NoSuchPatientBillException} if it could not be found.
	*
	* @param patientBillId the primary key of the patient bill
	* @return the patient bill
	* @throws com.napier.portal.db.NoSuchPatientBillException if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill findByPrimaryKey(
		long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchPatientBillException;

	/**
	* Returns the patient bill with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param patientBillId the primary key of the patient bill
	* @return the patient bill, or <code>null</code> if a patient bill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.PatientBill fetchByPrimaryKey(
		long patientBillId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the patient bills.
	*
	* @return the patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the patient bills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @return the range of patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the patient bills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.PatientBillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of patient bills
	* @param end the upper bound of the range of patient bills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of patient bills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.PatientBill> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the patient bills from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of patient bills.
	*
	* @return the number of patient bills
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}