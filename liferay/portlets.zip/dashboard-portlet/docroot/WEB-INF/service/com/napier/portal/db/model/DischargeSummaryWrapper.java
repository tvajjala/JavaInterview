/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link DischargeSummary}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DischargeSummary
 * @generated
 */
public class DischargeSummaryWrapper implements DischargeSummary,
	ModelWrapper<DischargeSummary> {
	public DischargeSummaryWrapper(DischargeSummary dischargeSummary) {
		_dischargeSummary = dischargeSummary;
	}

	@Override
	public Class<?> getModelClass() {
		return DischargeSummary.class;
	}

	@Override
	public String getModelClassName() {
		return DischargeSummary.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("dischargeSummaryId", getDischargeSummaryId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("docPath", getDocPath());
		attributes.put("departmentName", getDepartmentName());
		attributes.put("status", getStatus());
		attributes.put("ward", getWard());
		attributes.put("bedClass", getBedClass());
		attributes.put("dischargeDate", getDischargeDate());
		attributes.put("admissionDate", getAdmissionDate());
		attributes.put("primaryDoctor", getPrimaryDoctor());
		attributes.put("chiefComplaint", getChiefComplaint());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long dischargeSummaryId = (Long)attributes.get("dischargeSummaryId");

		if (dischargeSummaryId != null) {
			setDischargeSummaryId(dischargeSummaryId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String docPath = (String)attributes.get("docPath");

		if (docPath != null) {
			setDocPath(docPath);
		}

		String departmentName = (String)attributes.get("departmentName");

		if (departmentName != null) {
			setDepartmentName(departmentName);
		}

		Boolean status = (Boolean)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String ward = (String)attributes.get("ward");

		if (ward != null) {
			setWard(ward);
		}

		String bedClass = (String)attributes.get("bedClass");

		if (bedClass != null) {
			setBedClass(bedClass);
		}

		Date dischargeDate = (Date)attributes.get("dischargeDate");

		if (dischargeDate != null) {
			setDischargeDate(dischargeDate);
		}

		Date admissionDate = (Date)attributes.get("admissionDate");

		if (admissionDate != null) {
			setAdmissionDate(admissionDate);
		}

		String primaryDoctor = (String)attributes.get("primaryDoctor");

		if (primaryDoctor != null) {
			setPrimaryDoctor(primaryDoctor);
		}

		String chiefComplaint = (String)attributes.get("chiefComplaint");

		if (chiefComplaint != null) {
			setChiefComplaint(chiefComplaint);
		}
	}

	/**
	* Returns the primary key of this discharge summary.
	*
	* @return the primary key of this discharge summary
	*/
	@Override
	public long getPrimaryKey() {
		return _dischargeSummary.getPrimaryKey();
	}

	/**
	* Sets the primary key of this discharge summary.
	*
	* @param primaryKey the primary key of this discharge summary
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_dischargeSummary.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the discharge summary ID of this discharge summary.
	*
	* @return the discharge summary ID of this discharge summary
	*/
	@Override
	public long getDischargeSummaryId() {
		return _dischargeSummary.getDischargeSummaryId();
	}

	/**
	* Sets the discharge summary ID of this discharge summary.
	*
	* @param dischargeSummaryId the discharge summary ID of this discharge summary
	*/
	@Override
	public void setDischargeSummaryId(long dischargeSummaryId) {
		_dischargeSummary.setDischargeSummaryId(dischargeSummaryId);
	}

	/**
	* Returns the mr number of this discharge summary.
	*
	* @return the mr number of this discharge summary
	*/
	@Override
	public java.lang.String getMrNumber() {
		return _dischargeSummary.getMrNumber();
	}

	/**
	* Sets the mr number of this discharge summary.
	*
	* @param mrNumber the mr number of this discharge summary
	*/
	@Override
	public void setMrNumber(java.lang.String mrNumber) {
		_dischargeSummary.setMrNumber(mrNumber);
	}

	/**
	* Returns the ip number of this discharge summary.
	*
	* @return the ip number of this discharge summary
	*/
	@Override
	public java.lang.String getIpNumber() {
		return _dischargeSummary.getIpNumber();
	}

	/**
	* Sets the ip number of this discharge summary.
	*
	* @param ipNumber the ip number of this discharge summary
	*/
	@Override
	public void setIpNumber(java.lang.String ipNumber) {
		_dischargeSummary.setIpNumber(ipNumber);
	}

	/**
	* Returns the doc path of this discharge summary.
	*
	* @return the doc path of this discharge summary
	*/
	@Override
	public java.lang.String getDocPath() {
		return _dischargeSummary.getDocPath();
	}

	/**
	* Sets the doc path of this discharge summary.
	*
	* @param docPath the doc path of this discharge summary
	*/
	@Override
	public void setDocPath(java.lang.String docPath) {
		_dischargeSummary.setDocPath(docPath);
	}

	/**
	* Returns the department name of this discharge summary.
	*
	* @return the department name of this discharge summary
	*/
	@Override
	public java.lang.String getDepartmentName() {
		return _dischargeSummary.getDepartmentName();
	}

	/**
	* Sets the department name of this discharge summary.
	*
	* @param departmentName the department name of this discharge summary
	*/
	@Override
	public void setDepartmentName(java.lang.String departmentName) {
		_dischargeSummary.setDepartmentName(departmentName);
	}

	/**
	* Returns the status of this discharge summary.
	*
	* @return the status of this discharge summary
	*/
	@Override
	public boolean getStatus() {
		return _dischargeSummary.getStatus();
	}

	/**
	* Returns <code>true</code> if this discharge summary is status.
	*
	* @return <code>true</code> if this discharge summary is status; <code>false</code> otherwise
	*/
	@Override
	public boolean isStatus() {
		return _dischargeSummary.isStatus();
	}

	/**
	* Sets whether this discharge summary is status.
	*
	* @param status the status of this discharge summary
	*/
	@Override
	public void setStatus(boolean status) {
		_dischargeSummary.setStatus(status);
	}

	/**
	* Returns the ward of this discharge summary.
	*
	* @return the ward of this discharge summary
	*/
	@Override
	public java.lang.String getWard() {
		return _dischargeSummary.getWard();
	}

	/**
	* Sets the ward of this discharge summary.
	*
	* @param ward the ward of this discharge summary
	*/
	@Override
	public void setWard(java.lang.String ward) {
		_dischargeSummary.setWard(ward);
	}

	/**
	* Returns the bed class of this discharge summary.
	*
	* @return the bed class of this discharge summary
	*/
	@Override
	public java.lang.String getBedClass() {
		return _dischargeSummary.getBedClass();
	}

	/**
	* Sets the bed class of this discharge summary.
	*
	* @param bedClass the bed class of this discharge summary
	*/
	@Override
	public void setBedClass(java.lang.String bedClass) {
		_dischargeSummary.setBedClass(bedClass);
	}

	/**
	* Returns the discharge date of this discharge summary.
	*
	* @return the discharge date of this discharge summary
	*/
	@Override
	public java.util.Date getDischargeDate() {
		return _dischargeSummary.getDischargeDate();
	}

	/**
	* Sets the discharge date of this discharge summary.
	*
	* @param dischargeDate the discharge date of this discharge summary
	*/
	@Override
	public void setDischargeDate(java.util.Date dischargeDate) {
		_dischargeSummary.setDischargeDate(dischargeDate);
	}

	/**
	* Returns the admission date of this discharge summary.
	*
	* @return the admission date of this discharge summary
	*/
	@Override
	public java.util.Date getAdmissionDate() {
		return _dischargeSummary.getAdmissionDate();
	}

	/**
	* Sets the admission date of this discharge summary.
	*
	* @param admissionDate the admission date of this discharge summary
	*/
	@Override
	public void setAdmissionDate(java.util.Date admissionDate) {
		_dischargeSummary.setAdmissionDate(admissionDate);
	}

	/**
	* Returns the primary doctor of this discharge summary.
	*
	* @return the primary doctor of this discharge summary
	*/
	@Override
	public java.lang.String getPrimaryDoctor() {
		return _dischargeSummary.getPrimaryDoctor();
	}

	/**
	* Sets the primary doctor of this discharge summary.
	*
	* @param primaryDoctor the primary doctor of this discharge summary
	*/
	@Override
	public void setPrimaryDoctor(java.lang.String primaryDoctor) {
		_dischargeSummary.setPrimaryDoctor(primaryDoctor);
	}

	/**
	* Returns the chief complaint of this discharge summary.
	*
	* @return the chief complaint of this discharge summary
	*/
	@Override
	public java.lang.String getChiefComplaint() {
		return _dischargeSummary.getChiefComplaint();
	}

	/**
	* Sets the chief complaint of this discharge summary.
	*
	* @param chiefComplaint the chief complaint of this discharge summary
	*/
	@Override
	public void setChiefComplaint(java.lang.String chiefComplaint) {
		_dischargeSummary.setChiefComplaint(chiefComplaint);
	}

	@Override
	public boolean isNew() {
		return _dischargeSummary.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_dischargeSummary.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _dischargeSummary.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_dischargeSummary.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _dischargeSummary.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _dischargeSummary.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_dischargeSummary.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _dischargeSummary.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_dischargeSummary.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_dischargeSummary.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_dischargeSummary.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DischargeSummaryWrapper((DischargeSummary)_dischargeSummary.clone());
	}

	@Override
	public int compareTo(
		com.napier.portal.db.model.DischargeSummary dischargeSummary) {
		return _dischargeSummary.compareTo(dischargeSummary);
	}

	@Override
	public int hashCode() {
		return _dischargeSummary.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.DischargeSummary> toCacheModel() {
		return _dischargeSummary.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.DischargeSummary toEscapedModel() {
		return new DischargeSummaryWrapper(_dischargeSummary.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.DischargeSummary toUnescapedModel() {
		return new DischargeSummaryWrapper(_dischargeSummary.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _dischargeSummary.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _dischargeSummary.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_dischargeSummary.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DischargeSummaryWrapper)) {
			return false;
		}

		DischargeSummaryWrapper dischargeSummaryWrapper = (DischargeSummaryWrapper)obj;

		if (Validator.equals(_dischargeSummary,
					dischargeSummaryWrapper._dischargeSummary)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public DischargeSummary getWrappedDischargeSummary() {
		return _dischargeSummary;
	}

	@Override
	public DischargeSummary getWrappedModel() {
		return _dischargeSummary;
	}

	@Override
	public void resetOriginalValues() {
		_dischargeSummary.resetOriginalValues();
	}

	private DischargeSummary _dischargeSummary;
}