/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.PatientBillLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class PatientBillClp extends BaseModelImpl<PatientBill>
	implements PatientBill {
	public PatientBillClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return PatientBill.class;
	}

	@Override
	public String getModelClassName() {
		return PatientBill.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _patientBillId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setPatientBillId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _patientBillId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("patientBillId", getPatientBillId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("billNumber", getBillNumber());
		attributes.put("company", getCompany());
		attributes.put("sponser", getSponser());
		attributes.put("planName", getPlanName());
		attributes.put("planExpiry", getPlanExpiry());
		attributes.put("admissionDate", getAdmissionDate());
		attributes.put("isBillgenerated", getIsBillgenerated());
		attributes.put("isBalanceAmount", getIsBalanceAmount());
		attributes.put("billAmount", getBillAmount());
		attributes.put("paidAmount", getPaidAmount());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long patientBillId = (Long)attributes.get("patientBillId");

		if (patientBillId != null) {
			setPatientBillId(patientBillId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String billNumber = (String)attributes.get("billNumber");

		if (billNumber != null) {
			setBillNumber(billNumber);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String sponser = (String)attributes.get("sponser");

		if (sponser != null) {
			setSponser(sponser);
		}

		String planName = (String)attributes.get("planName");

		if (planName != null) {
			setPlanName(planName);
		}

		Date planExpiry = (Date)attributes.get("planExpiry");

		if (planExpiry != null) {
			setPlanExpiry(planExpiry);
		}

		Date admissionDate = (Date)attributes.get("admissionDate");

		if (admissionDate != null) {
			setAdmissionDate(admissionDate);
		}

		Boolean isBillgenerated = (Boolean)attributes.get("isBillgenerated");

		if (isBillgenerated != null) {
			setIsBillgenerated(isBillgenerated);
		}

		Boolean isBalanceAmount = (Boolean)attributes.get("isBalanceAmount");

		if (isBalanceAmount != null) {
			setIsBalanceAmount(isBalanceAmount);
		}

		Double billAmount = (Double)attributes.get("billAmount");

		if (billAmount != null) {
			setBillAmount(billAmount);
		}

		Double paidAmount = (Double)attributes.get("paidAmount");

		if (paidAmount != null) {
			setPaidAmount(paidAmount);
		}
	}

	@Override
	public long getPatientBillId() {
		return _patientBillId;
	}

	@Override
	public void setPatientBillId(long patientBillId) {
		_patientBillId = patientBillId;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setPatientBillId", long.class);

				method.invoke(_patientBillRemoteModel, patientBillId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_patientBillRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getIpNumber() {
		return _ipNumber;
	}

	@Override
	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setIpNumber", String.class);

				method.invoke(_patientBillRemoteModel, ipNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getBillNumber() {
		return _billNumber;
	}

	@Override
	public void setBillNumber(String billNumber) {
		_billNumber = billNumber;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setBillNumber", String.class);

				method.invoke(_patientBillRemoteModel, billNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompany() {
		return _company;
	}

	@Override
	public void setCompany(String company) {
		_company = company;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setCompany", String.class);

				method.invoke(_patientBillRemoteModel, company);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSponser() {
		return _sponser;
	}

	@Override
	public void setSponser(String sponser) {
		_sponser = sponser;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setSponser", String.class);

				method.invoke(_patientBillRemoteModel, sponser);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPlanName() {
		return _planName;
	}

	@Override
	public void setPlanName(String planName) {
		_planName = planName;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setPlanName", String.class);

				method.invoke(_patientBillRemoteModel, planName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getPlanExpiry() {
		return _planExpiry;
	}

	@Override
	public void setPlanExpiry(Date planExpiry) {
		_planExpiry = planExpiry;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setPlanExpiry", Date.class);

				method.invoke(_patientBillRemoteModel, planExpiry);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getAdmissionDate() {
		return _admissionDate;
	}

	@Override
	public void setAdmissionDate(Date admissionDate) {
		_admissionDate = admissionDate;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setAdmissionDate", Date.class);

				method.invoke(_patientBillRemoteModel, admissionDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getIsBillgenerated() {
		return _isBillgenerated;
	}

	@Override
	public boolean isIsBillgenerated() {
		return _isBillgenerated;
	}

	@Override
	public void setIsBillgenerated(boolean isBillgenerated) {
		_isBillgenerated = isBillgenerated;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setIsBillgenerated",
						boolean.class);

				method.invoke(_patientBillRemoteModel, isBillgenerated);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getIsBalanceAmount() {
		return _isBalanceAmount;
	}

	@Override
	public boolean isIsBalanceAmount() {
		return _isBalanceAmount;
	}

	@Override
	public void setIsBalanceAmount(boolean isBalanceAmount) {
		_isBalanceAmount = isBalanceAmount;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setIsBalanceAmount",
						boolean.class);

				method.invoke(_patientBillRemoteModel, isBalanceAmount);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getBillAmount() {
		return _billAmount;
	}

	@Override
	public void setBillAmount(double billAmount) {
		_billAmount = billAmount;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setBillAmount", double.class);

				method.invoke(_patientBillRemoteModel, billAmount);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getPaidAmount() {
		return _paidAmount;
	}

	@Override
	public void setPaidAmount(double paidAmount) {
		_paidAmount = paidAmount;

		if (_patientBillRemoteModel != null) {
			try {
				Class<?> clazz = _patientBillRemoteModel.getClass();

				Method method = clazz.getMethod("setPaidAmount", double.class);

				method.invoke(_patientBillRemoteModel, paidAmount);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getPatientBillRemoteModel() {
		return _patientBillRemoteModel;
	}

	public void setPatientBillRemoteModel(BaseModel<?> patientBillRemoteModel) {
		_patientBillRemoteModel = patientBillRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _patientBillRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_patientBillRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			PatientBillLocalServiceUtil.addPatientBill(this);
		}
		else {
			PatientBillLocalServiceUtil.updatePatientBill(this);
		}
	}

	@Override
	public PatientBill toEscapedModel() {
		return (PatientBill)ProxyUtil.newProxyInstance(PatientBill.class.getClassLoader(),
			new Class[] { PatientBill.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		PatientBillClp clone = new PatientBillClp();

		clone.setPatientBillId(getPatientBillId());
		clone.setMrNumber(getMrNumber());
		clone.setIpNumber(getIpNumber());
		clone.setBillNumber(getBillNumber());
		clone.setCompany(getCompany());
		clone.setSponser(getSponser());
		clone.setPlanName(getPlanName());
		clone.setPlanExpiry(getPlanExpiry());
		clone.setAdmissionDate(getAdmissionDate());
		clone.setIsBillgenerated(getIsBillgenerated());
		clone.setIsBalanceAmount(getIsBalanceAmount());
		clone.setBillAmount(getBillAmount());
		clone.setPaidAmount(getPaidAmount());

		return clone;
	}

	@Override
	public int compareTo(PatientBill patientBill) {
		int value = 0;

		value = DateUtil.compareTo(getAdmissionDate(),
				patientBill.getAdmissionDate());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof PatientBillClp)) {
			return false;
		}

		PatientBillClp patientBill = (PatientBillClp)obj;

		long primaryKey = patientBill.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{patientBillId=");
		sb.append(getPatientBillId());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", ipNumber=");
		sb.append(getIpNumber());
		sb.append(", billNumber=");
		sb.append(getBillNumber());
		sb.append(", company=");
		sb.append(getCompany());
		sb.append(", sponser=");
		sb.append(getSponser());
		sb.append(", planName=");
		sb.append(getPlanName());
		sb.append(", planExpiry=");
		sb.append(getPlanExpiry());
		sb.append(", admissionDate=");
		sb.append(getAdmissionDate());
		sb.append(", isBillgenerated=");
		sb.append(getIsBillgenerated());
		sb.append(", isBalanceAmount=");
		sb.append(getIsBalanceAmount());
		sb.append(", billAmount=");
		sb.append(getBillAmount());
		sb.append(", paidAmount=");
		sb.append(getPaidAmount());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(43);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.PatientBill");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>patientBillId</column-name><column-value><![CDATA[");
		sb.append(getPatientBillId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ipNumber</column-name><column-value><![CDATA[");
		sb.append(getIpNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>billNumber</column-name><column-value><![CDATA[");
		sb.append(getBillNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>company</column-name><column-value><![CDATA[");
		sb.append(getCompany());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>sponser</column-name><column-value><![CDATA[");
		sb.append(getSponser());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>planName</column-name><column-value><![CDATA[");
		sb.append(getPlanName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>planExpiry</column-name><column-value><![CDATA[");
		sb.append(getPlanExpiry());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>admissionDate</column-name><column-value><![CDATA[");
		sb.append(getAdmissionDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>isBillgenerated</column-name><column-value><![CDATA[");
		sb.append(getIsBillgenerated());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>isBalanceAmount</column-name><column-value><![CDATA[");
		sb.append(getIsBalanceAmount());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>billAmount</column-name><column-value><![CDATA[");
		sb.append(getBillAmount());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>paidAmount</column-name><column-value><![CDATA[");
		sb.append(getPaidAmount());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _patientBillId;
	private String _mrNumber;
	private String _ipNumber;
	private String _billNumber;
	private String _company;
	private String _sponser;
	private String _planName;
	private Date _planExpiry;
	private Date _admissionDate;
	private boolean _isBillgenerated;
	private boolean _isBalanceAmount;
	private double _billAmount;
	private double _paidAmount;
	private BaseModel<?> _patientBillRemoteModel;
}