/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.napier.portal.db.model.DiagnosticReport;

import java.util.List;

/**
 * The persistence utility for the diagnostic report service. This utility wraps {@link DiagnosticReportPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DiagnosticReportPersistence
 * @see DiagnosticReportPersistenceImpl
 * @generated
 */
public class DiagnosticReportUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(DiagnosticReport diagnosticReport) {
		getPersistence().clearCache(diagnosticReport);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<DiagnosticReport> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<DiagnosticReport> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<DiagnosticReport> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static DiagnosticReport update(DiagnosticReport diagnosticReport)
		throws SystemException {
		return getPersistence().update(diagnosticReport);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static DiagnosticReport update(DiagnosticReport diagnosticReport,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(diagnosticReport, serviceContext);
	}

	/**
	* Returns all the diagnostic reports where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber);
	}

	/**
	* Returns a range of all the diagnostic reports where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @return the range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber, start, end);
	}

	/**
	* Returns an ordered range of all the diagnostic reports where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBymrNumber(mrNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the diagnostic reports before and after the current diagnostic report in the ordered set where mrNumber = &#63;.
	*
	* @param diagnosticId the primary key of the current diagnostic report
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport[] findBymrNumber_PrevAndNext(
		long diagnosticId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence()
				   .findBymrNumber_PrevAndNext(diagnosticId, mrNumber,
			orderByComparator);
	}

	/**
	* Removes all the diagnostic reports where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBymrNumber(mrNumber);
	}

	/**
	* Returns the number of diagnostic reports where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBymrNumber(mrNumber);
	}

	/**
	* Returns all the diagnostic reports where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber);
	}

	/**
	* Returns a range of all the diagnostic reports where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @return the range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber, start, end);
	}

	/**
	* Returns an ordered range of all the diagnostic reports where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByipNumber(ipNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the diagnostic reports before and after the current diagnostic report in the ordered set where ipNumber = &#63;.
	*
	* @param diagnosticId the primary key of the current diagnostic report
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport[] findByipNumber_PrevAndNext(
		long diagnosticId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence()
				   .findByipNumber_PrevAndNext(diagnosticId, ipNumber,
			orderByComparator);
	}

	/**
	* Removes all the diagnostic reports where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByipNumber(ipNumber);
	}

	/**
	* Returns the number of diagnostic reports where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByipNumber(ipNumber);
	}

	/**
	* Returns all the diagnostic reports where testName = &#63;.
	*
	* @param testName the test name
	* @return the matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBytestName(
		java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBytestName(testName);
	}

	/**
	* Returns a range of all the diagnostic reports where testName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param testName the test name
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @return the range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBytestName(
		java.lang.String testName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBytestName(testName, start, end);
	}

	/**
	* Returns an ordered range of all the diagnostic reports where testName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param testName the test name
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBytestName(
		java.lang.String testName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBytestName(testName, start, end, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findBytestName_First(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findBytestName_First(testName, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchBytestName_First(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBytestName_First(testName, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findBytestName_Last(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findBytestName_Last(testName, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchBytestName_Last(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBytestName_Last(testName, orderByComparator);
	}

	/**
	* Returns the diagnostic reports before and after the current diagnostic report in the ordered set where testName = &#63;.
	*
	* @param diagnosticId the primary key of the current diagnostic report
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport[] findBytestName_PrevAndNext(
		long diagnosticId, java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence()
				   .findBytestName_PrevAndNext(diagnosticId, testName,
			orderByComparator);
	}

	/**
	* Removes all the diagnostic reports where testName = &#63; from the database.
	*
	* @param testName the test name
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBytestName(java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBytestName(testName);
	}

	/**
	* Returns the number of diagnostic reports where testName = &#63;.
	*
	* @param testName the test name
	* @return the number of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countBytestName(java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBytestName(testName);
	}

	/**
	* Returns all the diagnostic reports where status = &#63;.
	*
	* @param status the status
	* @return the matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBystatus(
		boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatus(status);
	}

	/**
	* Returns a range of all the diagnostic reports where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @return the range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBystatus(
		boolean status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatus(status, start, end);
	}

	/**
	* Returns an ordered range of all the diagnostic reports where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findBystatus(
		boolean status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBystatus(status, start, end, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findBystatus_First(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findBystatus_First(status, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchBystatus_First(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatus_First(status, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findBystatus_Last(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findBystatus_Last(status, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchBystatus_Last(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatus_Last(status, orderByComparator);
	}

	/**
	* Returns the diagnostic reports before and after the current diagnostic report in the ordered set where status = &#63;.
	*
	* @param diagnosticId the primary key of the current diagnostic report
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport[] findBystatus_PrevAndNext(
		long diagnosticId, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence()
				   .findBystatus_PrevAndNext(diagnosticId, status,
			orderByComparator);
	}

	/**
	* Removes all the diagnostic reports where status = &#63; from the database.
	*
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystatus(boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystatus(status);
	}

	/**
	* Returns the number of diagnostic reports where status = &#63;.
	*
	* @param status the status
	* @return the number of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystatus(boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystatus(status);
	}

	/**
	* Returns all the diagnostic reports where mrNumber = &#63; and status = &#63;.
	*
	* @param mrNumber the mr number
	* @param status the status
	* @return the matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findByMR_STATUS(
		java.lang.String mrNumber, boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByMR_STATUS(mrNumber, status);
	}

	/**
	* Returns a range of all the diagnostic reports where mrNumber = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param status the status
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @return the range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findByMR_STATUS(
		java.lang.String mrNumber, boolean status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByMR_STATUS(mrNumber, status, start, end);
	}

	/**
	* Returns an ordered range of all the diagnostic reports where mrNumber = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param status the status
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findByMR_STATUS(
		java.lang.String mrNumber, boolean status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByMR_STATUS(mrNumber, status, start, end,
			orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	*
	* @param mrNumber the mr number
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findByMR_STATUS_First(
		java.lang.String mrNumber, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence()
				   .findByMR_STATUS_First(mrNumber, status, orderByComparator);
	}

	/**
	* Returns the first diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	*
	* @param mrNumber the mr number
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchByMR_STATUS_First(
		java.lang.String mrNumber, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByMR_STATUS_First(mrNumber, status, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	*
	* @param mrNumber the mr number
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findByMR_STATUS_Last(
		java.lang.String mrNumber, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence()
				   .findByMR_STATUS_Last(mrNumber, status, orderByComparator);
	}

	/**
	* Returns the last diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	*
	* @param mrNumber the mr number
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching diagnostic report, or <code>null</code> if a matching diagnostic report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchByMR_STATUS_Last(
		java.lang.String mrNumber, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByMR_STATUS_Last(mrNumber, status, orderByComparator);
	}

	/**
	* Returns the diagnostic reports before and after the current diagnostic report in the ordered set where mrNumber = &#63; and status = &#63;.
	*
	* @param diagnosticId the primary key of the current diagnostic report
	* @param mrNumber the mr number
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport[] findByMR_STATUS_PrevAndNext(
		long diagnosticId, java.lang.String mrNumber, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence()
				   .findByMR_STATUS_PrevAndNext(diagnosticId, mrNumber, status,
			orderByComparator);
	}

	/**
	* Removes all the diagnostic reports where mrNumber = &#63; and status = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByMR_STATUS(java.lang.String mrNumber,
		boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByMR_STATUS(mrNumber, status);
	}

	/**
	* Returns the number of diagnostic reports where mrNumber = &#63; and status = &#63;.
	*
	* @param mrNumber the mr number
	* @param status the status
	* @return the number of matching diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countByMR_STATUS(java.lang.String mrNumber, boolean status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByMR_STATUS(mrNumber, status);
	}

	/**
	* Caches the diagnostic report in the entity cache if it is enabled.
	*
	* @param diagnosticReport the diagnostic report
	*/
	public static void cacheResult(
		com.napier.portal.db.model.DiagnosticReport diagnosticReport) {
		getPersistence().cacheResult(diagnosticReport);
	}

	/**
	* Caches the diagnostic reports in the entity cache if it is enabled.
	*
	* @param diagnosticReports the diagnostic reports
	*/
	public static void cacheResult(
		java.util.List<com.napier.portal.db.model.DiagnosticReport> diagnosticReports) {
		getPersistence().cacheResult(diagnosticReports);
	}

	/**
	* Creates a new diagnostic report with the primary key. Does not add the diagnostic report to the database.
	*
	* @param diagnosticId the primary key for the new diagnostic report
	* @return the new diagnostic report
	*/
	public static com.napier.portal.db.model.DiagnosticReport create(
		long diagnosticId) {
		return getPersistence().create(diagnosticId);
	}

	/**
	* Removes the diagnostic report with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param diagnosticId the primary key of the diagnostic report
	* @return the diagnostic report that was removed
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport remove(
		long diagnosticId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().remove(diagnosticId);
	}

	public static com.napier.portal.db.model.DiagnosticReport updateImpl(
		com.napier.portal.db.model.DiagnosticReport diagnosticReport)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(diagnosticReport);
	}

	/**
	* Returns the diagnostic report with the primary key or throws a {@link com.napier.portal.db.NoSuchDiagnosticReportException} if it could not be found.
	*
	* @param diagnosticId the primary key of the diagnostic report
	* @return the diagnostic report
	* @throws com.napier.portal.db.NoSuchDiagnosticReportException if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport findByPrimaryKey(
		long diagnosticId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDiagnosticReportException {
		return getPersistence().findByPrimaryKey(diagnosticId);
	}

	/**
	* Returns the diagnostic report with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param diagnosticId the primary key of the diagnostic report
	* @return the diagnostic report, or <code>null</code> if a diagnostic report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DiagnosticReport fetchByPrimaryKey(
		long diagnosticId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(diagnosticId);
	}

	/**
	* Returns all the diagnostic reports.
	*
	* @return the diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the diagnostic reports.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @return the range of diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the diagnostic reports.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DiagnosticReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of diagnostic reports
	* @param end the upper bound of the range of diagnostic reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DiagnosticReport> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the diagnostic reports from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of diagnostic reports.
	*
	* @return the number of diagnostic reports
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static DiagnosticReportPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (DiagnosticReportPersistence)PortletBeanLocatorUtil.locate(com.napier.portal.db.service.ClpSerializer.getServletContextName(),
					DiagnosticReportPersistence.class.getName());

			ReferenceRegistry.registerReference(DiagnosticReportUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(DiagnosticReportPersistence persistence) {
	}

	private static DiagnosticReportPersistence _persistence;
}