/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link NapierUserLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see NapierUserLocalService
 * @generated
 */
public class NapierUserLocalServiceWrapper implements NapierUserLocalService,
	ServiceWrapper<NapierUserLocalService> {
	public NapierUserLocalServiceWrapper(
		NapierUserLocalService napierUserLocalService) {
		_napierUserLocalService = napierUserLocalService;
	}

	/**
	* Adds the napier user to the database. Also notifies the appropriate model listeners.
	*
	* @param napierUser the napier user
	* @return the napier user that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.napier.portal.db.model.NapierUser addNapierUser(
		com.napier.portal.db.model.NapierUser napierUser)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.addNapierUser(napierUser);
	}

	/**
	* Creates a new napier user with the primary key. Does not add the napier user to the database.
	*
	* @param napierUserId the primary key for the new napier user
	* @return the new napier user
	*/
	@Override
	public com.napier.portal.db.model.NapierUser createNapierUser(
		long napierUserId) {
		return _napierUserLocalService.createNapierUser(napierUserId);
	}

	/**
	* Deletes the napier user with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param napierUserId the primary key of the napier user
	* @return the napier user that was removed
	* @throws PortalException if a napier user with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.napier.portal.db.model.NapierUser deleteNapierUser(
		long napierUserId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.deleteNapierUser(napierUserId);
	}

	/**
	* Deletes the napier user from the database. Also notifies the appropriate model listeners.
	*
	* @param napierUser the napier user
	* @return the napier user that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.napier.portal.db.model.NapierUser deleteNapierUser(
		com.napier.portal.db.model.NapierUser napierUser)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.deleteNapierUser(napierUser);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _napierUserLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.NapierUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.NapierUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.napier.portal.db.model.NapierUser fetchNapierUser(
		long napierUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.fetchNapierUser(napierUserId);
	}

	/**
	* Returns the napier user with the primary key.
	*
	* @param napierUserId the primary key of the napier user
	* @return the napier user
	* @throws PortalException if a napier user with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.napier.portal.db.model.NapierUser getNapierUser(
		long napierUserId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.getNapierUser(napierUserId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the napier users.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.NapierUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of napier users
	* @param end the upper bound of the range of napier users (not inclusive)
	* @return the range of napier users
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.napier.portal.db.model.NapierUser> getNapierUsers(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.getNapierUsers(start, end);
	}

	/**
	* Returns the number of napier users.
	*
	* @return the number of napier users
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getNapierUsersCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.getNapierUsersCount();
	}

	/**
	* Updates the napier user in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param napierUser the napier user
	* @return the napier user that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.napier.portal.db.model.NapierUser updateNapierUser(
		com.napier.portal.db.model.NapierUser napierUser)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _napierUserLocalService.updateNapierUser(napierUser);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _napierUserLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_napierUserLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _napierUserLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	@Override
	public com.napier.portal.db.model.NapierUser getByportalUserId(
		long portalUserId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchNapierUserException {
		return _napierUserLocalService.getByportalUserId(portalUserId);
	}

	@Override
	public com.napier.portal.db.model.NapierUser getBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchNapierUserException {
		return _napierUserLocalService.getBymrNumber(mrNumber);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public NapierUserLocalService getWrappedNapierUserLocalService() {
		return _napierUserLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedNapierUserLocalService(
		NapierUserLocalService napierUserLocalService) {
		_napierUserLocalService = napierUserLocalService;
	}

	@Override
	public NapierUserLocalService getWrappedService() {
		return _napierUserLocalService;
	}

	@Override
	public void setWrappedService(NapierUserLocalService napierUserLocalService) {
		_napierUserLocalService = napierUserLocalService;
	}

	private NapierUserLocalService _napierUserLocalService;
}