/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.LabReportLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class LabReportClp extends BaseModelImpl<LabReport> implements LabReport {
	public LabReportClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return LabReport.class;
	}

	@Override
	public String getModelClassName() {
		return LabReport.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _labId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setLabId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _labId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("labId", getLabId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("orderNumber", getOrderNumber());
		attributes.put("orderDate", getOrderDate());
		attributes.put("reportedOn", getReportedOn());
		attributes.put("testName", getTestName());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("docPath", getDocPath());
		attributes.put("departmentName", getDepartmentName());
		attributes.put("status", getStatus());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long labId = (Long)attributes.get("labId");

		if (labId != null) {
			setLabId(labId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String orderNumber = (String)attributes.get("orderNumber");

		if (orderNumber != null) {
			setOrderNumber(orderNumber);
		}

		Date orderDate = (Date)attributes.get("orderDate");

		if (orderDate != null) {
			setOrderDate(orderDate);
		}

		Date reportedOn = (Date)attributes.get("reportedOn");

		if (reportedOn != null) {
			setReportedOn(reportedOn);
		}

		String testName = (String)attributes.get("testName");

		if (testName != null) {
			setTestName(testName);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String docPath = (String)attributes.get("docPath");

		if (docPath != null) {
			setDocPath(docPath);
		}

		String departmentName = (String)attributes.get("departmentName");

		if (departmentName != null) {
			setDepartmentName(departmentName);
		}

		Boolean status = (Boolean)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}
	}

	@Override
	public long getLabId() {
		return _labId;
	}

	@Override
	public void setLabId(long labId) {
		_labId = labId;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setLabId", long.class);

				method.invoke(_labReportRemoteModel, labId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_labReportRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOrderNumber() {
		return _orderNumber;
	}

	@Override
	public void setOrderNumber(String orderNumber) {
		_orderNumber = orderNumber;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setOrderNumber", String.class);

				method.invoke(_labReportRemoteModel, orderNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getOrderDate() {
		return _orderDate;
	}

	@Override
	public void setOrderDate(Date orderDate) {
		_orderDate = orderDate;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setOrderDate", Date.class);

				method.invoke(_labReportRemoteModel, orderDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getReportedOn() {
		return _reportedOn;
	}

	@Override
	public void setReportedOn(Date reportedOn) {
		_reportedOn = reportedOn;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setReportedOn", Date.class);

				method.invoke(_labReportRemoteModel, reportedOn);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTestName() {
		return _testName;
	}

	@Override
	public void setTestName(String testName) {
		_testName = testName;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setTestName", String.class);

				method.invoke(_labReportRemoteModel, testName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getIpNumber() {
		return _ipNumber;
	}

	@Override
	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setIpNumber", String.class);

				method.invoke(_labReportRemoteModel, ipNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDocPath() {
		return _docPath;
	}

	@Override
	public void setDocPath(String docPath) {
		_docPath = docPath;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setDocPath", String.class);

				method.invoke(_labReportRemoteModel, docPath);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDepartmentName() {
		return _departmentName;
	}

	@Override
	public void setDepartmentName(String departmentName) {
		_departmentName = departmentName;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setDepartmentName",
						String.class);

				method.invoke(_labReportRemoteModel, departmentName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getStatus() {
		return _status;
	}

	@Override
	public boolean isStatus() {
		return _status;
	}

	@Override
	public void setStatus(boolean status) {
		_status = status;

		if (_labReportRemoteModel != null) {
			try {
				Class<?> clazz = _labReportRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", boolean.class);

				method.invoke(_labReportRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getLabReportRemoteModel() {
		return _labReportRemoteModel;
	}

	public void setLabReportRemoteModel(BaseModel<?> labReportRemoteModel) {
		_labReportRemoteModel = labReportRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _labReportRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_labReportRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			LabReportLocalServiceUtil.addLabReport(this);
		}
		else {
			LabReportLocalServiceUtil.updateLabReport(this);
		}
	}

	@Override
	public LabReport toEscapedModel() {
		return (LabReport)ProxyUtil.newProxyInstance(LabReport.class.getClassLoader(),
			new Class[] { LabReport.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		LabReportClp clone = new LabReportClp();

		clone.setLabId(getLabId());
		clone.setMrNumber(getMrNumber());
		clone.setOrderNumber(getOrderNumber());
		clone.setOrderDate(getOrderDate());
		clone.setReportedOn(getReportedOn());
		clone.setTestName(getTestName());
		clone.setIpNumber(getIpNumber());
		clone.setDocPath(getDocPath());
		clone.setDepartmentName(getDepartmentName());
		clone.setStatus(getStatus());

		return clone;
	}

	@Override
	public int compareTo(LabReport labReport) {
		int value = 0;

		value = DateUtil.compareTo(getOrderDate(), labReport.getOrderDate());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LabReportClp)) {
			return false;
		}

		LabReportClp labReport = (LabReportClp)obj;

		long primaryKey = labReport.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{labId=");
		sb.append(getLabId());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", orderNumber=");
		sb.append(getOrderNumber());
		sb.append(", orderDate=");
		sb.append(getOrderDate());
		sb.append(", reportedOn=");
		sb.append(getReportedOn());
		sb.append(", testName=");
		sb.append(getTestName());
		sb.append(", ipNumber=");
		sb.append(getIpNumber());
		sb.append(", docPath=");
		sb.append(getDocPath());
		sb.append(", departmentName=");
		sb.append(getDepartmentName());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(34);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.LabReport");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>labId</column-name><column-value><![CDATA[");
		sb.append(getLabId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>orderNumber</column-name><column-value><![CDATA[");
		sb.append(getOrderNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>orderDate</column-name><column-value><![CDATA[");
		sb.append(getOrderDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>reportedOn</column-name><column-value><![CDATA[");
		sb.append(getReportedOn());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>testName</column-name><column-value><![CDATA[");
		sb.append(getTestName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ipNumber</column-name><column-value><![CDATA[");
		sb.append(getIpNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>docPath</column-name><column-value><![CDATA[");
		sb.append(getDocPath());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>departmentName</column-name><column-value><![CDATA[");
		sb.append(getDepartmentName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _labId;
	private String _mrNumber;
	private String _orderNumber;
	private Date _orderDate;
	private Date _reportedOn;
	private String _testName;
	private String _ipNumber;
	private String _docPath;
	private String _departmentName;
	private boolean _status;
	private BaseModel<?> _labReportRemoteModel;
}