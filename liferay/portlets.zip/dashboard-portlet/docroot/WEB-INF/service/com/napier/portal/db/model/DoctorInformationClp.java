/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.DoctorInformationLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class DoctorInformationClp extends BaseModelImpl<DoctorInformation>
	implements DoctorInformation {
	public DoctorInformationClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return DoctorInformation.class;
	}

	@Override
	public String getModelClassName() {
		return DoctorInformation.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _doctorInfoId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDoctorInfoId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _doctorInfoId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("doctorInfoId", getDoctorInfoId());
		attributes.put("specialization", getSpecialization());
		attributes.put("doctorName", getDoctorName());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long doctorInfoId = (Long)attributes.get("doctorInfoId");

		if (doctorInfoId != null) {
			setDoctorInfoId(doctorInfoId);
		}

		String specialization = (String)attributes.get("specialization");

		if (specialization != null) {
			setSpecialization(specialization);
		}

		String doctorName = (String)attributes.get("doctorName");

		if (doctorName != null) {
			setDoctorName(doctorName);
		}
	}

	@Override
	public long getDoctorInfoId() {
		return _doctorInfoId;
	}

	@Override
	public void setDoctorInfoId(long doctorInfoId) {
		_doctorInfoId = doctorInfoId;

		if (_doctorInformationRemoteModel != null) {
			try {
				Class<?> clazz = _doctorInformationRemoteModel.getClass();

				Method method = clazz.getMethod("setDoctorInfoId", long.class);

				method.invoke(_doctorInformationRemoteModel, doctorInfoId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSpecialization() {
		return _specialization;
	}

	@Override
	public void setSpecialization(String specialization) {
		_specialization = specialization;

		if (_doctorInformationRemoteModel != null) {
			try {
				Class<?> clazz = _doctorInformationRemoteModel.getClass();

				Method method = clazz.getMethod("setSpecialization",
						String.class);

				method.invoke(_doctorInformationRemoteModel, specialization);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDoctorName() {
		return _doctorName;
	}

	@Override
	public void setDoctorName(String doctorName) {
		_doctorName = doctorName;

		if (_doctorInformationRemoteModel != null) {
			try {
				Class<?> clazz = _doctorInformationRemoteModel.getClass();

				Method method = clazz.getMethod("setDoctorName", String.class);

				method.invoke(_doctorInformationRemoteModel, doctorName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getDoctorInformationRemoteModel() {
		return _doctorInformationRemoteModel;
	}

	public void setDoctorInformationRemoteModel(
		BaseModel<?> doctorInformationRemoteModel) {
		_doctorInformationRemoteModel = doctorInformationRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _doctorInformationRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_doctorInformationRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DoctorInformationLocalServiceUtil.addDoctorInformation(this);
		}
		else {
			DoctorInformationLocalServiceUtil.updateDoctorInformation(this);
		}
	}

	@Override
	public DoctorInformation toEscapedModel() {
		return (DoctorInformation)ProxyUtil.newProxyInstance(DoctorInformation.class.getClassLoader(),
			new Class[] { DoctorInformation.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DoctorInformationClp clone = new DoctorInformationClp();

		clone.setDoctorInfoId(getDoctorInfoId());
		clone.setSpecialization(getSpecialization());
		clone.setDoctorName(getDoctorName());

		return clone;
	}

	@Override
	public int compareTo(DoctorInformation doctorInformation) {
		long primaryKey = doctorInformation.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DoctorInformationClp)) {
			return false;
		}

		DoctorInformationClp doctorInformation = (DoctorInformationClp)obj;

		long primaryKey = doctorInformation.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{doctorInfoId=");
		sb.append(getDoctorInfoId());
		sb.append(", specialization=");
		sb.append(getSpecialization());
		sb.append(", doctorName=");
		sb.append(getDoctorName());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(13);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.DoctorInformation");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>doctorInfoId</column-name><column-value><![CDATA[");
		sb.append(getDoctorInfoId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>specialization</column-name><column-value><![CDATA[");
		sb.append(getSpecialization());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>doctorName</column-name><column-value><![CDATA[");
		sb.append(getDoctorName());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _doctorInfoId;
	private String _specialization;
	private String _doctorName;
	private BaseModel<?> _doctorInformationRemoteModel;
}