/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class PatientBillSoap implements Serializable {
	public static PatientBillSoap toSoapModel(PatientBill model) {
		PatientBillSoap soapModel = new PatientBillSoap();

		soapModel.setPatientBillId(model.getPatientBillId());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setIpNumber(model.getIpNumber());
		soapModel.setBillNumber(model.getBillNumber());
		soapModel.setCompany(model.getCompany());
		soapModel.setSponser(model.getSponser());
		soapModel.setPlanName(model.getPlanName());
		soapModel.setPlanExpiry(model.getPlanExpiry());
		soapModel.setAdmissionDate(model.getAdmissionDate());
		soapModel.setIsBillgenerated(model.getIsBillgenerated());
		soapModel.setIsBalanceAmount(model.getIsBalanceAmount());
		soapModel.setBillAmount(model.getBillAmount());
		soapModel.setPaidAmount(model.getPaidAmount());

		return soapModel;
	}

	public static PatientBillSoap[] toSoapModels(PatientBill[] models) {
		PatientBillSoap[] soapModels = new PatientBillSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static PatientBillSoap[][] toSoapModels(PatientBill[][] models) {
		PatientBillSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new PatientBillSoap[models.length][models[0].length];
		}
		else {
			soapModels = new PatientBillSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static PatientBillSoap[] toSoapModels(List<PatientBill> models) {
		List<PatientBillSoap> soapModels = new ArrayList<PatientBillSoap>(models.size());

		for (PatientBill model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new PatientBillSoap[soapModels.size()]);
	}

	public PatientBillSoap() {
	}

	public long getPrimaryKey() {
		return _patientBillId;
	}

	public void setPrimaryKey(long pk) {
		setPatientBillId(pk);
	}

	public long getPatientBillId() {
		return _patientBillId;
	}

	public void setPatientBillId(long patientBillId) {
		_patientBillId = patientBillId;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public String getIpNumber() {
		return _ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;
	}

	public String getBillNumber() {
		return _billNumber;
	}

	public void setBillNumber(String billNumber) {
		_billNumber = billNumber;
	}

	public String getCompany() {
		return _company;
	}

	public void setCompany(String company) {
		_company = company;
	}

	public String getSponser() {
		return _sponser;
	}

	public void setSponser(String sponser) {
		_sponser = sponser;
	}

	public String getPlanName() {
		return _planName;
	}

	public void setPlanName(String planName) {
		_planName = planName;
	}

	public Date getPlanExpiry() {
		return _planExpiry;
	}

	public void setPlanExpiry(Date planExpiry) {
		_planExpiry = planExpiry;
	}

	public Date getAdmissionDate() {
		return _admissionDate;
	}

	public void setAdmissionDate(Date admissionDate) {
		_admissionDate = admissionDate;
	}

	public boolean getIsBillgenerated() {
		return _isBillgenerated;
	}

	public boolean isIsBillgenerated() {
		return _isBillgenerated;
	}

	public void setIsBillgenerated(boolean isBillgenerated) {
		_isBillgenerated = isBillgenerated;
	}

	public boolean getIsBalanceAmount() {
		return _isBalanceAmount;
	}

	public boolean isIsBalanceAmount() {
		return _isBalanceAmount;
	}

	public void setIsBalanceAmount(boolean isBalanceAmount) {
		_isBalanceAmount = isBalanceAmount;
	}

	public double getBillAmount() {
		return _billAmount;
	}

	public void setBillAmount(double billAmount) {
		_billAmount = billAmount;
	}

	public double getPaidAmount() {
		return _paidAmount;
	}

	public void setPaidAmount(double paidAmount) {
		_paidAmount = paidAmount;
	}

	private long _patientBillId;
	private String _mrNumber;
	private String _ipNumber;
	private String _billNumber;
	private String _company;
	private String _sponser;
	private String _planName;
	private Date _planExpiry;
	private Date _admissionDate;
	private boolean _isBillgenerated;
	private boolean _isBalanceAmount;
	private double _billAmount;
	private double _paidAmount;
}