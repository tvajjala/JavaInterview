/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import com.napier.portal.db.service.BedAllocationLocalServiceUtil;
import com.napier.portal.db.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class BedAllocationClp extends BaseModelImpl<BedAllocation>
	implements BedAllocation {
	public BedAllocationClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return BedAllocation.class;
	}

	@Override
	public String getModelClassName() {
		return BedAllocation.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _bedAllocationId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setBedAllocationId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _bedAllocationId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("bedAllocationId", getBedAllocationId());
		attributes.put("bedReservationNumber", getBedReservationNumber());
		attributes.put("bedReservationDate", getBedReservationDate());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("bedNumber", getBedNumber());
		attributes.put("joiningDate", getJoiningDate());
		attributes.put("admissionDate", getAdmissionDate());
		attributes.put("patientName", getPatientName());
		attributes.put("age", getAge());
		attributes.put("gender", getGender());
		attributes.put("mobile", getMobile());
		attributes.put("email", getEmail());
		attributes.put("status", getStatus());
		attributes.put("createdUserId", getCreatedUserId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long bedAllocationId = (Long)attributes.get("bedAllocationId");

		if (bedAllocationId != null) {
			setBedAllocationId(bedAllocationId);
		}

		String bedReservationNumber = (String)attributes.get(
				"bedReservationNumber");

		if (bedReservationNumber != null) {
			setBedReservationNumber(bedReservationNumber);
		}

		Date bedReservationDate = (Date)attributes.get("bedReservationDate");

		if (bedReservationDate != null) {
			setBedReservationDate(bedReservationDate);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String bedNumber = (String)attributes.get("bedNumber");

		if (bedNumber != null) {
			setBedNumber(bedNumber);
		}

		Date joiningDate = (Date)attributes.get("joiningDate");

		if (joiningDate != null) {
			setJoiningDate(joiningDate);
		}

		Date admissionDate = (Date)attributes.get("admissionDate");

		if (admissionDate != null) {
			setAdmissionDate(admissionDate);
		}

		String patientName = (String)attributes.get("patientName");

		if (patientName != null) {
			setPatientName(patientName);
		}

		Integer age = (Integer)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String mobile = (String)attributes.get("mobile");

		if (mobile != null) {
			setMobile(mobile);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Long createdUserId = (Long)attributes.get("createdUserId");

		if (createdUserId != null) {
			setCreatedUserId(createdUserId);
		}
	}

	@Override
	public long getBedAllocationId() {
		return _bedAllocationId;
	}

	@Override
	public void setBedAllocationId(long bedAllocationId) {
		_bedAllocationId = bedAllocationId;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setBedAllocationId", long.class);

				method.invoke(_bedAllocationRemoteModel, bedAllocationId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getBedReservationNumber() {
		return _bedReservationNumber;
	}

	@Override
	public void setBedReservationNumber(String bedReservationNumber) {
		_bedReservationNumber = bedReservationNumber;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setBedReservationNumber",
						String.class);

				method.invoke(_bedAllocationRemoteModel, bedReservationNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getBedReservationDate() {
		return _bedReservationDate;
	}

	@Override
	public void setBedReservationDate(Date bedReservationDate) {
		_bedReservationDate = bedReservationDate;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setBedReservationDate",
						Date.class);

				method.invoke(_bedAllocationRemoteModel, bedReservationDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_bedAllocationRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getIpNumber() {
		return _ipNumber;
	}

	@Override
	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setIpNumber", String.class);

				method.invoke(_bedAllocationRemoteModel, ipNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getBedNumber() {
		return _bedNumber;
	}

	@Override
	public void setBedNumber(String bedNumber) {
		_bedNumber = bedNumber;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setBedNumber", String.class);

				method.invoke(_bedAllocationRemoteModel, bedNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getJoiningDate() {
		return _joiningDate;
	}

	@Override
	public void setJoiningDate(Date joiningDate) {
		_joiningDate = joiningDate;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setJoiningDate", Date.class);

				method.invoke(_bedAllocationRemoteModel, joiningDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getAdmissionDate() {
		return _admissionDate;
	}

	@Override
	public void setAdmissionDate(Date admissionDate) {
		_admissionDate = admissionDate;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setAdmissionDate", Date.class);

				method.invoke(_bedAllocationRemoteModel, admissionDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPatientName() {
		return _patientName;
	}

	@Override
	public void setPatientName(String patientName) {
		_patientName = patientName;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setPatientName", String.class);

				method.invoke(_bedAllocationRemoteModel, patientName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getAge() {
		return _age;
	}

	@Override
	public void setAge(int age) {
		_age = age;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setAge", int.class);

				method.invoke(_bedAllocationRemoteModel, age);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getGender() {
		return _gender;
	}

	@Override
	public void setGender(String gender) {
		_gender = gender;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setGender", String.class);

				method.invoke(_bedAllocationRemoteModel, gender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMobile() {
		return _mobile;
	}

	@Override
	public void setMobile(String mobile) {
		_mobile = mobile;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setMobile", String.class);

				method.invoke(_bedAllocationRemoteModel, mobile);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmail() {
		return _email;
	}

	@Override
	public void setEmail(String email) {
		_email = email;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setEmail", String.class);

				method.invoke(_bedAllocationRemoteModel, email);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatus() {
		return _status;
	}

	@Override
	public void setStatus(String status) {
		_status = status;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", String.class);

				method.invoke(_bedAllocationRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCreatedUserId() {
		return _createdUserId;
	}

	@Override
	public void setCreatedUserId(long createdUserId) {
		_createdUserId = createdUserId;

		if (_bedAllocationRemoteModel != null) {
			try {
				Class<?> clazz = _bedAllocationRemoteModel.getClass();

				Method method = clazz.getMethod("setCreatedUserId", long.class);

				method.invoke(_bedAllocationRemoteModel, createdUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCreatedUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getCreatedUserId(), "uuid",
			_createdUserUuid);
	}

	@Override
	public void setCreatedUserUuid(String createdUserUuid) {
		_createdUserUuid = createdUserUuid;
	}

	public BaseModel<?> getBedAllocationRemoteModel() {
		return _bedAllocationRemoteModel;
	}

	public void setBedAllocationRemoteModel(
		BaseModel<?> bedAllocationRemoteModel) {
		_bedAllocationRemoteModel = bedAllocationRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _bedAllocationRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_bedAllocationRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			BedAllocationLocalServiceUtil.addBedAllocation(this);
		}
		else {
			BedAllocationLocalServiceUtil.updateBedAllocation(this);
		}
	}

	@Override
	public BedAllocation toEscapedModel() {
		return (BedAllocation)ProxyUtil.newProxyInstance(BedAllocation.class.getClassLoader(),
			new Class[] { BedAllocation.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		BedAllocationClp clone = new BedAllocationClp();

		clone.setBedAllocationId(getBedAllocationId());
		clone.setBedReservationNumber(getBedReservationNumber());
		clone.setBedReservationDate(getBedReservationDate());
		clone.setMrNumber(getMrNumber());
		clone.setIpNumber(getIpNumber());
		clone.setBedNumber(getBedNumber());
		clone.setJoiningDate(getJoiningDate());
		clone.setAdmissionDate(getAdmissionDate());
		clone.setPatientName(getPatientName());
		clone.setAge(getAge());
		clone.setGender(getGender());
		clone.setMobile(getMobile());
		clone.setEmail(getEmail());
		clone.setStatus(getStatus());
		clone.setCreatedUserId(getCreatedUserId());

		return clone;
	}

	@Override
	public int compareTo(BedAllocation bedAllocation) {
		long primaryKey = bedAllocation.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BedAllocationClp)) {
			return false;
		}

		BedAllocationClp bedAllocation = (BedAllocationClp)obj;

		long primaryKey = bedAllocation.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{bedAllocationId=");
		sb.append(getBedAllocationId());
		sb.append(", bedReservationNumber=");
		sb.append(getBedReservationNumber());
		sb.append(", bedReservationDate=");
		sb.append(getBedReservationDate());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", ipNumber=");
		sb.append(getIpNumber());
		sb.append(", bedNumber=");
		sb.append(getBedNumber());
		sb.append(", joiningDate=");
		sb.append(getJoiningDate());
		sb.append(", admissionDate=");
		sb.append(getAdmissionDate());
		sb.append(", patientName=");
		sb.append(getPatientName());
		sb.append(", age=");
		sb.append(getAge());
		sb.append(", gender=");
		sb.append(getGender());
		sb.append(", mobile=");
		sb.append(getMobile());
		sb.append(", email=");
		sb.append(getEmail());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", createdUserId=");
		sb.append(getCreatedUserId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(49);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.BedAllocation");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>bedAllocationId</column-name><column-value><![CDATA[");
		sb.append(getBedAllocationId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bedReservationNumber</column-name><column-value><![CDATA[");
		sb.append(getBedReservationNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bedReservationDate</column-name><column-value><![CDATA[");
		sb.append(getBedReservationDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ipNumber</column-name><column-value><![CDATA[");
		sb.append(getIpNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bedNumber</column-name><column-value><![CDATA[");
		sb.append(getBedNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>joiningDate</column-name><column-value><![CDATA[");
		sb.append(getJoiningDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>admissionDate</column-name><column-value><![CDATA[");
		sb.append(getAdmissionDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>patientName</column-name><column-value><![CDATA[");
		sb.append(getPatientName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>age</column-name><column-value><![CDATA[");
		sb.append(getAge());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>gender</column-name><column-value><![CDATA[");
		sb.append(getGender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mobile</column-name><column-value><![CDATA[");
		sb.append(getMobile());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>email</column-name><column-value><![CDATA[");
		sb.append(getEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createdUserId</column-name><column-value><![CDATA[");
		sb.append(getCreatedUserId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _bedAllocationId;
	private String _bedReservationNumber;
	private Date _bedReservationDate;
	private String _mrNumber;
	private String _ipNumber;
	private String _bedNumber;
	private Date _joiningDate;
	private Date _admissionDate;
	private String _patientName;
	private int _age;
	private String _gender;
	private String _mobile;
	private String _email;
	private String _status;
	private long _createdUserId;
	private String _createdUserUuid;
	private BaseModel<?> _bedAllocationRemoteModel;
}