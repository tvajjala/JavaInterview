/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.DoctorAppointmentLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class DoctorAppointmentClp extends BaseModelImpl<DoctorAppointment>
	implements DoctorAppointment {
	public DoctorAppointmentClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return DoctorAppointment.class;
	}

	@Override
	public String getModelClassName() {
		return DoctorAppointment.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _appointmentId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setAppointmentId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _appointmentId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("appointmentId", getAppointmentId());
		attributes.put("appointmentNumber", getAppointmentNumber());
		attributes.put("appointmentDate", getAppointmentDate());
		attributes.put("doctorName", getDoctorName());
		attributes.put("specialization", getSpecialization());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("creationDate", getCreationDate());
		attributes.put("fromTime", getFromTime());
		attributes.put("toTime", getToTime());
		attributes.put("status", getStatus());
		attributes.put("patientName", getPatientName());
		attributes.put("age", getAge());
		attributes.put("gender", getGender());
		attributes.put("mobile", getMobile());
		attributes.put("email", getEmail());
		attributes.put("complaint", getComplaint());
		attributes.put("createdByUserId", getCreatedByUserId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long appointmentId = (Long)attributes.get("appointmentId");

		if (appointmentId != null) {
			setAppointmentId(appointmentId);
		}

		String appointmentNumber = (String)attributes.get("appointmentNumber");

		if (appointmentNumber != null) {
			setAppointmentNumber(appointmentNumber);
		}

		Date appointmentDate = (Date)attributes.get("appointmentDate");

		if (appointmentDate != null) {
			setAppointmentDate(appointmentDate);
		}

		String doctorName = (String)attributes.get("doctorName");

		if (doctorName != null) {
			setDoctorName(doctorName);
		}

		String specialization = (String)attributes.get("specialization");

		if (specialization != null) {
			setSpecialization(specialization);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		Date creationDate = (Date)attributes.get("creationDate");

		if (creationDate != null) {
			setCreationDate(creationDate);
		}

		String fromTime = (String)attributes.get("fromTime");

		if (fromTime != null) {
			setFromTime(fromTime);
		}

		String toTime = (String)attributes.get("toTime");

		if (toTime != null) {
			setToTime(toTime);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String patientName = (String)attributes.get("patientName");

		if (patientName != null) {
			setPatientName(patientName);
		}

		Integer age = (Integer)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String mobile = (String)attributes.get("mobile");

		if (mobile != null) {
			setMobile(mobile);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String complaint = (String)attributes.get("complaint");

		if (complaint != null) {
			setComplaint(complaint);
		}

		Long createdByUserId = (Long)attributes.get("createdByUserId");

		if (createdByUserId != null) {
			setCreatedByUserId(createdByUserId);
		}
	}

	@Override
	public long getAppointmentId() {
		return _appointmentId;
	}

	@Override
	public void setAppointmentId(long appointmentId) {
		_appointmentId = appointmentId;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAppointmentId", long.class);

				method.invoke(_doctorAppointmentRemoteModel, appointmentId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAppointmentNumber() {
		return _appointmentNumber;
	}

	@Override
	public void setAppointmentNumber(String appointmentNumber) {
		_appointmentNumber = appointmentNumber;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAppointmentNumber",
						String.class);

				method.invoke(_doctorAppointmentRemoteModel, appointmentNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getAppointmentDate() {
		return _appointmentDate;
	}

	@Override
	public void setAppointmentDate(Date appointmentDate) {
		_appointmentDate = appointmentDate;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAppointmentDate", Date.class);

				method.invoke(_doctorAppointmentRemoteModel, appointmentDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDoctorName() {
		return _doctorName;
	}

	@Override
	public void setDoctorName(String doctorName) {
		_doctorName = doctorName;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setDoctorName", String.class);

				method.invoke(_doctorAppointmentRemoteModel, doctorName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSpecialization() {
		return _specialization;
	}

	@Override
	public void setSpecialization(String specialization) {
		_specialization = specialization;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setSpecialization",
						String.class);

				method.invoke(_doctorAppointmentRemoteModel, specialization);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_doctorAppointmentRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreationDate() {
		return _creationDate;
	}

	@Override
	public void setCreationDate(Date creationDate) {
		_creationDate = creationDate;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setCreationDate", Date.class);

				method.invoke(_doctorAppointmentRemoteModel, creationDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFromTime() {
		return _fromTime;
	}

	@Override
	public void setFromTime(String fromTime) {
		_fromTime = fromTime;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setFromTime", String.class);

				method.invoke(_doctorAppointmentRemoteModel, fromTime);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getToTime() {
		return _toTime;
	}

	@Override
	public void setToTime(String toTime) {
		_toTime = toTime;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setToTime", String.class);

				method.invoke(_doctorAppointmentRemoteModel, toTime);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatus() {
		return _status;
	}

	@Override
	public void setStatus(String status) {
		_status = status;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", String.class);

				method.invoke(_doctorAppointmentRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPatientName() {
		return _patientName;
	}

	@Override
	public void setPatientName(String patientName) {
		_patientName = patientName;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setPatientName", String.class);

				method.invoke(_doctorAppointmentRemoteModel, patientName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getAge() {
		return _age;
	}

	@Override
	public void setAge(int age) {
		_age = age;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAge", int.class);

				method.invoke(_doctorAppointmentRemoteModel, age);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getGender() {
		return _gender;
	}

	@Override
	public void setGender(String gender) {
		_gender = gender;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setGender", String.class);

				method.invoke(_doctorAppointmentRemoteModel, gender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMobile() {
		return _mobile;
	}

	@Override
	public void setMobile(String mobile) {
		_mobile = mobile;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setMobile", String.class);

				method.invoke(_doctorAppointmentRemoteModel, mobile);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmail() {
		return _email;
	}

	@Override
	public void setEmail(String email) {
		_email = email;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setEmail", String.class);

				method.invoke(_doctorAppointmentRemoteModel, email);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getComplaint() {
		return _complaint;
	}

	@Override
	public void setComplaint(String complaint) {
		_complaint = complaint;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setComplaint", String.class);

				method.invoke(_doctorAppointmentRemoteModel, complaint);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCreatedByUserId() {
		return _createdByUserId;
	}

	@Override
	public void setCreatedByUserId(long createdByUserId) {
		_createdByUserId = createdByUserId;

		if (_doctorAppointmentRemoteModel != null) {
			try {
				Class<?> clazz = _doctorAppointmentRemoteModel.getClass();

				Method method = clazz.getMethod("setCreatedByUserId", long.class);

				method.invoke(_doctorAppointmentRemoteModel, createdByUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCreatedByUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getCreatedByUserId(), "uuid",
			_createdByUserUuid);
	}

	@Override
	public void setCreatedByUserUuid(String createdByUserUuid) {
		_createdByUserUuid = createdByUserUuid;
	}

	public BaseModel<?> getDoctorAppointmentRemoteModel() {
		return _doctorAppointmentRemoteModel;
	}

	public void setDoctorAppointmentRemoteModel(
		BaseModel<?> doctorAppointmentRemoteModel) {
		_doctorAppointmentRemoteModel = doctorAppointmentRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _doctorAppointmentRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_doctorAppointmentRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DoctorAppointmentLocalServiceUtil.addDoctorAppointment(this);
		}
		else {
			DoctorAppointmentLocalServiceUtil.updateDoctorAppointment(this);
		}
	}

	@Override
	public DoctorAppointment toEscapedModel() {
		return (DoctorAppointment)ProxyUtil.newProxyInstance(DoctorAppointment.class.getClassLoader(),
			new Class[] { DoctorAppointment.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DoctorAppointmentClp clone = new DoctorAppointmentClp();

		clone.setAppointmentId(getAppointmentId());
		clone.setAppointmentNumber(getAppointmentNumber());
		clone.setAppointmentDate(getAppointmentDate());
		clone.setDoctorName(getDoctorName());
		clone.setSpecialization(getSpecialization());
		clone.setMrNumber(getMrNumber());
		clone.setCreationDate(getCreationDate());
		clone.setFromTime(getFromTime());
		clone.setToTime(getToTime());
		clone.setStatus(getStatus());
		clone.setPatientName(getPatientName());
		clone.setAge(getAge());
		clone.setGender(getGender());
		clone.setMobile(getMobile());
		clone.setEmail(getEmail());
		clone.setComplaint(getComplaint());
		clone.setCreatedByUserId(getCreatedByUserId());

		return clone;
	}

	@Override
	public int compareTo(DoctorAppointment doctorAppointment) {
		int value = 0;

		value = DateUtil.compareTo(getCreationDate(),
				doctorAppointment.getCreationDate());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DoctorAppointmentClp)) {
			return false;
		}

		DoctorAppointmentClp doctorAppointment = (DoctorAppointmentClp)obj;

		long primaryKey = doctorAppointment.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(35);

		sb.append("{appointmentId=");
		sb.append(getAppointmentId());
		sb.append(", appointmentNumber=");
		sb.append(getAppointmentNumber());
		sb.append(", appointmentDate=");
		sb.append(getAppointmentDate());
		sb.append(", doctorName=");
		sb.append(getDoctorName());
		sb.append(", specialization=");
		sb.append(getSpecialization());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", creationDate=");
		sb.append(getCreationDate());
		sb.append(", fromTime=");
		sb.append(getFromTime());
		sb.append(", toTime=");
		sb.append(getToTime());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", patientName=");
		sb.append(getPatientName());
		sb.append(", age=");
		sb.append(getAge());
		sb.append(", gender=");
		sb.append(getGender());
		sb.append(", mobile=");
		sb.append(getMobile());
		sb.append(", email=");
		sb.append(getEmail());
		sb.append(", complaint=");
		sb.append(getComplaint());
		sb.append(", createdByUserId=");
		sb.append(getCreatedByUserId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(55);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.DoctorAppointment");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>appointmentId</column-name><column-value><![CDATA[");
		sb.append(getAppointmentId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>appointmentNumber</column-name><column-value><![CDATA[");
		sb.append(getAppointmentNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>appointmentDate</column-name><column-value><![CDATA[");
		sb.append(getAppointmentDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>doctorName</column-name><column-value><![CDATA[");
		sb.append(getDoctorName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>specialization</column-name><column-value><![CDATA[");
		sb.append(getSpecialization());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>creationDate</column-name><column-value><![CDATA[");
		sb.append(getCreationDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>fromTime</column-name><column-value><![CDATA[");
		sb.append(getFromTime());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>toTime</column-name><column-value><![CDATA[");
		sb.append(getToTime());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>patientName</column-name><column-value><![CDATA[");
		sb.append(getPatientName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>age</column-name><column-value><![CDATA[");
		sb.append(getAge());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>gender</column-name><column-value><![CDATA[");
		sb.append(getGender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mobile</column-name><column-value><![CDATA[");
		sb.append(getMobile());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>email</column-name><column-value><![CDATA[");
		sb.append(getEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>complaint</column-name><column-value><![CDATA[");
		sb.append(getComplaint());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createdByUserId</column-name><column-value><![CDATA[");
		sb.append(getCreatedByUserId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _appointmentId;
	private String _appointmentNumber;
	private Date _appointmentDate;
	private String _doctorName;
	private String _specialization;
	private String _mrNumber;
	private Date _creationDate;
	private String _fromTime;
	private String _toTime;
	private String _status;
	private String _patientName;
	private int _age;
	private String _gender;
	private String _mobile;
	private String _email;
	private String _complaint;
	private long _createdByUserId;
	private String _createdByUserUuid;
	private BaseModel<?> _doctorAppointmentRemoteModel;
}