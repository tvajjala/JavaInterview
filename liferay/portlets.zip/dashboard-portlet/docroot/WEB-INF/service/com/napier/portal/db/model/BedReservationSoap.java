/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class BedReservationSoap implements Serializable {
	public static BedReservationSoap toSoapModel(BedReservation model) {
		BedReservationSoap soapModel = new BedReservationSoap();

		soapModel.setBedReservationId(model.getBedReservationId());
		soapModel.setBedClass(model.getBedClass());
		soapModel.setWard(model.getWard());
		soapModel.setTotalBedCount(model.getTotalBedCount());
		soapModel.setVacantBedCount(model.getVacantBedCount());
		soapModel.setHospitalTariff(model.getHospitalTariff());
		soapModel.setGender(model.getGender());

		return soapModel;
	}

	public static BedReservationSoap[] toSoapModels(BedReservation[] models) {
		BedReservationSoap[] soapModels = new BedReservationSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static BedReservationSoap[][] toSoapModels(BedReservation[][] models) {
		BedReservationSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new BedReservationSoap[models.length][models[0].length];
		}
		else {
			soapModels = new BedReservationSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static BedReservationSoap[] toSoapModels(List<BedReservation> models) {
		List<BedReservationSoap> soapModels = new ArrayList<BedReservationSoap>(models.size());

		for (BedReservation model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new BedReservationSoap[soapModels.size()]);
	}

	public BedReservationSoap() {
	}

	public long getPrimaryKey() {
		return _bedReservationId;
	}

	public void setPrimaryKey(long pk) {
		setBedReservationId(pk);
	}

	public long getBedReservationId() {
		return _bedReservationId;
	}

	public void setBedReservationId(long bedReservationId) {
		_bedReservationId = bedReservationId;
	}

	public String getBedClass() {
		return _bedClass;
	}

	public void setBedClass(String bedClass) {
		_bedClass = bedClass;
	}

	public String getWard() {
		return _ward;
	}

	public void setWard(String ward) {
		_ward = ward;
	}

	public int getTotalBedCount() {
		return _totalBedCount;
	}

	public void setTotalBedCount(int totalBedCount) {
		_totalBedCount = totalBedCount;
	}

	public int getVacantBedCount() {
		return _vacantBedCount;
	}

	public void setVacantBedCount(int vacantBedCount) {
		_vacantBedCount = vacantBedCount;
	}

	public double getHospitalTariff() {
		return _hospitalTariff;
	}

	public void setHospitalTariff(double hospitalTariff) {
		_hospitalTariff = hospitalTariff;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	private long _bedReservationId;
	private String _bedClass;
	private String _ward;
	private int _totalBedCount;
	private int _vacantBedCount;
	private double _hospitalTariff;
	private String _gender;
}