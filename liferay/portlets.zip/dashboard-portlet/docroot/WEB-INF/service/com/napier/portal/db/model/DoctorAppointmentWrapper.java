/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link DoctorAppointment}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DoctorAppointment
 * @generated
 */
public class DoctorAppointmentWrapper implements DoctorAppointment,
	ModelWrapper<DoctorAppointment> {
	public DoctorAppointmentWrapper(DoctorAppointment doctorAppointment) {
		_doctorAppointment = doctorAppointment;
	}

	@Override
	public Class<?> getModelClass() {
		return DoctorAppointment.class;
	}

	@Override
	public String getModelClassName() {
		return DoctorAppointment.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("appointmentId", getAppointmentId());
		attributes.put("appointmentNumber", getAppointmentNumber());
		attributes.put("appointmentDate", getAppointmentDate());
		attributes.put("doctorName", getDoctorName());
		attributes.put("specialization", getSpecialization());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("creationDate", getCreationDate());
		attributes.put("fromTime", getFromTime());
		attributes.put("toTime", getToTime());
		attributes.put("status", getStatus());
		attributes.put("patientName", getPatientName());
		attributes.put("age", getAge());
		attributes.put("gender", getGender());
		attributes.put("mobile", getMobile());
		attributes.put("email", getEmail());
		attributes.put("complaint", getComplaint());
		attributes.put("createdByUserId", getCreatedByUserId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long appointmentId = (Long)attributes.get("appointmentId");

		if (appointmentId != null) {
			setAppointmentId(appointmentId);
		}

		String appointmentNumber = (String)attributes.get("appointmentNumber");

		if (appointmentNumber != null) {
			setAppointmentNumber(appointmentNumber);
		}

		Date appointmentDate = (Date)attributes.get("appointmentDate");

		if (appointmentDate != null) {
			setAppointmentDate(appointmentDate);
		}

		String doctorName = (String)attributes.get("doctorName");

		if (doctorName != null) {
			setDoctorName(doctorName);
		}

		String specialization = (String)attributes.get("specialization");

		if (specialization != null) {
			setSpecialization(specialization);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		Date creationDate = (Date)attributes.get("creationDate");

		if (creationDate != null) {
			setCreationDate(creationDate);
		}

		String fromTime = (String)attributes.get("fromTime");

		if (fromTime != null) {
			setFromTime(fromTime);
		}

		String toTime = (String)attributes.get("toTime");

		if (toTime != null) {
			setToTime(toTime);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String patientName = (String)attributes.get("patientName");

		if (patientName != null) {
			setPatientName(patientName);
		}

		Integer age = (Integer)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String mobile = (String)attributes.get("mobile");

		if (mobile != null) {
			setMobile(mobile);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String complaint = (String)attributes.get("complaint");

		if (complaint != null) {
			setComplaint(complaint);
		}

		Long createdByUserId = (Long)attributes.get("createdByUserId");

		if (createdByUserId != null) {
			setCreatedByUserId(createdByUserId);
		}
	}

	/**
	* Returns the primary key of this doctor appointment.
	*
	* @return the primary key of this doctor appointment
	*/
	@Override
	public long getPrimaryKey() {
		return _doctorAppointment.getPrimaryKey();
	}

	/**
	* Sets the primary key of this doctor appointment.
	*
	* @param primaryKey the primary key of this doctor appointment
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_doctorAppointment.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the appointment ID of this doctor appointment.
	*
	* @return the appointment ID of this doctor appointment
	*/
	@Override
	public long getAppointmentId() {
		return _doctorAppointment.getAppointmentId();
	}

	/**
	* Sets the appointment ID of this doctor appointment.
	*
	* @param appointmentId the appointment ID of this doctor appointment
	*/
	@Override
	public void setAppointmentId(long appointmentId) {
		_doctorAppointment.setAppointmentId(appointmentId);
	}

	/**
	* Returns the appointment number of this doctor appointment.
	*
	* @return the appointment number of this doctor appointment
	*/
	@Override
	public java.lang.String getAppointmentNumber() {
		return _doctorAppointment.getAppointmentNumber();
	}

	/**
	* Sets the appointment number of this doctor appointment.
	*
	* @param appointmentNumber the appointment number of this doctor appointment
	*/
	@Override
	public void setAppointmentNumber(java.lang.String appointmentNumber) {
		_doctorAppointment.setAppointmentNumber(appointmentNumber);
	}

	/**
	* Returns the appointment date of this doctor appointment.
	*
	* @return the appointment date of this doctor appointment
	*/
	@Override
	public java.util.Date getAppointmentDate() {
		return _doctorAppointment.getAppointmentDate();
	}

	/**
	* Sets the appointment date of this doctor appointment.
	*
	* @param appointmentDate the appointment date of this doctor appointment
	*/
	@Override
	public void setAppointmentDate(java.util.Date appointmentDate) {
		_doctorAppointment.setAppointmentDate(appointmentDate);
	}

	/**
	* Returns the doctor name of this doctor appointment.
	*
	* @return the doctor name of this doctor appointment
	*/
	@Override
	public java.lang.String getDoctorName() {
		return _doctorAppointment.getDoctorName();
	}

	/**
	* Sets the doctor name of this doctor appointment.
	*
	* @param doctorName the doctor name of this doctor appointment
	*/
	@Override
	public void setDoctorName(java.lang.String doctorName) {
		_doctorAppointment.setDoctorName(doctorName);
	}

	/**
	* Returns the specialization of this doctor appointment.
	*
	* @return the specialization of this doctor appointment
	*/
	@Override
	public java.lang.String getSpecialization() {
		return _doctorAppointment.getSpecialization();
	}

	/**
	* Sets the specialization of this doctor appointment.
	*
	* @param specialization the specialization of this doctor appointment
	*/
	@Override
	public void setSpecialization(java.lang.String specialization) {
		_doctorAppointment.setSpecialization(specialization);
	}

	/**
	* Returns the mr number of this doctor appointment.
	*
	* @return the mr number of this doctor appointment
	*/
	@Override
	public java.lang.String getMrNumber() {
		return _doctorAppointment.getMrNumber();
	}

	/**
	* Sets the mr number of this doctor appointment.
	*
	* @param mrNumber the mr number of this doctor appointment
	*/
	@Override
	public void setMrNumber(java.lang.String mrNumber) {
		_doctorAppointment.setMrNumber(mrNumber);
	}

	/**
	* Returns the creation date of this doctor appointment.
	*
	* @return the creation date of this doctor appointment
	*/
	@Override
	public java.util.Date getCreationDate() {
		return _doctorAppointment.getCreationDate();
	}

	/**
	* Sets the creation date of this doctor appointment.
	*
	* @param creationDate the creation date of this doctor appointment
	*/
	@Override
	public void setCreationDate(java.util.Date creationDate) {
		_doctorAppointment.setCreationDate(creationDate);
	}

	/**
	* Returns the from time of this doctor appointment.
	*
	* @return the from time of this doctor appointment
	*/
	@Override
	public java.lang.String getFromTime() {
		return _doctorAppointment.getFromTime();
	}

	/**
	* Sets the from time of this doctor appointment.
	*
	* @param fromTime the from time of this doctor appointment
	*/
	@Override
	public void setFromTime(java.lang.String fromTime) {
		_doctorAppointment.setFromTime(fromTime);
	}

	/**
	* Returns the to time of this doctor appointment.
	*
	* @return the to time of this doctor appointment
	*/
	@Override
	public java.lang.String getToTime() {
		return _doctorAppointment.getToTime();
	}

	/**
	* Sets the to time of this doctor appointment.
	*
	* @param toTime the to time of this doctor appointment
	*/
	@Override
	public void setToTime(java.lang.String toTime) {
		_doctorAppointment.setToTime(toTime);
	}

	/**
	* Returns the status of this doctor appointment.
	*
	* @return the status of this doctor appointment
	*/
	@Override
	public java.lang.String getStatus() {
		return _doctorAppointment.getStatus();
	}

	/**
	* Sets the status of this doctor appointment.
	*
	* @param status the status of this doctor appointment
	*/
	@Override
	public void setStatus(java.lang.String status) {
		_doctorAppointment.setStatus(status);
	}

	/**
	* Returns the patient name of this doctor appointment.
	*
	* @return the patient name of this doctor appointment
	*/
	@Override
	public java.lang.String getPatientName() {
		return _doctorAppointment.getPatientName();
	}

	/**
	* Sets the patient name of this doctor appointment.
	*
	* @param patientName the patient name of this doctor appointment
	*/
	@Override
	public void setPatientName(java.lang.String patientName) {
		_doctorAppointment.setPatientName(patientName);
	}

	/**
	* Returns the age of this doctor appointment.
	*
	* @return the age of this doctor appointment
	*/
	@Override
	public int getAge() {
		return _doctorAppointment.getAge();
	}

	/**
	* Sets the age of this doctor appointment.
	*
	* @param age the age of this doctor appointment
	*/
	@Override
	public void setAge(int age) {
		_doctorAppointment.setAge(age);
	}

	/**
	* Returns the gender of this doctor appointment.
	*
	* @return the gender of this doctor appointment
	*/
	@Override
	public java.lang.String getGender() {
		return _doctorAppointment.getGender();
	}

	/**
	* Sets the gender of this doctor appointment.
	*
	* @param gender the gender of this doctor appointment
	*/
	@Override
	public void setGender(java.lang.String gender) {
		_doctorAppointment.setGender(gender);
	}

	/**
	* Returns the mobile of this doctor appointment.
	*
	* @return the mobile of this doctor appointment
	*/
	@Override
	public java.lang.String getMobile() {
		return _doctorAppointment.getMobile();
	}

	/**
	* Sets the mobile of this doctor appointment.
	*
	* @param mobile the mobile of this doctor appointment
	*/
	@Override
	public void setMobile(java.lang.String mobile) {
		_doctorAppointment.setMobile(mobile);
	}

	/**
	* Returns the email of this doctor appointment.
	*
	* @return the email of this doctor appointment
	*/
	@Override
	public java.lang.String getEmail() {
		return _doctorAppointment.getEmail();
	}

	/**
	* Sets the email of this doctor appointment.
	*
	* @param email the email of this doctor appointment
	*/
	@Override
	public void setEmail(java.lang.String email) {
		_doctorAppointment.setEmail(email);
	}

	/**
	* Returns the complaint of this doctor appointment.
	*
	* @return the complaint of this doctor appointment
	*/
	@Override
	public java.lang.String getComplaint() {
		return _doctorAppointment.getComplaint();
	}

	/**
	* Sets the complaint of this doctor appointment.
	*
	* @param complaint the complaint of this doctor appointment
	*/
	@Override
	public void setComplaint(java.lang.String complaint) {
		_doctorAppointment.setComplaint(complaint);
	}

	/**
	* Returns the created by user ID of this doctor appointment.
	*
	* @return the created by user ID of this doctor appointment
	*/
	@Override
	public long getCreatedByUserId() {
		return _doctorAppointment.getCreatedByUserId();
	}

	/**
	* Sets the created by user ID of this doctor appointment.
	*
	* @param createdByUserId the created by user ID of this doctor appointment
	*/
	@Override
	public void setCreatedByUserId(long createdByUserId) {
		_doctorAppointment.setCreatedByUserId(createdByUserId);
	}

	/**
	* Returns the created by user uuid of this doctor appointment.
	*
	* @return the created by user uuid of this doctor appointment
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getCreatedByUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _doctorAppointment.getCreatedByUserUuid();
	}

	/**
	* Sets the created by user uuid of this doctor appointment.
	*
	* @param createdByUserUuid the created by user uuid of this doctor appointment
	*/
	@Override
	public void setCreatedByUserUuid(java.lang.String createdByUserUuid) {
		_doctorAppointment.setCreatedByUserUuid(createdByUserUuid);
	}

	@Override
	public boolean isNew() {
		return _doctorAppointment.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_doctorAppointment.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _doctorAppointment.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_doctorAppointment.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _doctorAppointment.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _doctorAppointment.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_doctorAppointment.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _doctorAppointment.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_doctorAppointment.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_doctorAppointment.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_doctorAppointment.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DoctorAppointmentWrapper((DoctorAppointment)_doctorAppointment.clone());
	}

	@Override
	public int compareTo(
		com.napier.portal.db.model.DoctorAppointment doctorAppointment) {
		return _doctorAppointment.compareTo(doctorAppointment);
	}

	@Override
	public int hashCode() {
		return _doctorAppointment.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.DoctorAppointment> toCacheModel() {
		return _doctorAppointment.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.DoctorAppointment toEscapedModel() {
		return new DoctorAppointmentWrapper(_doctorAppointment.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.DoctorAppointment toUnescapedModel() {
		return new DoctorAppointmentWrapper(_doctorAppointment.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _doctorAppointment.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _doctorAppointment.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_doctorAppointment.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DoctorAppointmentWrapper)) {
			return false;
		}

		DoctorAppointmentWrapper doctorAppointmentWrapper = (DoctorAppointmentWrapper)obj;

		if (Validator.equals(_doctorAppointment,
					doctorAppointmentWrapper._doctorAppointment)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public DoctorAppointment getWrappedDoctorAppointment() {
		return _doctorAppointment;
	}

	@Override
	public DoctorAppointment getWrappedModel() {
		return _doctorAppointment;
	}

	@Override
	public void resetOriginalValues() {
		_doctorAppointment.resetOriginalValues();
	}

	private DoctorAppointment _doctorAppointment;
}