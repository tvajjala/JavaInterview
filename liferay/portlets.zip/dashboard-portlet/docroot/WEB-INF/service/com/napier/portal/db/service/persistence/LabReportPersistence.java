/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.napier.portal.db.model.LabReport;

/**
 * The persistence interface for the lab report service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see LabReportPersistenceImpl
 * @see LabReportUtil
 * @generated
 */
public interface LabReportPersistence extends BasePersistence<LabReport> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link LabReportUtil} to access the lab report persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the lab reports where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the lab reports where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the lab reports where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the first lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the last lab report in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where mrNumber = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport[] findBymrNumber_PrevAndNext(
		long labId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Removes all the lab reports where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of lab reports where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the lab reports where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the lab reports where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the lab reports where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the first lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the last lab report in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where ipNumber = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport[] findByipNumber_PrevAndNext(
		long labId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Removes all the lab reports where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of lab reports where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the lab reports where testName = &#63;.
	*
	* @param testName the test name
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBytestName(
		java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the lab reports where testName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param testName the test name
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBytestName(
		java.lang.String testName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the lab reports where testName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param testName the test name
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBytestName(
		java.lang.String testName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findBytestName_First(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the first lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchBytestName_First(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findBytestName_Last(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the last lab report in the ordered set where testName = &#63;.
	*
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchBytestName_Last(
		java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where testName = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param testName the test name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport[] findBytestName_PrevAndNext(
		long labId, java.lang.String testName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Removes all the lab reports where testName = &#63; from the database.
	*
	* @param testName the test name
	* @throws SystemException if a system exception occurred
	*/
	public void removeBytestName(java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of lab reports where testName = &#63;.
	*
	* @param testName the test name
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public int countBytestName(java.lang.String testName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the lab reports where status = &#63;.
	*
	* @param status the status
	* @return the matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBystatus(
		boolean status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the lab reports where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBystatus(
		boolean status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the lab reports where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findBystatus(
		boolean status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findBystatus_First(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the first lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchBystatus_First(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findBystatus_Last(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the last lab report in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lab report, or <code>null</code> if a matching lab report could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchBystatus_Last(
		boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the lab reports before and after the current lab report in the ordered set where status = &#63;.
	*
	* @param labId the primary key of the current lab report
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport[] findBystatus_PrevAndNext(
		long labId, boolean status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Removes all the lab reports where status = &#63; from the database.
	*
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public void removeBystatus(boolean status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of lab reports where status = &#63;.
	*
	* @param status the status
	* @return the number of matching lab reports
	* @throws SystemException if a system exception occurred
	*/
	public int countBystatus(boolean status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the lab report in the entity cache if it is enabled.
	*
	* @param labReport the lab report
	*/
	public void cacheResult(com.napier.portal.db.model.LabReport labReport);

	/**
	* Caches the lab reports in the entity cache if it is enabled.
	*
	* @param labReports the lab reports
	*/
	public void cacheResult(
		java.util.List<com.napier.portal.db.model.LabReport> labReports);

	/**
	* Creates a new lab report with the primary key. Does not add the lab report to the database.
	*
	* @param labId the primary key for the new lab report
	* @return the new lab report
	*/
	public com.napier.portal.db.model.LabReport create(long labId);

	/**
	* Removes the lab report with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param labId the primary key of the lab report
	* @return the lab report that was removed
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport remove(long labId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	public com.napier.portal.db.model.LabReport updateImpl(
		com.napier.portal.db.model.LabReport labReport)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the lab report with the primary key or throws a {@link com.napier.portal.db.NoSuchLabReportException} if it could not be found.
	*
	* @param labId the primary key of the lab report
	* @return the lab report
	* @throws com.napier.portal.db.NoSuchLabReportException if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport findByPrimaryKey(long labId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchLabReportException;

	/**
	* Returns the lab report with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param labId the primary key of the lab report
	* @return the lab report, or <code>null</code> if a lab report with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.LabReport fetchByPrimaryKey(long labId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the lab reports.
	*
	* @return the lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the lab reports.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @return the range of lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the lab reports.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.LabReportModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of lab reports
	* @param end the upper bound of the range of lab reports (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of lab reports
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.LabReport> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the lab reports from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of lab reports.
	*
	* @return the number of lab reports
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}