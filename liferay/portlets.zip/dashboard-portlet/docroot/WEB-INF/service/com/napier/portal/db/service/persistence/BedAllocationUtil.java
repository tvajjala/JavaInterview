/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.napier.portal.db.model.BedAllocation;

import java.util.List;

/**
 * The persistence utility for the bed allocation service. This utility wraps {@link BedAllocationPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see BedAllocationPersistence
 * @see BedAllocationPersistenceImpl
 * @generated
 */
public class BedAllocationUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(BedAllocation bedAllocation) {
		getPersistence().clearCache(bedAllocation);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<BedAllocation> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<BedAllocation> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<BedAllocation> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static BedAllocation update(BedAllocation bedAllocation)
		throws SystemException {
		return getPersistence().update(bedAllocation);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static BedAllocation update(BedAllocation bedAllocation,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(bedAllocation, serviceContext);
	}

	/**
	* Returns all the bed allocations where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber);
	}

	/**
	* Returns a range of all the bed allocations where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @return the range of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBymrNumber(mrNumber, start, end);
	}

	/**
	* Returns an ordered range of all the bed allocations where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBymrNumber(mrNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first bed allocation in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence().findBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the first bed allocation in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBymrNumber_First(mrNumber, orderByComparator);
	}

	/**
	* Returns the last bed allocation in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence().findBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the last bed allocation in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBymrNumber_Last(mrNumber, orderByComparator);
	}

	/**
	* Returns the bed allocations before and after the current bed allocation in the ordered set where mrNumber = &#63;.
	*
	* @param bedAllocationId the primary key of the current bed allocation
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation[] findBymrNumber_PrevAndNext(
		long bedAllocationId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence()
				   .findBymrNumber_PrevAndNext(bedAllocationId, mrNumber,
			orderByComparator);
	}

	/**
	* Removes all the bed allocations where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBymrNumber(mrNumber);
	}

	/**
	* Returns the number of bed allocations where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBymrNumber(mrNumber);
	}

	/**
	* Returns all the bed allocations where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber);
	}

	/**
	* Returns a range of all the bed allocations where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @return the range of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByipNumber(ipNumber, start, end);
	}

	/**
	* Returns an ordered range of all the bed allocations where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByipNumber(ipNumber, start, end, orderByComparator);
	}

	/**
	* Returns the first bed allocation in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence().findByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the first bed allocation in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByipNumber_First(ipNumber, orderByComparator);
	}

	/**
	* Returns the last bed allocation in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence().findByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the last bed allocation in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByipNumber_Last(ipNumber, orderByComparator);
	}

	/**
	* Returns the bed allocations before and after the current bed allocation in the ordered set where ipNumber = &#63;.
	*
	* @param bedAllocationId the primary key of the current bed allocation
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation[] findByipNumber_PrevAndNext(
		long bedAllocationId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence()
				   .findByipNumber_PrevAndNext(bedAllocationId, ipNumber,
			orderByComparator);
	}

	/**
	* Removes all the bed allocations where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByipNumber(ipNumber);
	}

	/**
	* Returns the number of bed allocations where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByipNumber(ipNumber);
	}

	/**
	* Returns all the bed allocations where createdUserId = &#63;.
	*
	* @param createdUserId the created user ID
	* @return the matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findByuserId(
		long createdUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserId(createdUserId);
	}

	/**
	* Returns a range of all the bed allocations where createdUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdUserId the created user ID
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @return the range of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findByuserId(
		long createdUserId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserId(createdUserId, start, end);
	}

	/**
	* Returns an ordered range of all the bed allocations where createdUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdUserId the created user ID
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findByuserId(
		long createdUserId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserId(createdUserId, start, end, orderByComparator);
	}

	/**
	* Returns the first bed allocation in the ordered set where createdUserId = &#63;.
	*
	* @param createdUserId the created user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation findByuserId_First(
		long createdUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence()
				   .findByuserId_First(createdUserId, orderByComparator);
	}

	/**
	* Returns the first bed allocation in the ordered set where createdUserId = &#63;.
	*
	* @param createdUserId the created user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation fetchByuserId_First(
		long createdUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserId_First(createdUserId, orderByComparator);
	}

	/**
	* Returns the last bed allocation in the ordered set where createdUserId = &#63;.
	*
	* @param createdUserId the created user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation findByuserId_Last(
		long createdUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence()
				   .findByuserId_Last(createdUserId, orderByComparator);
	}

	/**
	* Returns the last bed allocation in the ordered set where createdUserId = &#63;.
	*
	* @param createdUserId the created user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed allocation, or <code>null</code> if a matching bed allocation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation fetchByuserId_Last(
		long createdUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserId_Last(createdUserId, orderByComparator);
	}

	/**
	* Returns the bed allocations before and after the current bed allocation in the ordered set where createdUserId = &#63;.
	*
	* @param bedAllocationId the primary key of the current bed allocation
	* @param createdUserId the created user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation[] findByuserId_PrevAndNext(
		long bedAllocationId, long createdUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence()
				   .findByuserId_PrevAndNext(bedAllocationId, createdUserId,
			orderByComparator);
	}

	/**
	* Removes all the bed allocations where createdUserId = &#63; from the database.
	*
	* @param createdUserId the created user ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserId(long createdUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserId(createdUserId);
	}

	/**
	* Returns the number of bed allocations where createdUserId = &#63;.
	*
	* @param createdUserId the created user ID
	* @return the number of matching bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserId(long createdUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserId(createdUserId);
	}

	/**
	* Caches the bed allocation in the entity cache if it is enabled.
	*
	* @param bedAllocation the bed allocation
	*/
	public static void cacheResult(
		com.napier.portal.db.model.BedAllocation bedAllocation) {
		getPersistence().cacheResult(bedAllocation);
	}

	/**
	* Caches the bed allocations in the entity cache if it is enabled.
	*
	* @param bedAllocations the bed allocations
	*/
	public static void cacheResult(
		java.util.List<com.napier.portal.db.model.BedAllocation> bedAllocations) {
		getPersistence().cacheResult(bedAllocations);
	}

	/**
	* Creates a new bed allocation with the primary key. Does not add the bed allocation to the database.
	*
	* @param bedAllocationId the primary key for the new bed allocation
	* @return the new bed allocation
	*/
	public static com.napier.portal.db.model.BedAllocation create(
		long bedAllocationId) {
		return getPersistence().create(bedAllocationId);
	}

	/**
	* Removes the bed allocation with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param bedAllocationId the primary key of the bed allocation
	* @return the bed allocation that was removed
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation remove(
		long bedAllocationId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence().remove(bedAllocationId);
	}

	public static com.napier.portal.db.model.BedAllocation updateImpl(
		com.napier.portal.db.model.BedAllocation bedAllocation)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(bedAllocation);
	}

	/**
	* Returns the bed allocation with the primary key or throws a {@link com.napier.portal.db.NoSuchBedAllocationException} if it could not be found.
	*
	* @param bedAllocationId the primary key of the bed allocation
	* @return the bed allocation
	* @throws com.napier.portal.db.NoSuchBedAllocationException if a bed allocation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation findByPrimaryKey(
		long bedAllocationId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedAllocationException {
		return getPersistence().findByPrimaryKey(bedAllocationId);
	}

	/**
	* Returns the bed allocation with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param bedAllocationId the primary key of the bed allocation
	* @return the bed allocation, or <code>null</code> if a bed allocation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.BedAllocation fetchByPrimaryKey(
		long bedAllocationId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(bedAllocationId);
	}

	/**
	* Returns all the bed allocations.
	*
	* @return the bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the bed allocations.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @return the range of bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the bed allocations.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedAllocationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bed allocations
	* @param end the upper bound of the range of bed allocations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.BedAllocation> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the bed allocations from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of bed allocations.
	*
	* @return the number of bed allocations
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static BedAllocationPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (BedAllocationPersistence)PortletBeanLocatorUtil.locate(com.napier.portal.db.service.ClpSerializer.getServletContextName(),
					BedAllocationPersistence.class.getName());

			ReferenceRegistry.registerReference(BedAllocationUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(BedAllocationPersistence persistence) {
	}

	private static BedAllocationPersistence _persistence;
}