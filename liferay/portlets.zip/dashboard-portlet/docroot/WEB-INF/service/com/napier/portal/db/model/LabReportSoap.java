/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class LabReportSoap implements Serializable {
	public static LabReportSoap toSoapModel(LabReport model) {
		LabReportSoap soapModel = new LabReportSoap();

		soapModel.setLabId(model.getLabId());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setOrderNumber(model.getOrderNumber());
		soapModel.setOrderDate(model.getOrderDate());
		soapModel.setReportedOn(model.getReportedOn());
		soapModel.setTestName(model.getTestName());
		soapModel.setIpNumber(model.getIpNumber());
		soapModel.setDocPath(model.getDocPath());
		soapModel.setDepartmentName(model.getDepartmentName());
		soapModel.setStatus(model.getStatus());

		return soapModel;
	}

	public static LabReportSoap[] toSoapModels(LabReport[] models) {
		LabReportSoap[] soapModels = new LabReportSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static LabReportSoap[][] toSoapModels(LabReport[][] models) {
		LabReportSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new LabReportSoap[models.length][models[0].length];
		}
		else {
			soapModels = new LabReportSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static LabReportSoap[] toSoapModels(List<LabReport> models) {
		List<LabReportSoap> soapModels = new ArrayList<LabReportSoap>(models.size());

		for (LabReport model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new LabReportSoap[soapModels.size()]);
	}

	public LabReportSoap() {
	}

	public long getPrimaryKey() {
		return _labId;
	}

	public void setPrimaryKey(long pk) {
		setLabId(pk);
	}

	public long getLabId() {
		return _labId;
	}

	public void setLabId(long labId) {
		_labId = labId;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public String getOrderNumber() {
		return _orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		_orderNumber = orderNumber;
	}

	public Date getOrderDate() {
		return _orderDate;
	}

	public void setOrderDate(Date orderDate) {
		_orderDate = orderDate;
	}

	public Date getReportedOn() {
		return _reportedOn;
	}

	public void setReportedOn(Date reportedOn) {
		_reportedOn = reportedOn;
	}

	public String getTestName() {
		return _testName;
	}

	public void setTestName(String testName) {
		_testName = testName;
	}

	public String getIpNumber() {
		return _ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;
	}

	public String getDocPath() {
		return _docPath;
	}

	public void setDocPath(String docPath) {
		_docPath = docPath;
	}

	public String getDepartmentName() {
		return _departmentName;
	}

	public void setDepartmentName(String departmentName) {
		_departmentName = departmentName;
	}

	public boolean getStatus() {
		return _status;
	}

	public boolean isStatus() {
		return _status;
	}

	public void setStatus(boolean status) {
		_status = status;
	}

	private long _labId;
	private String _mrNumber;
	private String _orderNumber;
	private Date _orderDate;
	private Date _reportedOn;
	private String _testName;
	private String _ipNumber;
	private String _docPath;
	private String _departmentName;
	private boolean _status;
}