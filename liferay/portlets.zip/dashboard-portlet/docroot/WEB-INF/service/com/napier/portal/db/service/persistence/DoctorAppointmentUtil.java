/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.napier.portal.db.model.DoctorAppointment;

import java.util.List;

/**
 * The persistence utility for the doctor appointment service. This utility wraps {@link DoctorAppointmentPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DoctorAppointmentPersistence
 * @see DoctorAppointmentPersistenceImpl
 * @generated
 */
public class DoctorAppointmentUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(DoctorAppointment doctorAppointment) {
		getPersistence().clearCache(doctorAppointment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<DoctorAppointment> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<DoctorAppointment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<DoctorAppointment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static DoctorAppointment update(DoctorAppointment doctorAppointment)
		throws SystemException {
		return getPersistence().update(doctorAppointment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static DoctorAppointment update(
		DoctorAppointment doctorAppointment, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(doctorAppointment, serviceContext);
	}

	/**
	* Returns all the doctor appointments where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @return the matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DoctorAppointment> findByuserId(
		long createdByUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserId(createdByUserId);
	}

	/**
	* Returns a range of all the doctor appointments where createdByUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdByUserId the created by user ID
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @return the range of matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DoctorAppointment> findByuserId(
		long createdByUserId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserId(createdByUserId, start, end);
	}

	/**
	* Returns an ordered range of all the doctor appointments where createdByUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdByUserId the created by user ID
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DoctorAppointment> findByuserId(
		long createdByUserId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserId(createdByUserId, start, end, orderByComparator);
	}

	/**
	* Returns the first doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment findByuserId_First(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException {
		return getPersistence()
				   .findByuserId_First(createdByUserId, orderByComparator);
	}

	/**
	* Returns the first doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching doctor appointment, or <code>null</code> if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment fetchByuserId_First(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserId_First(createdByUserId, orderByComparator);
	}

	/**
	* Returns the last doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment findByuserId_Last(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException {
		return getPersistence()
				   .findByuserId_Last(createdByUserId, orderByComparator);
	}

	/**
	* Returns the last doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching doctor appointment, or <code>null</code> if a matching doctor appointment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment fetchByuserId_Last(
		long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserId_Last(createdByUserId, orderByComparator);
	}

	/**
	* Returns the doctor appointments before and after the current doctor appointment in the ordered set where createdByUserId = &#63;.
	*
	* @param appointmentId the primary key of the current doctor appointment
	* @param createdByUserId the created by user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment[] findByuserId_PrevAndNext(
		long appointmentId, long createdByUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException {
		return getPersistence()
				   .findByuserId_PrevAndNext(appointmentId, createdByUserId,
			orderByComparator);
	}

	/**
	* Removes all the doctor appointments where createdByUserId = &#63; from the database.
	*
	* @param createdByUserId the created by user ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserId(long createdByUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserId(createdByUserId);
	}

	/**
	* Returns the number of doctor appointments where createdByUserId = &#63;.
	*
	* @param createdByUserId the created by user ID
	* @return the number of matching doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserId(long createdByUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserId(createdByUserId);
	}

	/**
	* Caches the doctor appointment in the entity cache if it is enabled.
	*
	* @param doctorAppointment the doctor appointment
	*/
	public static void cacheResult(
		com.napier.portal.db.model.DoctorAppointment doctorAppointment) {
		getPersistence().cacheResult(doctorAppointment);
	}

	/**
	* Caches the doctor appointments in the entity cache if it is enabled.
	*
	* @param doctorAppointments the doctor appointments
	*/
	public static void cacheResult(
		java.util.List<com.napier.portal.db.model.DoctorAppointment> doctorAppointments) {
		getPersistence().cacheResult(doctorAppointments);
	}

	/**
	* Creates a new doctor appointment with the primary key. Does not add the doctor appointment to the database.
	*
	* @param appointmentId the primary key for the new doctor appointment
	* @return the new doctor appointment
	*/
	public static com.napier.portal.db.model.DoctorAppointment create(
		long appointmentId) {
		return getPersistence().create(appointmentId);
	}

	/**
	* Removes the doctor appointment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param appointmentId the primary key of the doctor appointment
	* @return the doctor appointment that was removed
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment remove(
		long appointmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException {
		return getPersistence().remove(appointmentId);
	}

	public static com.napier.portal.db.model.DoctorAppointment updateImpl(
		com.napier.portal.db.model.DoctorAppointment doctorAppointment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(doctorAppointment);
	}

	/**
	* Returns the doctor appointment with the primary key or throws a {@link com.napier.portal.db.NoSuchDoctorAppointmentException} if it could not be found.
	*
	* @param appointmentId the primary key of the doctor appointment
	* @return the doctor appointment
	* @throws com.napier.portal.db.NoSuchDoctorAppointmentException if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment findByPrimaryKey(
		long appointmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDoctorAppointmentException {
		return getPersistence().findByPrimaryKey(appointmentId);
	}

	/**
	* Returns the doctor appointment with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param appointmentId the primary key of the doctor appointment
	* @return the doctor appointment, or <code>null</code> if a doctor appointment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.napier.portal.db.model.DoctorAppointment fetchByPrimaryKey(
		long appointmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(appointmentId);
	}

	/**
	* Returns all the doctor appointments.
	*
	* @return the doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DoctorAppointment> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the doctor appointments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @return the range of doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DoctorAppointment> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the doctor appointments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DoctorAppointmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of doctor appointments
	* @param end the upper bound of the range of doctor appointments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.napier.portal.db.model.DoctorAppointment> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the doctor appointments from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of doctor appointments.
	*
	* @return the number of doctor appointments
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static DoctorAppointmentPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (DoctorAppointmentPersistence)PortletBeanLocatorUtil.locate(com.napier.portal.db.service.ClpSerializer.getServletContextName(),
					DoctorAppointmentPersistence.class.getName());

			ReferenceRegistry.registerReference(DoctorAppointmentUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(DoctorAppointmentPersistence persistence) {
	}

	private static DoctorAppointmentPersistence _persistence;
}