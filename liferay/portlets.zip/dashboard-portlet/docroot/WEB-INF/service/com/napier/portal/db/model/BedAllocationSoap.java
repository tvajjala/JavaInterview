/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class BedAllocationSoap implements Serializable {
	public static BedAllocationSoap toSoapModel(BedAllocation model) {
		BedAllocationSoap soapModel = new BedAllocationSoap();

		soapModel.setBedAllocationId(model.getBedAllocationId());
		soapModel.setBedReservationNumber(model.getBedReservationNumber());
		soapModel.setBedReservationDate(model.getBedReservationDate());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setIpNumber(model.getIpNumber());
		soapModel.setBedNumber(model.getBedNumber());
		soapModel.setJoiningDate(model.getJoiningDate());
		soapModel.setAdmissionDate(model.getAdmissionDate());
		soapModel.setPatientName(model.getPatientName());
		soapModel.setAge(model.getAge());
		soapModel.setGender(model.getGender());
		soapModel.setMobile(model.getMobile());
		soapModel.setEmail(model.getEmail());
		soapModel.setStatus(model.getStatus());
		soapModel.setCreatedUserId(model.getCreatedUserId());

		return soapModel;
	}

	public static BedAllocationSoap[] toSoapModels(BedAllocation[] models) {
		BedAllocationSoap[] soapModels = new BedAllocationSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static BedAllocationSoap[][] toSoapModels(BedAllocation[][] models) {
		BedAllocationSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new BedAllocationSoap[models.length][models[0].length];
		}
		else {
			soapModels = new BedAllocationSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static BedAllocationSoap[] toSoapModels(List<BedAllocation> models) {
		List<BedAllocationSoap> soapModels = new ArrayList<BedAllocationSoap>(models.size());

		for (BedAllocation model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new BedAllocationSoap[soapModels.size()]);
	}

	public BedAllocationSoap() {
	}

	public long getPrimaryKey() {
		return _bedAllocationId;
	}

	public void setPrimaryKey(long pk) {
		setBedAllocationId(pk);
	}

	public long getBedAllocationId() {
		return _bedAllocationId;
	}

	public void setBedAllocationId(long bedAllocationId) {
		_bedAllocationId = bedAllocationId;
	}

	public String getBedReservationNumber() {
		return _bedReservationNumber;
	}

	public void setBedReservationNumber(String bedReservationNumber) {
		_bedReservationNumber = bedReservationNumber;
	}

	public Date getBedReservationDate() {
		return _bedReservationDate;
	}

	public void setBedReservationDate(Date bedReservationDate) {
		_bedReservationDate = bedReservationDate;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public String getIpNumber() {
		return _ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;
	}

	public String getBedNumber() {
		return _bedNumber;
	}

	public void setBedNumber(String bedNumber) {
		_bedNumber = bedNumber;
	}

	public Date getJoiningDate() {
		return _joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		_joiningDate = joiningDate;
	}

	public Date getAdmissionDate() {
		return _admissionDate;
	}

	public void setAdmissionDate(Date admissionDate) {
		_admissionDate = admissionDate;
	}

	public String getPatientName() {
		return _patientName;
	}

	public void setPatientName(String patientName) {
		_patientName = patientName;
	}

	public int getAge() {
		return _age;
	}

	public void setAge(int age) {
		_age = age;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public String getMobile() {
		return _mobile;
	}

	public void setMobile(String mobile) {
		_mobile = mobile;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getStatus() {
		return _status;
	}

	public void setStatus(String status) {
		_status = status;
	}

	public long getCreatedUserId() {
		return _createdUserId;
	}

	public void setCreatedUserId(long createdUserId) {
		_createdUserId = createdUserId;
	}

	private long _bedAllocationId;
	private String _bedReservationNumber;
	private Date _bedReservationDate;
	private String _mrNumber;
	private String _ipNumber;
	private String _bedNumber;
	private Date _joiningDate;
	private Date _admissionDate;
	private String _patientName;
	private int _age;
	private String _gender;
	private String _mobile;
	private String _email;
	private String _status;
	private long _createdUserId;
}