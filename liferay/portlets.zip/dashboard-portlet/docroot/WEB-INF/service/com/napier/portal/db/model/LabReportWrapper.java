/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link LabReport}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see LabReport
 * @generated
 */
public class LabReportWrapper implements LabReport, ModelWrapper<LabReport> {
	public LabReportWrapper(LabReport labReport) {
		_labReport = labReport;
	}

	@Override
	public Class<?> getModelClass() {
		return LabReport.class;
	}

	@Override
	public String getModelClassName() {
		return LabReport.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("labId", getLabId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("orderNumber", getOrderNumber());
		attributes.put("orderDate", getOrderDate());
		attributes.put("reportedOn", getReportedOn());
		attributes.put("testName", getTestName());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("docPath", getDocPath());
		attributes.put("departmentName", getDepartmentName());
		attributes.put("status", getStatus());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long labId = (Long)attributes.get("labId");

		if (labId != null) {
			setLabId(labId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String orderNumber = (String)attributes.get("orderNumber");

		if (orderNumber != null) {
			setOrderNumber(orderNumber);
		}

		Date orderDate = (Date)attributes.get("orderDate");

		if (orderDate != null) {
			setOrderDate(orderDate);
		}

		Date reportedOn = (Date)attributes.get("reportedOn");

		if (reportedOn != null) {
			setReportedOn(reportedOn);
		}

		String testName = (String)attributes.get("testName");

		if (testName != null) {
			setTestName(testName);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String docPath = (String)attributes.get("docPath");

		if (docPath != null) {
			setDocPath(docPath);
		}

		String departmentName = (String)attributes.get("departmentName");

		if (departmentName != null) {
			setDepartmentName(departmentName);
		}

		Boolean status = (Boolean)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}
	}

	/**
	* Returns the primary key of this lab report.
	*
	* @return the primary key of this lab report
	*/
	@Override
	public long getPrimaryKey() {
		return _labReport.getPrimaryKey();
	}

	/**
	* Sets the primary key of this lab report.
	*
	* @param primaryKey the primary key of this lab report
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_labReport.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the lab ID of this lab report.
	*
	* @return the lab ID of this lab report
	*/
	@Override
	public long getLabId() {
		return _labReport.getLabId();
	}

	/**
	* Sets the lab ID of this lab report.
	*
	* @param labId the lab ID of this lab report
	*/
	@Override
	public void setLabId(long labId) {
		_labReport.setLabId(labId);
	}

	/**
	* Returns the mr number of this lab report.
	*
	* @return the mr number of this lab report
	*/
	@Override
	public java.lang.String getMrNumber() {
		return _labReport.getMrNumber();
	}

	/**
	* Sets the mr number of this lab report.
	*
	* @param mrNumber the mr number of this lab report
	*/
	@Override
	public void setMrNumber(java.lang.String mrNumber) {
		_labReport.setMrNumber(mrNumber);
	}

	/**
	* Returns the order number of this lab report.
	*
	* @return the order number of this lab report
	*/
	@Override
	public java.lang.String getOrderNumber() {
		return _labReport.getOrderNumber();
	}

	/**
	* Sets the order number of this lab report.
	*
	* @param orderNumber the order number of this lab report
	*/
	@Override
	public void setOrderNumber(java.lang.String orderNumber) {
		_labReport.setOrderNumber(orderNumber);
	}

	/**
	* Returns the order date of this lab report.
	*
	* @return the order date of this lab report
	*/
	@Override
	public java.util.Date getOrderDate() {
		return _labReport.getOrderDate();
	}

	/**
	* Sets the order date of this lab report.
	*
	* @param orderDate the order date of this lab report
	*/
	@Override
	public void setOrderDate(java.util.Date orderDate) {
		_labReport.setOrderDate(orderDate);
	}

	/**
	* Returns the reported on of this lab report.
	*
	* @return the reported on of this lab report
	*/
	@Override
	public java.util.Date getReportedOn() {
		return _labReport.getReportedOn();
	}

	/**
	* Sets the reported on of this lab report.
	*
	* @param reportedOn the reported on of this lab report
	*/
	@Override
	public void setReportedOn(java.util.Date reportedOn) {
		_labReport.setReportedOn(reportedOn);
	}

	/**
	* Returns the test name of this lab report.
	*
	* @return the test name of this lab report
	*/
	@Override
	public java.lang.String getTestName() {
		return _labReport.getTestName();
	}

	/**
	* Sets the test name of this lab report.
	*
	* @param testName the test name of this lab report
	*/
	@Override
	public void setTestName(java.lang.String testName) {
		_labReport.setTestName(testName);
	}

	/**
	* Returns the ip number of this lab report.
	*
	* @return the ip number of this lab report
	*/
	@Override
	public java.lang.String getIpNumber() {
		return _labReport.getIpNumber();
	}

	/**
	* Sets the ip number of this lab report.
	*
	* @param ipNumber the ip number of this lab report
	*/
	@Override
	public void setIpNumber(java.lang.String ipNumber) {
		_labReport.setIpNumber(ipNumber);
	}

	/**
	* Returns the doc path of this lab report.
	*
	* @return the doc path of this lab report
	*/
	@Override
	public java.lang.String getDocPath() {
		return _labReport.getDocPath();
	}

	/**
	* Sets the doc path of this lab report.
	*
	* @param docPath the doc path of this lab report
	*/
	@Override
	public void setDocPath(java.lang.String docPath) {
		_labReport.setDocPath(docPath);
	}

	/**
	* Returns the department name of this lab report.
	*
	* @return the department name of this lab report
	*/
	@Override
	public java.lang.String getDepartmentName() {
		return _labReport.getDepartmentName();
	}

	/**
	* Sets the department name of this lab report.
	*
	* @param departmentName the department name of this lab report
	*/
	@Override
	public void setDepartmentName(java.lang.String departmentName) {
		_labReport.setDepartmentName(departmentName);
	}

	/**
	* Returns the status of this lab report.
	*
	* @return the status of this lab report
	*/
	@Override
	public boolean getStatus() {
		return _labReport.getStatus();
	}

	/**
	* Returns <code>true</code> if this lab report is status.
	*
	* @return <code>true</code> if this lab report is status; <code>false</code> otherwise
	*/
	@Override
	public boolean isStatus() {
		return _labReport.isStatus();
	}

	/**
	* Sets whether this lab report is status.
	*
	* @param status the status of this lab report
	*/
	@Override
	public void setStatus(boolean status) {
		_labReport.setStatus(status);
	}

	@Override
	public boolean isNew() {
		return _labReport.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_labReport.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _labReport.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_labReport.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _labReport.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _labReport.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_labReport.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _labReport.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_labReport.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_labReport.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_labReport.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new LabReportWrapper((LabReport)_labReport.clone());
	}

	@Override
	public int compareTo(com.napier.portal.db.model.LabReport labReport) {
		return _labReport.compareTo(labReport);
	}

	@Override
	public int hashCode() {
		return _labReport.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.LabReport> toCacheModel() {
		return _labReport.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.LabReport toEscapedModel() {
		return new LabReportWrapper(_labReport.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.LabReport toUnescapedModel() {
		return new LabReportWrapper(_labReport.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _labReport.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _labReport.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_labReport.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LabReportWrapper)) {
			return false;
		}

		LabReportWrapper labReportWrapper = (LabReportWrapper)obj;

		if (Validator.equals(_labReport, labReportWrapper._labReport)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public LabReport getWrappedLabReport() {
		return _labReport;
	}

	@Override
	public LabReport getWrappedModel() {
		return _labReport;
	}

	@Override
	public void resetOriginalValues() {
		_labReport.resetOriginalValues();
	}

	private LabReport _labReport;
}