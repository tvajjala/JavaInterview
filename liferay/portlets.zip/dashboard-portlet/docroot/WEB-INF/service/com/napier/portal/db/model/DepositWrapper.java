/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Deposit}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Deposit
 * @generated
 */
public class DepositWrapper implements Deposit, ModelWrapper<Deposit> {
	public DepositWrapper(Deposit deposit) {
		_deposit = deposit;
	}

	@Override
	public Class<?> getModelClass() {
		return Deposit.class;
	}

	@Override
	public String getModelClassName() {
		return Deposit.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("depositId", getDepositId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("depositNumber", getDepositNumber());
		attributes.put("depositAmount", getDepositAmount());
		attributes.put("depositAgainst", getDepositAgainst());
		attributes.put("patientBillId", getPatientBillId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long depositId = (Long)attributes.get("depositId");

		if (depositId != null) {
			setDepositId(depositId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String depositNumber = (String)attributes.get("depositNumber");

		if (depositNumber != null) {
			setDepositNumber(depositNumber);
		}

		Double depositAmount = (Double)attributes.get("depositAmount");

		if (depositAmount != null) {
			setDepositAmount(depositAmount);
		}

		String depositAgainst = (String)attributes.get("depositAgainst");

		if (depositAgainst != null) {
			setDepositAgainst(depositAgainst);
		}

		Long patientBillId = (Long)attributes.get("patientBillId");

		if (patientBillId != null) {
			setPatientBillId(patientBillId);
		}
	}

	/**
	* Returns the primary key of this deposit.
	*
	* @return the primary key of this deposit
	*/
	@Override
	public long getPrimaryKey() {
		return _deposit.getPrimaryKey();
	}

	/**
	* Sets the primary key of this deposit.
	*
	* @param primaryKey the primary key of this deposit
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_deposit.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the deposit ID of this deposit.
	*
	* @return the deposit ID of this deposit
	*/
	@Override
	public long getDepositId() {
		return _deposit.getDepositId();
	}

	/**
	* Sets the deposit ID of this deposit.
	*
	* @param depositId the deposit ID of this deposit
	*/
	@Override
	public void setDepositId(long depositId) {
		_deposit.setDepositId(depositId);
	}

	/**
	* Returns the mr number of this deposit.
	*
	* @return the mr number of this deposit
	*/
	@Override
	public java.lang.String getMrNumber() {
		return _deposit.getMrNumber();
	}

	/**
	* Sets the mr number of this deposit.
	*
	* @param mrNumber the mr number of this deposit
	*/
	@Override
	public void setMrNumber(java.lang.String mrNumber) {
		_deposit.setMrNumber(mrNumber);
	}

	/**
	* Returns the ip number of this deposit.
	*
	* @return the ip number of this deposit
	*/
	@Override
	public java.lang.String getIpNumber() {
		return _deposit.getIpNumber();
	}

	/**
	* Sets the ip number of this deposit.
	*
	* @param ipNumber the ip number of this deposit
	*/
	@Override
	public void setIpNumber(java.lang.String ipNumber) {
		_deposit.setIpNumber(ipNumber);
	}

	/**
	* Returns the deposit number of this deposit.
	*
	* @return the deposit number of this deposit
	*/
	@Override
	public java.lang.String getDepositNumber() {
		return _deposit.getDepositNumber();
	}

	/**
	* Sets the deposit number of this deposit.
	*
	* @param depositNumber the deposit number of this deposit
	*/
	@Override
	public void setDepositNumber(java.lang.String depositNumber) {
		_deposit.setDepositNumber(depositNumber);
	}

	/**
	* Returns the deposit amount of this deposit.
	*
	* @return the deposit amount of this deposit
	*/
	@Override
	public double getDepositAmount() {
		return _deposit.getDepositAmount();
	}

	/**
	* Sets the deposit amount of this deposit.
	*
	* @param depositAmount the deposit amount of this deposit
	*/
	@Override
	public void setDepositAmount(double depositAmount) {
		_deposit.setDepositAmount(depositAmount);
	}

	/**
	* Returns the deposit against of this deposit.
	*
	* @return the deposit against of this deposit
	*/
	@Override
	public java.lang.String getDepositAgainst() {
		return _deposit.getDepositAgainst();
	}

	/**
	* Sets the deposit against of this deposit.
	*
	* @param depositAgainst the deposit against of this deposit
	*/
	@Override
	public void setDepositAgainst(java.lang.String depositAgainst) {
		_deposit.setDepositAgainst(depositAgainst);
	}

	/**
	* Returns the patient bill ID of this deposit.
	*
	* @return the patient bill ID of this deposit
	*/
	@Override
	public long getPatientBillId() {
		return _deposit.getPatientBillId();
	}

	/**
	* Sets the patient bill ID of this deposit.
	*
	* @param patientBillId the patient bill ID of this deposit
	*/
	@Override
	public void setPatientBillId(long patientBillId) {
		_deposit.setPatientBillId(patientBillId);
	}

	@Override
	public boolean isNew() {
		return _deposit.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_deposit.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _deposit.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_deposit.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _deposit.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _deposit.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_deposit.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _deposit.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_deposit.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_deposit.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_deposit.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DepositWrapper((Deposit)_deposit.clone());
	}

	@Override
	public int compareTo(com.napier.portal.db.model.Deposit deposit) {
		return _deposit.compareTo(deposit);
	}

	@Override
	public int hashCode() {
		return _deposit.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.Deposit> toCacheModel() {
		return _deposit.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.Deposit toEscapedModel() {
		return new DepositWrapper(_deposit.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.Deposit toUnescapedModel() {
		return new DepositWrapper(_deposit.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _deposit.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _deposit.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_deposit.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DepositWrapper)) {
			return false;
		}

		DepositWrapper depositWrapper = (DepositWrapper)obj;

		if (Validator.equals(_deposit, depositWrapper._deposit)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Deposit getWrappedDeposit() {
		return _deposit;
	}

	@Override
	public Deposit getWrappedModel() {
		return _deposit;
	}

	@Override
	public void resetOriginalValues() {
		_deposit.resetOriginalValues();
	}

	private Deposit _deposit;
}