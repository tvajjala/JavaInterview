/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.napier.portal.db.model.BedReservation;

/**
 * The persistence interface for the bed reservation service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see BedReservationPersistenceImpl
 * @see BedReservationUtil
 * @generated
 */
public interface BedReservationPersistence extends BasePersistence<BedReservation> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link BedReservationUtil} to access the bed reservation persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the bed reservations where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @return the matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findBybedClass(
		java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the bed reservations where bedClass = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bedClass the bed class
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @return the range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findBybedClass(
		java.lang.String bedClass, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the bed reservations where bedClass = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bedClass the bed class
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findBybedClass(
		java.lang.String bedClass, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation findBybedClass_First(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	/**
	* Returns the first bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation fetchBybedClass_First(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation findBybedClass_Last(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	/**
	* Returns the last bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation fetchBybedClass_Last(
		java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the bed reservations before and after the current bed reservation in the ordered set where bedClass = &#63;.
	*
	* @param bedReservationId the primary key of the current bed reservation
	* @param bedClass the bed class
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation[] findBybedClass_PrevAndNext(
		long bedReservationId, java.lang.String bedClass,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	/**
	* Removes all the bed reservations where bedClass = &#63; from the database.
	*
	* @param bedClass the bed class
	* @throws SystemException if a system exception occurred
	*/
	public void removeBybedClass(java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of bed reservations where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @return the number of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public int countBybedClass(java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the bed reservations where ward = &#63;.
	*
	* @param ward the ward
	* @return the matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findByward(
		java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the bed reservations where ward = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ward the ward
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @return the range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findByward(
		java.lang.String ward, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the bed reservations where ward = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ward the ward
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findByward(
		java.lang.String ward, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation findByward_First(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	/**
	* Returns the first bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation fetchByward_First(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation findByward_Last(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	/**
	* Returns the last bed reservation in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bed reservation, or <code>null</code> if a matching bed reservation could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation fetchByward_Last(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the bed reservations before and after the current bed reservation in the ordered set where ward = &#63;.
	*
	* @param bedReservationId the primary key of the current bed reservation
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation[] findByward_PrevAndNext(
		long bedReservationId, java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	/**
	* Removes all the bed reservations where ward = &#63; from the database.
	*
	* @param ward the ward
	* @throws SystemException if a system exception occurred
	*/
	public void removeByward(java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of bed reservations where ward = &#63;.
	*
	* @param ward the ward
	* @return the number of matching bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public int countByward(java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the bed reservation in the entity cache if it is enabled.
	*
	* @param bedReservation the bed reservation
	*/
	public void cacheResult(
		com.napier.portal.db.model.BedReservation bedReservation);

	/**
	* Caches the bed reservations in the entity cache if it is enabled.
	*
	* @param bedReservations the bed reservations
	*/
	public void cacheResult(
		java.util.List<com.napier.portal.db.model.BedReservation> bedReservations);

	/**
	* Creates a new bed reservation with the primary key. Does not add the bed reservation to the database.
	*
	* @param bedReservationId the primary key for the new bed reservation
	* @return the new bed reservation
	*/
	public com.napier.portal.db.model.BedReservation create(
		long bedReservationId);

	/**
	* Removes the bed reservation with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param bedReservationId the primary key of the bed reservation
	* @return the bed reservation that was removed
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation remove(
		long bedReservationId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	public com.napier.portal.db.model.BedReservation updateImpl(
		com.napier.portal.db.model.BedReservation bedReservation)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the bed reservation with the primary key or throws a {@link com.napier.portal.db.NoSuchBedReservationException} if it could not be found.
	*
	* @param bedReservationId the primary key of the bed reservation
	* @return the bed reservation
	* @throws com.napier.portal.db.NoSuchBedReservationException if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation findByPrimaryKey(
		long bedReservationId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchBedReservationException;

	/**
	* Returns the bed reservation with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param bedReservationId the primary key of the bed reservation
	* @return the bed reservation, or <code>null</code> if a bed reservation with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.BedReservation fetchByPrimaryKey(
		long bedReservationId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the bed reservations.
	*
	* @return the bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the bed reservations.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @return the range of bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the bed reservations.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.BedReservationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bed reservations
	* @param end the upper bound of the range of bed reservations (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.BedReservation> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the bed reservations from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of bed reservations.
	*
	* @return the number of bed reservations
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}