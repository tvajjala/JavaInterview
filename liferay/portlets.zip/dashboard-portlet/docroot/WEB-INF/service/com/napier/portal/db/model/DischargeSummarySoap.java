/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class DischargeSummarySoap implements Serializable {
	public static DischargeSummarySoap toSoapModel(DischargeSummary model) {
		DischargeSummarySoap soapModel = new DischargeSummarySoap();

		soapModel.setDischargeSummaryId(model.getDischargeSummaryId());
		soapModel.setMrNumber(model.getMrNumber());
		soapModel.setIpNumber(model.getIpNumber());
		soapModel.setDocPath(model.getDocPath());
		soapModel.setDepartmentName(model.getDepartmentName());
		soapModel.setStatus(model.getStatus());
		soapModel.setWard(model.getWard());
		soapModel.setBedClass(model.getBedClass());
		soapModel.setDischargeDate(model.getDischargeDate());
		soapModel.setAdmissionDate(model.getAdmissionDate());
		soapModel.setPrimaryDoctor(model.getPrimaryDoctor());
		soapModel.setChiefComplaint(model.getChiefComplaint());

		return soapModel;
	}

	public static DischargeSummarySoap[] toSoapModels(DischargeSummary[] models) {
		DischargeSummarySoap[] soapModels = new DischargeSummarySoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static DischargeSummarySoap[][] toSoapModels(
		DischargeSummary[][] models) {
		DischargeSummarySoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new DischargeSummarySoap[models.length][models[0].length];
		}
		else {
			soapModels = new DischargeSummarySoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static DischargeSummarySoap[] toSoapModels(
		List<DischargeSummary> models) {
		List<DischargeSummarySoap> soapModels = new ArrayList<DischargeSummarySoap>(models.size());

		for (DischargeSummary model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new DischargeSummarySoap[soapModels.size()]);
	}

	public DischargeSummarySoap() {
	}

	public long getPrimaryKey() {
		return _dischargeSummaryId;
	}

	public void setPrimaryKey(long pk) {
		setDischargeSummaryId(pk);
	}

	public long getDischargeSummaryId() {
		return _dischargeSummaryId;
	}

	public void setDischargeSummaryId(long dischargeSummaryId) {
		_dischargeSummaryId = dischargeSummaryId;
	}

	public String getMrNumber() {
		return _mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;
	}

	public String getIpNumber() {
		return _ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		_ipNumber = ipNumber;
	}

	public String getDocPath() {
		return _docPath;
	}

	public void setDocPath(String docPath) {
		_docPath = docPath;
	}

	public String getDepartmentName() {
		return _departmentName;
	}

	public void setDepartmentName(String departmentName) {
		_departmentName = departmentName;
	}

	public boolean getStatus() {
		return _status;
	}

	public boolean isStatus() {
		return _status;
	}

	public void setStatus(boolean status) {
		_status = status;
	}

	public String getWard() {
		return _ward;
	}

	public void setWard(String ward) {
		_ward = ward;
	}

	public String getBedClass() {
		return _bedClass;
	}

	public void setBedClass(String bedClass) {
		_bedClass = bedClass;
	}

	public Date getDischargeDate() {
		return _dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		_dischargeDate = dischargeDate;
	}

	public Date getAdmissionDate() {
		return _admissionDate;
	}

	public void setAdmissionDate(Date admissionDate) {
		_admissionDate = admissionDate;
	}

	public String getPrimaryDoctor() {
		return _primaryDoctor;
	}

	public void setPrimaryDoctor(String primaryDoctor) {
		_primaryDoctor = primaryDoctor;
	}

	public String getChiefComplaint() {
		return _chiefComplaint;
	}

	public void setChiefComplaint(String chiefComplaint) {
		_chiefComplaint = chiefComplaint;
	}

	private long _dischargeSummaryId;
	private String _mrNumber;
	private String _ipNumber;
	private String _docPath;
	private String _departmentName;
	private boolean _status;
	private String _ward;
	private String _bedClass;
	private Date _dischargeDate;
	private Date _admissionDate;
	private String _primaryDoctor;
	private String _chiefComplaint;
}