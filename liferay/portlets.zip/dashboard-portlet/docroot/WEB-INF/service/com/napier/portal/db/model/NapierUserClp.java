/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import com.napier.portal.db.service.ClpSerializer;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Brian Wing Shun Chan
 */
public class NapierUserClp extends BaseModelImpl<NapierUser>
	implements NapierUser {
	public NapierUserClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return NapierUser.class;
	}

	@Override
	public String getModelClassName() {
		return NapierUser.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _napierUserId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setNapierUserId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _napierUserId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("napierUserId", getNapierUserId());
		attributes.put("portalUserId", getPortalUserId());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("tpaId", getTpaId());
		attributes.put("coroporateId", getCoroporateId());
		attributes.put("doctorId", getDoctorId());
		attributes.put("age", getAge());
		attributes.put("mobile", getMobile());
		attributes.put("gender", getGender());
		attributes.put("specialization", getSpecialization());
		attributes.put("userType", getUserType());
		attributes.put("address", getAddress());
		attributes.put("email", getEmail());
		attributes.put("name", getName());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long napierUserId = (Long)attributes.get("napierUserId");

		if (napierUserId != null) {
			setNapierUserId(napierUserId);
		}

		Long portalUserId = (Long)attributes.get("portalUserId");

		if (portalUserId != null) {
			setPortalUserId(portalUserId);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String tpaId = (String)attributes.get("tpaId");

		if (tpaId != null) {
			setTpaId(tpaId);
		}

		String coroporateId = (String)attributes.get("coroporateId");

		if (coroporateId != null) {
			setCoroporateId(coroporateId);
		}

		String doctorId = (String)attributes.get("doctorId");

		if (doctorId != null) {
			setDoctorId(doctorId);
		}

		Integer age = (Integer)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String mobile = (String)attributes.get("mobile");

		if (mobile != null) {
			setMobile(mobile);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String specialization = (String)attributes.get("specialization");

		if (specialization != null) {
			setSpecialization(specialization);
		}

		String userType = (String)attributes.get("userType");

		if (userType != null) {
			setUserType(userType);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}
	}

	@Override
	public long getNapierUserId() {
		return _napierUserId;
	}

	@Override
	public void setNapierUserId(long napierUserId) {
		_napierUserId = napierUserId;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setNapierUserId", long.class);

				method.invoke(_napierUserRemoteModel, napierUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNapierUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getNapierUserId(), "uuid",
			_napierUserUuid);
	}

	@Override
	public void setNapierUserUuid(String napierUserUuid) {
		_napierUserUuid = napierUserUuid;
	}

	@Override
	public long getPortalUserId() {
		return _portalUserId;
	}

	@Override
	public void setPortalUserId(long portalUserId) {
		_portalUserId = portalUserId;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setPortalUserId", long.class);

				method.invoke(_napierUserRemoteModel, portalUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPortalUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getPortalUserId(), "uuid",
			_portalUserUuid);
	}

	@Override
	public void setPortalUserUuid(String portalUserUuid) {
		_portalUserUuid = portalUserUuid;
	}

	@Override
	public String getMrNumber() {
		return _mrNumber;
	}

	@Override
	public void setMrNumber(String mrNumber) {
		_mrNumber = mrNumber;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setMrNumber", String.class);

				method.invoke(_napierUserRemoteModel, mrNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTpaId() {
		return _tpaId;
	}

	@Override
	public void setTpaId(String tpaId) {
		_tpaId = tpaId;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setTpaId", String.class);

				method.invoke(_napierUserRemoteModel, tpaId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCoroporateId() {
		return _coroporateId;
	}

	@Override
	public void setCoroporateId(String coroporateId) {
		_coroporateId = coroporateId;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setCoroporateId", String.class);

				method.invoke(_napierUserRemoteModel, coroporateId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDoctorId() {
		return _doctorId;
	}

	@Override
	public void setDoctorId(String doctorId) {
		_doctorId = doctorId;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setDoctorId", String.class);

				method.invoke(_napierUserRemoteModel, doctorId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getAge() {
		return _age;
	}

	@Override
	public void setAge(int age) {
		_age = age;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setAge", int.class);

				method.invoke(_napierUserRemoteModel, age);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMobile() {
		return _mobile;
	}

	@Override
	public void setMobile(String mobile) {
		_mobile = mobile;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setMobile", String.class);

				method.invoke(_napierUserRemoteModel, mobile);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getGender() {
		return _gender;
	}

	@Override
	public void setGender(String gender) {
		_gender = gender;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setGender", String.class);

				method.invoke(_napierUserRemoteModel, gender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSpecialization() {
		return _specialization;
	}

	@Override
	public void setSpecialization(String specialization) {
		_specialization = specialization;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setSpecialization",
						String.class);

				method.invoke(_napierUserRemoteModel, specialization);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserType() {
		return _userType;
	}

	@Override
	public void setUserType(String userType) {
		_userType = userType;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setUserType", String.class);

				method.invoke(_napierUserRemoteModel, userType);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAddress() {
		return _address;
	}

	@Override
	public void setAddress(String address) {
		_address = address;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setAddress", String.class);

				method.invoke(_napierUserRemoteModel, address);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmail() {
		return _email;
	}

	@Override
	public void setEmail(String email) {
		_email = email;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setEmail", String.class);

				method.invoke(_napierUserRemoteModel, email);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getName() {
		return _name;
	}

	@Override
	public void setName(String name) {
		_name = name;

		if (_napierUserRemoteModel != null) {
			try {
				Class<?> clazz = _napierUserRemoteModel.getClass();

				Method method = clazz.getMethod("setName", String.class);

				method.invoke(_napierUserRemoteModel, name);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getNapierUserRemoteModel() {
		return _napierUserRemoteModel;
	}

	public void setNapierUserRemoteModel(BaseModel<?> napierUserRemoteModel) {
		_napierUserRemoteModel = napierUserRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _napierUserRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_napierUserRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			NapierUserLocalServiceUtil.addNapierUser(this);
		}
		else {
			NapierUserLocalServiceUtil.updateNapierUser(this);
		}
	}

	@Override
	public NapierUser toEscapedModel() {
		return (NapierUser)ProxyUtil.newProxyInstance(NapierUser.class.getClassLoader(),
			new Class[] { NapierUser.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		NapierUserClp clone = new NapierUserClp();

		clone.setNapierUserId(getNapierUserId());
		clone.setPortalUserId(getPortalUserId());
		clone.setMrNumber(getMrNumber());
		clone.setTpaId(getTpaId());
		clone.setCoroporateId(getCoroporateId());
		clone.setDoctorId(getDoctorId());
		clone.setAge(getAge());
		clone.setMobile(getMobile());
		clone.setGender(getGender());
		clone.setSpecialization(getSpecialization());
		clone.setUserType(getUserType());
		clone.setAddress(getAddress());
		clone.setEmail(getEmail());
		clone.setName(getName());

		return clone;
	}

	@Override
	public int compareTo(NapierUser napierUser) {
		int value = 0;

		value = getMrNumber().compareTo(napierUser.getMrNumber());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof NapierUserClp)) {
			return false;
		}

		NapierUserClp napierUser = (NapierUserClp)obj;

		long primaryKey = napierUser.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{napierUserId=");
		sb.append(getNapierUserId());
		sb.append(", portalUserId=");
		sb.append(getPortalUserId());
		sb.append(", mrNumber=");
		sb.append(getMrNumber());
		sb.append(", tpaId=");
		sb.append(getTpaId());
		sb.append(", coroporateId=");
		sb.append(getCoroporateId());
		sb.append(", doctorId=");
		sb.append(getDoctorId());
		sb.append(", age=");
		sb.append(getAge());
		sb.append(", mobile=");
		sb.append(getMobile());
		sb.append(", gender=");
		sb.append(getGender());
		sb.append(", specialization=");
		sb.append(getSpecialization());
		sb.append(", userType=");
		sb.append(getUserType());
		sb.append(", address=");
		sb.append(getAddress());
		sb.append(", email=");
		sb.append(getEmail());
		sb.append(", name=");
		sb.append(getName());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(46);

		sb.append("<model><model-name>");
		sb.append("com.napier.portal.db.model.NapierUser");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>napierUserId</column-name><column-value><![CDATA[");
		sb.append(getNapierUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>portalUserId</column-name><column-value><![CDATA[");
		sb.append(getPortalUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mrNumber</column-name><column-value><![CDATA[");
		sb.append(getMrNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>tpaId</column-name><column-value><![CDATA[");
		sb.append(getTpaId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>coroporateId</column-name><column-value><![CDATA[");
		sb.append(getCoroporateId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>doctorId</column-name><column-value><![CDATA[");
		sb.append(getDoctorId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>age</column-name><column-value><![CDATA[");
		sb.append(getAge());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mobile</column-name><column-value><![CDATA[");
		sb.append(getMobile());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>gender</column-name><column-value><![CDATA[");
		sb.append(getGender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>specialization</column-name><column-value><![CDATA[");
		sb.append(getSpecialization());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userType</column-name><column-value><![CDATA[");
		sb.append(getUserType());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>address</column-name><column-value><![CDATA[");
		sb.append(getAddress());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>email</column-name><column-value><![CDATA[");
		sb.append(getEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>name</column-name><column-value><![CDATA[");
		sb.append(getName());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _napierUserId;
	private String _napierUserUuid;
	private long _portalUserId;
	private String _portalUserUuid;
	private String _mrNumber;
	private String _tpaId;
	private String _coroporateId;
	private String _doctorId;
	private int _age;
	private String _mobile;
	private String _gender;
	private String _specialization;
	private String _userType;
	private String _address;
	private String _email;
	private String _name;
	private BaseModel<?> _napierUserRemoteModel;
}