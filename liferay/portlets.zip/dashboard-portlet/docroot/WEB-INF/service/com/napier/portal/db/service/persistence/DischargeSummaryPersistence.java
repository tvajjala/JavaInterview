/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.napier.portal.db.model.DischargeSummary;

/**
 * The persistence interface for the discharge summary service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DischargeSummaryPersistenceImpl
 * @see DischargeSummaryUtil
 * @generated
 */
public interface DischargeSummaryPersistence extends BasePersistence<DischargeSummary> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link DischargeSummaryUtil} to access the discharge summary persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the discharge summaries where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findBymrNumber(
		java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the discharge summaries where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @return the range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findBymrNumber(
		java.lang.String mrNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the discharge summaries where mrNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param mrNumber the mr number
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findBymrNumber(
		java.lang.String mrNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first discharge summary in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the first discharge summary in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchBymrNumber_First(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last discharge summary in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the last discharge summary in the ordered set where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchBymrNumber_Last(
		java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summaries before and after the current discharge summary in the ordered set where mrNumber = &#63;.
	*
	* @param dischargeSummaryId the primary key of the current discharge summary
	* @param mrNumber the mr number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary[] findBymrNumber_PrevAndNext(
		long dischargeSummaryId, java.lang.String mrNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Removes all the discharge summaries where mrNumber = &#63; from the database.
	*
	* @param mrNumber the mr number
	* @throws SystemException if a system exception occurred
	*/
	public void removeBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of discharge summaries where mrNumber = &#63;.
	*
	* @param mrNumber the mr number
	* @return the number of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countBymrNumber(java.lang.String mrNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the discharge summaries where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByipNumber(
		java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the discharge summaries where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @return the range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByipNumber(
		java.lang.String ipNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the discharge summaries where ipNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ipNumber the ip number
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByipNumber(
		java.lang.String ipNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first discharge summary in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the first discharge summary in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByipNumber_First(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last discharge summary in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the last discharge summary in the ordered set where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByipNumber_Last(
		java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summaries before and after the current discharge summary in the ordered set where ipNumber = &#63;.
	*
	* @param dischargeSummaryId the primary key of the current discharge summary
	* @param ipNumber the ip number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary[] findByipNumber_PrevAndNext(
		long dischargeSummaryId, java.lang.String ipNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Removes all the discharge summaries where ipNumber = &#63; from the database.
	*
	* @param ipNumber the ip number
	* @throws SystemException if a system exception occurred
	*/
	public void removeByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of discharge summaries where ipNumber = &#63;.
	*
	* @param ipNumber the ip number
	* @return the number of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countByipNumber(java.lang.String ipNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summary where bedClass = &#63; or throws a {@link com.napier.portal.db.NoSuchDischargeSummaryException} if it could not be found.
	*
	* @param bedClass the bed class
	* @return the matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findBybedClass(
		java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the discharge summary where bedClass = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param bedClass the bed class
	* @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchBybedClass(
		java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summary where bedClass = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param bedClass the bed class
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchBybedClass(
		java.lang.String bedClass, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the discharge summary where bedClass = &#63; from the database.
	*
	* @param bedClass the bed class
	* @return the discharge summary that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary removeBybedClass(
		java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the number of discharge summaries where bedClass = &#63;.
	*
	* @param bedClass the bed class
	* @return the number of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countBybedClass(java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the discharge summaries where ward = &#63;.
	*
	* @param ward the ward
	* @return the matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByward(
		java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the discharge summaries where ward = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ward the ward
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @return the range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByward(
		java.lang.String ward, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the discharge summaries where ward = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ward the ward
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByward(
		java.lang.String ward, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first discharge summary in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByward_First(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the first discharge summary in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByward_First(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last discharge summary in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByward_Last(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the last discharge summary in the ordered set where ward = &#63;.
	*
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByward_Last(
		java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summaries before and after the current discharge summary in the ordered set where ward = &#63;.
	*
	* @param dischargeSummaryId the primary key of the current discharge summary
	* @param ward the ward
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary[] findByward_PrevAndNext(
		long dischargeSummaryId, java.lang.String ward,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Removes all the discharge summaries where ward = &#63; from the database.
	*
	* @param ward the ward
	* @throws SystemException if a system exception occurred
	*/
	public void removeByward(java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of discharge summaries where ward = &#63;.
	*
	* @param ward the ward
	* @return the number of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countByward(java.lang.String ward)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summary where ward = &#63; and bedClass = &#63; or throws a {@link com.napier.portal.db.NoSuchDischargeSummaryException} if it could not be found.
	*
	* @param ward the ward
	* @param bedClass the bed class
	* @return the matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByWardBed(
		java.lang.String ward, java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the discharge summary where ward = &#63; and bedClass = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param ward the ward
	* @param bedClass the bed class
	* @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByWardBed(
		java.lang.String ward, java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summary where ward = &#63; and bedClass = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param ward the ward
	* @param bedClass the bed class
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByWardBed(
		java.lang.String ward, java.lang.String bedClass,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the discharge summary where ward = &#63; and bedClass = &#63; from the database.
	*
	* @param ward the ward
	* @param bedClass the bed class
	* @return the discharge summary that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary removeByWardBed(
		java.lang.String ward, java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the number of discharge summaries where ward = &#63; and bedClass = &#63;.
	*
	* @param ward the ward
	* @param bedClass the bed class
	* @return the number of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countByWardBed(java.lang.String ward, java.lang.String bedClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the discharge summaries where dischargeDate = &#63;.
	*
	* @param dischargeDate the discharge date
	* @return the matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findBydischargeDate(
		java.util.Date dischargeDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the discharge summaries where dischargeDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dischargeDate the discharge date
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @return the range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findBydischargeDate(
		java.util.Date dischargeDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the discharge summaries where dischargeDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dischargeDate the discharge date
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findBydischargeDate(
		java.util.Date dischargeDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first discharge summary in the ordered set where dischargeDate = &#63;.
	*
	* @param dischargeDate the discharge date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findBydischargeDate_First(
		java.util.Date dischargeDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the first discharge summary in the ordered set where dischargeDate = &#63;.
	*
	* @param dischargeDate the discharge date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchBydischargeDate_First(
		java.util.Date dischargeDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last discharge summary in the ordered set where dischargeDate = &#63;.
	*
	* @param dischargeDate the discharge date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findBydischargeDate_Last(
		java.util.Date dischargeDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the last discharge summary in the ordered set where dischargeDate = &#63;.
	*
	* @param dischargeDate the discharge date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchBydischargeDate_Last(
		java.util.Date dischargeDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summaries before and after the current discharge summary in the ordered set where dischargeDate = &#63;.
	*
	* @param dischargeSummaryId the primary key of the current discharge summary
	* @param dischargeDate the discharge date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary[] findBydischargeDate_PrevAndNext(
		long dischargeSummaryId, java.util.Date dischargeDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Removes all the discharge summaries where dischargeDate = &#63; from the database.
	*
	* @param dischargeDate the discharge date
	* @throws SystemException if a system exception occurred
	*/
	public void removeBydischargeDate(java.util.Date dischargeDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of discharge summaries where dischargeDate = &#63;.
	*
	* @param dischargeDate the discharge date
	* @return the number of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countBydischargeDate(java.util.Date dischargeDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the discharge summaries where admissionDate = &#63;.
	*
	* @param admissionDate the admission date
	* @return the matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByadmissionDate(
		java.util.Date admissionDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the discharge summaries where admissionDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param admissionDate the admission date
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @return the range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByadmissionDate(
		java.util.Date admissionDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the discharge summaries where admissionDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param admissionDate the admission date
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findByadmissionDate(
		java.util.Date admissionDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first discharge summary in the ordered set where admissionDate = &#63;.
	*
	* @param admissionDate the admission date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByadmissionDate_First(
		java.util.Date admissionDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the first discharge summary in the ordered set where admissionDate = &#63;.
	*
	* @param admissionDate the admission date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByadmissionDate_First(
		java.util.Date admissionDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last discharge summary in the ordered set where admissionDate = &#63;.
	*
	* @param admissionDate the admission date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByadmissionDate_Last(
		java.util.Date admissionDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the last discharge summary in the ordered set where admissionDate = &#63;.
	*
	* @param admissionDate the admission date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discharge summary, or <code>null</code> if a matching discharge summary could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByadmissionDate_Last(
		java.util.Date admissionDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summaries before and after the current discharge summary in the ordered set where admissionDate = &#63;.
	*
	* @param dischargeSummaryId the primary key of the current discharge summary
	* @param admissionDate the admission date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary[] findByadmissionDate_PrevAndNext(
		long dischargeSummaryId, java.util.Date admissionDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Removes all the discharge summaries where admissionDate = &#63; from the database.
	*
	* @param admissionDate the admission date
	* @throws SystemException if a system exception occurred
	*/
	public void removeByadmissionDate(java.util.Date admissionDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of discharge summaries where admissionDate = &#63;.
	*
	* @param admissionDate the admission date
	* @return the number of matching discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countByadmissionDate(java.util.Date admissionDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the discharge summary in the entity cache if it is enabled.
	*
	* @param dischargeSummary the discharge summary
	*/
	public void cacheResult(
		com.napier.portal.db.model.DischargeSummary dischargeSummary);

	/**
	* Caches the discharge summaries in the entity cache if it is enabled.
	*
	* @param dischargeSummaries the discharge summaries
	*/
	public void cacheResult(
		java.util.List<com.napier.portal.db.model.DischargeSummary> dischargeSummaries);

	/**
	* Creates a new discharge summary with the primary key. Does not add the discharge summary to the database.
	*
	* @param dischargeSummaryId the primary key for the new discharge summary
	* @return the new discharge summary
	*/
	public com.napier.portal.db.model.DischargeSummary create(
		long dischargeSummaryId);

	/**
	* Removes the discharge summary with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param dischargeSummaryId the primary key of the discharge summary
	* @return the discharge summary that was removed
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary remove(
		long dischargeSummaryId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	public com.napier.portal.db.model.DischargeSummary updateImpl(
		com.napier.portal.db.model.DischargeSummary dischargeSummary)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the discharge summary with the primary key or throws a {@link com.napier.portal.db.NoSuchDischargeSummaryException} if it could not be found.
	*
	* @param dischargeSummaryId the primary key of the discharge summary
	* @return the discharge summary
	* @throws com.napier.portal.db.NoSuchDischargeSummaryException if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary findByPrimaryKey(
		long dischargeSummaryId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.napier.portal.db.NoSuchDischargeSummaryException;

	/**
	* Returns the discharge summary with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param dischargeSummaryId the primary key of the discharge summary
	* @return the discharge summary, or <code>null</code> if a discharge summary with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.napier.portal.db.model.DischargeSummary fetchByPrimaryKey(
		long dischargeSummaryId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the discharge summaries.
	*
	* @return the discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the discharge summaries.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @return the range of discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the discharge summaries.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.napier.portal.db.model.impl.DischargeSummaryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of discharge summaries
	* @param end the upper bound of the range of discharge summaries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.napier.portal.db.model.DischargeSummary> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the discharge summaries from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of discharge summaries.
	*
	* @return the number of discharge summaries
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}