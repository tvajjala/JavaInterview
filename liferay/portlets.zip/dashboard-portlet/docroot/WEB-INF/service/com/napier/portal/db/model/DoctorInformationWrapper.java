/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link DoctorInformation}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DoctorInformation
 * @generated
 */
public class DoctorInformationWrapper implements DoctorInformation,
	ModelWrapper<DoctorInformation> {
	public DoctorInformationWrapper(DoctorInformation doctorInformation) {
		_doctorInformation = doctorInformation;
	}

	@Override
	public Class<?> getModelClass() {
		return DoctorInformation.class;
	}

	@Override
	public String getModelClassName() {
		return DoctorInformation.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("doctorInfoId", getDoctorInfoId());
		attributes.put("specialization", getSpecialization());
		attributes.put("doctorName", getDoctorName());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long doctorInfoId = (Long)attributes.get("doctorInfoId");

		if (doctorInfoId != null) {
			setDoctorInfoId(doctorInfoId);
		}

		String specialization = (String)attributes.get("specialization");

		if (specialization != null) {
			setSpecialization(specialization);
		}

		String doctorName = (String)attributes.get("doctorName");

		if (doctorName != null) {
			setDoctorName(doctorName);
		}
	}

	/**
	* Returns the primary key of this doctor information.
	*
	* @return the primary key of this doctor information
	*/
	@Override
	public long getPrimaryKey() {
		return _doctorInformation.getPrimaryKey();
	}

	/**
	* Sets the primary key of this doctor information.
	*
	* @param primaryKey the primary key of this doctor information
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_doctorInformation.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the doctor info ID of this doctor information.
	*
	* @return the doctor info ID of this doctor information
	*/
	@Override
	public long getDoctorInfoId() {
		return _doctorInformation.getDoctorInfoId();
	}

	/**
	* Sets the doctor info ID of this doctor information.
	*
	* @param doctorInfoId the doctor info ID of this doctor information
	*/
	@Override
	public void setDoctorInfoId(long doctorInfoId) {
		_doctorInformation.setDoctorInfoId(doctorInfoId);
	}

	/**
	* Returns the specialization of this doctor information.
	*
	* @return the specialization of this doctor information
	*/
	@Override
	public java.lang.String getSpecialization() {
		return _doctorInformation.getSpecialization();
	}

	/**
	* Sets the specialization of this doctor information.
	*
	* @param specialization the specialization of this doctor information
	*/
	@Override
	public void setSpecialization(java.lang.String specialization) {
		_doctorInformation.setSpecialization(specialization);
	}

	/**
	* Returns the doctor name of this doctor information.
	*
	* @return the doctor name of this doctor information
	*/
	@Override
	public java.lang.String getDoctorName() {
		return _doctorInformation.getDoctorName();
	}

	/**
	* Sets the doctor name of this doctor information.
	*
	* @param doctorName the doctor name of this doctor information
	*/
	@Override
	public void setDoctorName(java.lang.String doctorName) {
		_doctorInformation.setDoctorName(doctorName);
	}

	@Override
	public boolean isNew() {
		return _doctorInformation.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_doctorInformation.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _doctorInformation.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_doctorInformation.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _doctorInformation.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _doctorInformation.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_doctorInformation.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _doctorInformation.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_doctorInformation.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_doctorInformation.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_doctorInformation.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DoctorInformationWrapper((DoctorInformation)_doctorInformation.clone());
	}

	@Override
	public int compareTo(
		com.napier.portal.db.model.DoctorInformation doctorInformation) {
		return _doctorInformation.compareTo(doctorInformation);
	}

	@Override
	public int hashCode() {
		return _doctorInformation.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.DoctorInformation> toCacheModel() {
		return _doctorInformation.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.DoctorInformation toEscapedModel() {
		return new DoctorInformationWrapper(_doctorInformation.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.DoctorInformation toUnescapedModel() {
		return new DoctorInformationWrapper(_doctorInformation.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _doctorInformation.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _doctorInformation.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_doctorInformation.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DoctorInformationWrapper)) {
			return false;
		}

		DoctorInformationWrapper doctorInformationWrapper = (DoctorInformationWrapper)obj;

		if (Validator.equals(_doctorInformation,
					doctorInformationWrapper._doctorInformation)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public DoctorInformation getWrappedDoctorInformation() {
		return _doctorInformation;
	}

	@Override
	public DoctorInformation getWrappedModel() {
		return _doctorInformation;
	}

	@Override
	public void resetOriginalValues() {
		_doctorInformation.resetOriginalValues();
	}

	private DoctorInformation _doctorInformation;
}