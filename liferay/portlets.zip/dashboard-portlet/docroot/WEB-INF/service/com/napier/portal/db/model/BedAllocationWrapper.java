/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link BedAllocation}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see BedAllocation
 * @generated
 */
public class BedAllocationWrapper implements BedAllocation,
	ModelWrapper<BedAllocation> {
	public BedAllocationWrapper(BedAllocation bedAllocation) {
		_bedAllocation = bedAllocation;
	}

	@Override
	public Class<?> getModelClass() {
		return BedAllocation.class;
	}

	@Override
	public String getModelClassName() {
		return BedAllocation.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("bedAllocationId", getBedAllocationId());
		attributes.put("bedReservationNumber", getBedReservationNumber());
		attributes.put("bedReservationDate", getBedReservationDate());
		attributes.put("mrNumber", getMrNumber());
		attributes.put("ipNumber", getIpNumber());
		attributes.put("bedNumber", getBedNumber());
		attributes.put("joiningDate", getJoiningDate());
		attributes.put("admissionDate", getAdmissionDate());
		attributes.put("patientName", getPatientName());
		attributes.put("age", getAge());
		attributes.put("gender", getGender());
		attributes.put("mobile", getMobile());
		attributes.put("email", getEmail());
		attributes.put("status", getStatus());
		attributes.put("createdUserId", getCreatedUserId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long bedAllocationId = (Long)attributes.get("bedAllocationId");

		if (bedAllocationId != null) {
			setBedAllocationId(bedAllocationId);
		}

		String bedReservationNumber = (String)attributes.get(
				"bedReservationNumber");

		if (bedReservationNumber != null) {
			setBedReservationNumber(bedReservationNumber);
		}

		Date bedReservationDate = (Date)attributes.get("bedReservationDate");

		if (bedReservationDate != null) {
			setBedReservationDate(bedReservationDate);
		}

		String mrNumber = (String)attributes.get("mrNumber");

		if (mrNumber != null) {
			setMrNumber(mrNumber);
		}

		String ipNumber = (String)attributes.get("ipNumber");

		if (ipNumber != null) {
			setIpNumber(ipNumber);
		}

		String bedNumber = (String)attributes.get("bedNumber");

		if (bedNumber != null) {
			setBedNumber(bedNumber);
		}

		Date joiningDate = (Date)attributes.get("joiningDate");

		if (joiningDate != null) {
			setJoiningDate(joiningDate);
		}

		Date admissionDate = (Date)attributes.get("admissionDate");

		if (admissionDate != null) {
			setAdmissionDate(admissionDate);
		}

		String patientName = (String)attributes.get("patientName");

		if (patientName != null) {
			setPatientName(patientName);
		}

		Integer age = (Integer)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String mobile = (String)attributes.get("mobile");

		if (mobile != null) {
			setMobile(mobile);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Long createdUserId = (Long)attributes.get("createdUserId");

		if (createdUserId != null) {
			setCreatedUserId(createdUserId);
		}
	}

	/**
	* Returns the primary key of this bed allocation.
	*
	* @return the primary key of this bed allocation
	*/
	@Override
	public long getPrimaryKey() {
		return _bedAllocation.getPrimaryKey();
	}

	/**
	* Sets the primary key of this bed allocation.
	*
	* @param primaryKey the primary key of this bed allocation
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_bedAllocation.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the bed allocation ID of this bed allocation.
	*
	* @return the bed allocation ID of this bed allocation
	*/
	@Override
	public long getBedAllocationId() {
		return _bedAllocation.getBedAllocationId();
	}

	/**
	* Sets the bed allocation ID of this bed allocation.
	*
	* @param bedAllocationId the bed allocation ID of this bed allocation
	*/
	@Override
	public void setBedAllocationId(long bedAllocationId) {
		_bedAllocation.setBedAllocationId(bedAllocationId);
	}

	/**
	* Returns the bed reservation number of this bed allocation.
	*
	* @return the bed reservation number of this bed allocation
	*/
	@Override
	public java.lang.String getBedReservationNumber() {
		return _bedAllocation.getBedReservationNumber();
	}

	/**
	* Sets the bed reservation number of this bed allocation.
	*
	* @param bedReservationNumber the bed reservation number of this bed allocation
	*/
	@Override
	public void setBedReservationNumber(java.lang.String bedReservationNumber) {
		_bedAllocation.setBedReservationNumber(bedReservationNumber);
	}

	/**
	* Returns the bed reservation date of this bed allocation.
	*
	* @return the bed reservation date of this bed allocation
	*/
	@Override
	public java.util.Date getBedReservationDate() {
		return _bedAllocation.getBedReservationDate();
	}

	/**
	* Sets the bed reservation date of this bed allocation.
	*
	* @param bedReservationDate the bed reservation date of this bed allocation
	*/
	@Override
	public void setBedReservationDate(java.util.Date bedReservationDate) {
		_bedAllocation.setBedReservationDate(bedReservationDate);
	}

	/**
	* Returns the mr number of this bed allocation.
	*
	* @return the mr number of this bed allocation
	*/
	@Override
	public java.lang.String getMrNumber() {
		return _bedAllocation.getMrNumber();
	}

	/**
	* Sets the mr number of this bed allocation.
	*
	* @param mrNumber the mr number of this bed allocation
	*/
	@Override
	public void setMrNumber(java.lang.String mrNumber) {
		_bedAllocation.setMrNumber(mrNumber);
	}

	/**
	* Returns the ip number of this bed allocation.
	*
	* @return the ip number of this bed allocation
	*/
	@Override
	public java.lang.String getIpNumber() {
		return _bedAllocation.getIpNumber();
	}

	/**
	* Sets the ip number of this bed allocation.
	*
	* @param ipNumber the ip number of this bed allocation
	*/
	@Override
	public void setIpNumber(java.lang.String ipNumber) {
		_bedAllocation.setIpNumber(ipNumber);
	}

	/**
	* Returns the bed number of this bed allocation.
	*
	* @return the bed number of this bed allocation
	*/
	@Override
	public java.lang.String getBedNumber() {
		return _bedAllocation.getBedNumber();
	}

	/**
	* Sets the bed number of this bed allocation.
	*
	* @param bedNumber the bed number of this bed allocation
	*/
	@Override
	public void setBedNumber(java.lang.String bedNumber) {
		_bedAllocation.setBedNumber(bedNumber);
	}

	/**
	* Returns the joining date of this bed allocation.
	*
	* @return the joining date of this bed allocation
	*/
	@Override
	public java.util.Date getJoiningDate() {
		return _bedAllocation.getJoiningDate();
	}

	/**
	* Sets the joining date of this bed allocation.
	*
	* @param joiningDate the joining date of this bed allocation
	*/
	@Override
	public void setJoiningDate(java.util.Date joiningDate) {
		_bedAllocation.setJoiningDate(joiningDate);
	}

	/**
	* Returns the admission date of this bed allocation.
	*
	* @return the admission date of this bed allocation
	*/
	@Override
	public java.util.Date getAdmissionDate() {
		return _bedAllocation.getAdmissionDate();
	}

	/**
	* Sets the admission date of this bed allocation.
	*
	* @param admissionDate the admission date of this bed allocation
	*/
	@Override
	public void setAdmissionDate(java.util.Date admissionDate) {
		_bedAllocation.setAdmissionDate(admissionDate);
	}

	/**
	* Returns the patient name of this bed allocation.
	*
	* @return the patient name of this bed allocation
	*/
	@Override
	public java.lang.String getPatientName() {
		return _bedAllocation.getPatientName();
	}

	/**
	* Sets the patient name of this bed allocation.
	*
	* @param patientName the patient name of this bed allocation
	*/
	@Override
	public void setPatientName(java.lang.String patientName) {
		_bedAllocation.setPatientName(patientName);
	}

	/**
	* Returns the age of this bed allocation.
	*
	* @return the age of this bed allocation
	*/
	@Override
	public int getAge() {
		return _bedAllocation.getAge();
	}

	/**
	* Sets the age of this bed allocation.
	*
	* @param age the age of this bed allocation
	*/
	@Override
	public void setAge(int age) {
		_bedAllocation.setAge(age);
	}

	/**
	* Returns the gender of this bed allocation.
	*
	* @return the gender of this bed allocation
	*/
	@Override
	public java.lang.String getGender() {
		return _bedAllocation.getGender();
	}

	/**
	* Sets the gender of this bed allocation.
	*
	* @param gender the gender of this bed allocation
	*/
	@Override
	public void setGender(java.lang.String gender) {
		_bedAllocation.setGender(gender);
	}

	/**
	* Returns the mobile of this bed allocation.
	*
	* @return the mobile of this bed allocation
	*/
	@Override
	public java.lang.String getMobile() {
		return _bedAllocation.getMobile();
	}

	/**
	* Sets the mobile of this bed allocation.
	*
	* @param mobile the mobile of this bed allocation
	*/
	@Override
	public void setMobile(java.lang.String mobile) {
		_bedAllocation.setMobile(mobile);
	}

	/**
	* Returns the email of this bed allocation.
	*
	* @return the email of this bed allocation
	*/
	@Override
	public java.lang.String getEmail() {
		return _bedAllocation.getEmail();
	}

	/**
	* Sets the email of this bed allocation.
	*
	* @param email the email of this bed allocation
	*/
	@Override
	public void setEmail(java.lang.String email) {
		_bedAllocation.setEmail(email);
	}

	/**
	* Returns the status of this bed allocation.
	*
	* @return the status of this bed allocation
	*/
	@Override
	public java.lang.String getStatus() {
		return _bedAllocation.getStatus();
	}

	/**
	* Sets the status of this bed allocation.
	*
	* @param status the status of this bed allocation
	*/
	@Override
	public void setStatus(java.lang.String status) {
		_bedAllocation.setStatus(status);
	}

	/**
	* Returns the created user ID of this bed allocation.
	*
	* @return the created user ID of this bed allocation
	*/
	@Override
	public long getCreatedUserId() {
		return _bedAllocation.getCreatedUserId();
	}

	/**
	* Sets the created user ID of this bed allocation.
	*
	* @param createdUserId the created user ID of this bed allocation
	*/
	@Override
	public void setCreatedUserId(long createdUserId) {
		_bedAllocation.setCreatedUserId(createdUserId);
	}

	/**
	* Returns the created user uuid of this bed allocation.
	*
	* @return the created user uuid of this bed allocation
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getCreatedUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bedAllocation.getCreatedUserUuid();
	}

	/**
	* Sets the created user uuid of this bed allocation.
	*
	* @param createdUserUuid the created user uuid of this bed allocation
	*/
	@Override
	public void setCreatedUserUuid(java.lang.String createdUserUuid) {
		_bedAllocation.setCreatedUserUuid(createdUserUuid);
	}

	@Override
	public boolean isNew() {
		return _bedAllocation.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_bedAllocation.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _bedAllocation.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_bedAllocation.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _bedAllocation.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _bedAllocation.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_bedAllocation.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _bedAllocation.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_bedAllocation.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_bedAllocation.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_bedAllocation.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new BedAllocationWrapper((BedAllocation)_bedAllocation.clone());
	}

	@Override
	public int compareTo(com.napier.portal.db.model.BedAllocation bedAllocation) {
		return _bedAllocation.compareTo(bedAllocation);
	}

	@Override
	public int hashCode() {
		return _bedAllocation.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.napier.portal.db.model.BedAllocation> toCacheModel() {
		return _bedAllocation.toCacheModel();
	}

	@Override
	public com.napier.portal.db.model.BedAllocation toEscapedModel() {
		return new BedAllocationWrapper(_bedAllocation.toEscapedModel());
	}

	@Override
	public com.napier.portal.db.model.BedAllocation toUnescapedModel() {
		return new BedAllocationWrapper(_bedAllocation.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _bedAllocation.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _bedAllocation.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_bedAllocation.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BedAllocationWrapper)) {
			return false;
		}

		BedAllocationWrapper bedAllocationWrapper = (BedAllocationWrapper)obj;

		if (Validator.equals(_bedAllocation, bedAllocationWrapper._bedAllocation)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public BedAllocation getWrappedBedAllocation() {
		return _bedAllocation;
	}

	@Override
	public BedAllocation getWrappedModel() {
		return _bedAllocation;
	}

	@Override
	public void resetOriginalValues() {
		_bedAllocation.resetOriginalValues();
	}

	private BedAllocation _bedAllocation;
}