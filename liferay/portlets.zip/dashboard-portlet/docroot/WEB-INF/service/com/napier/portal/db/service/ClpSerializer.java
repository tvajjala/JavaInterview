/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.napier.portal.db.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayInputStream;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayOutputStream;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ClassLoaderObjectInputStream;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.BaseModel;

import com.napier.portal.db.model.BedAllocationClp;
import com.napier.portal.db.model.BedReservationClp;
import com.napier.portal.db.model.DepositClp;
import com.napier.portal.db.model.DiagnosticReportClp;
import com.napier.portal.db.model.DischargeSummaryClp;
import com.napier.portal.db.model.DoctorAppointmentClp;
import com.napier.portal.db.model.DoctorInformationClp;
import com.napier.portal.db.model.LabReportClp;
import com.napier.portal.db.model.NapierUserClp;
import com.napier.portal.db.model.PatientBillClp;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Brian Wing Shun Chan
 */
public class ClpSerializer {
	public static String getServletContextName() {
		if (Validator.isNotNull(_servletContextName)) {
			return _servletContextName;
		}

		synchronized (ClpSerializer.class) {
			if (Validator.isNotNull(_servletContextName)) {
				return _servletContextName;
			}

			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Class<?> portletPropsClass = classLoader.loadClass(
						"com.liferay.util.portlet.PortletProps");

				Method getMethod = portletPropsClass.getMethod("get",
						new Class<?>[] { String.class });

				String portletPropsServletContextName = (String)getMethod.invoke(null,
						"dashboard-portlet-deployment-context");

				if (Validator.isNotNull(portletPropsServletContextName)) {
					_servletContextName = portletPropsServletContextName;
				}
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info(
						"Unable to locate deployment context from portlet properties");
				}
			}

			if (Validator.isNull(_servletContextName)) {
				try {
					String propsUtilServletContextName = PropsUtil.get(
							"dashboard-portlet-deployment-context");

					if (Validator.isNotNull(propsUtilServletContextName)) {
						_servletContextName = propsUtilServletContextName;
					}
				}
				catch (Throwable t) {
					if (_log.isInfoEnabled()) {
						_log.info(
							"Unable to locate deployment context from portal properties");
					}
				}
			}

			if (Validator.isNull(_servletContextName)) {
				_servletContextName = "dashboard-portlet";
			}

			return _servletContextName;
		}
	}

	public static Object translateInput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(BedAllocationClp.class.getName())) {
			return translateInputBedAllocation(oldModel);
		}

		if (oldModelClassName.equals(BedReservationClp.class.getName())) {
			return translateInputBedReservation(oldModel);
		}

		if (oldModelClassName.equals(DepositClp.class.getName())) {
			return translateInputDeposit(oldModel);
		}

		if (oldModelClassName.equals(DiagnosticReportClp.class.getName())) {
			return translateInputDiagnosticReport(oldModel);
		}

		if (oldModelClassName.equals(DischargeSummaryClp.class.getName())) {
			return translateInputDischargeSummary(oldModel);
		}

		if (oldModelClassName.equals(DoctorAppointmentClp.class.getName())) {
			return translateInputDoctorAppointment(oldModel);
		}

		if (oldModelClassName.equals(DoctorInformationClp.class.getName())) {
			return translateInputDoctorInformation(oldModel);
		}

		if (oldModelClassName.equals(LabReportClp.class.getName())) {
			return translateInputLabReport(oldModel);
		}

		if (oldModelClassName.equals(NapierUserClp.class.getName())) {
			return translateInputNapierUser(oldModel);
		}

		if (oldModelClassName.equals(PatientBillClp.class.getName())) {
			return translateInputPatientBill(oldModel);
		}

		return oldModel;
	}

	public static Object translateInput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateInput(curObj));
		}

		return newList;
	}

	public static Object translateInputBedAllocation(BaseModel<?> oldModel) {
		BedAllocationClp oldClpModel = (BedAllocationClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getBedAllocationRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputBedReservation(BaseModel<?> oldModel) {
		BedReservationClp oldClpModel = (BedReservationClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getBedReservationRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputDeposit(BaseModel<?> oldModel) {
		DepositClp oldClpModel = (DepositClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getDepositRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputDiagnosticReport(BaseModel<?> oldModel) {
		DiagnosticReportClp oldClpModel = (DiagnosticReportClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getDiagnosticReportRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputDischargeSummary(BaseModel<?> oldModel) {
		DischargeSummaryClp oldClpModel = (DischargeSummaryClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getDischargeSummaryRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputDoctorAppointment(BaseModel<?> oldModel) {
		DoctorAppointmentClp oldClpModel = (DoctorAppointmentClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getDoctorAppointmentRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputDoctorInformation(BaseModel<?> oldModel) {
		DoctorInformationClp oldClpModel = (DoctorInformationClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getDoctorInformationRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputLabReport(BaseModel<?> oldModel) {
		LabReportClp oldClpModel = (LabReportClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getLabReportRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputNapierUser(BaseModel<?> oldModel) {
		NapierUserClp oldClpModel = (NapierUserClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getNapierUserRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputPatientBill(BaseModel<?> oldModel) {
		PatientBillClp oldClpModel = (PatientBillClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getPatientBillRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateInput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateInput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Object translateOutput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.BedAllocationImpl")) {
			return translateOutputBedAllocation(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.BedReservationImpl")) {
			return translateOutputBedReservation(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.DepositImpl")) {
			return translateOutputDeposit(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.DiagnosticReportImpl")) {
			return translateOutputDiagnosticReport(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.DischargeSummaryImpl")) {
			return translateOutputDischargeSummary(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.DoctorAppointmentImpl")) {
			return translateOutputDoctorAppointment(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.DoctorInformationImpl")) {
			return translateOutputDoctorInformation(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.LabReportImpl")) {
			return translateOutputLabReport(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.NapierUserImpl")) {
			return translateOutputNapierUser(oldModel);
		}

		if (oldModelClassName.equals(
					"com.napier.portal.db.model.impl.PatientBillImpl")) {
			return translateOutputPatientBill(oldModel);
		}

		return oldModel;
	}

	public static Object translateOutput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateOutput(curObj));
		}

		return newList;
	}

	public static Object translateOutput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateOutput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateOutput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Throwable translateThrowable(Throwable throwable) {
		if (_useReflectionToTranslateThrowable) {
			try {
				UnsyncByteArrayOutputStream unsyncByteArrayOutputStream = new UnsyncByteArrayOutputStream();
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(unsyncByteArrayOutputStream);

				objectOutputStream.writeObject(throwable);

				objectOutputStream.flush();
				objectOutputStream.close();

				UnsyncByteArrayInputStream unsyncByteArrayInputStream = new UnsyncByteArrayInputStream(unsyncByteArrayOutputStream.unsafeGetByteArray(),
						0, unsyncByteArrayOutputStream.size());

				Thread currentThread = Thread.currentThread();

				ClassLoader contextClassLoader = currentThread.getContextClassLoader();

				ObjectInputStream objectInputStream = new ClassLoaderObjectInputStream(unsyncByteArrayInputStream,
						contextClassLoader);

				throwable = (Throwable)objectInputStream.readObject();

				objectInputStream.close();

				return throwable;
			}
			catch (SecurityException se) {
				if (_log.isInfoEnabled()) {
					_log.info("Do not use reflection to translate throwable");
				}

				_useReflectionToTranslateThrowable = false;
			}
			catch (Throwable throwable2) {
				_log.error(throwable2, throwable2);

				return throwable2;
			}
		}

		Class<?> clazz = throwable.getClass();

		String className = clazz.getName();

		if (className.equals(PortalException.class.getName())) {
			return new PortalException();
		}

		if (className.equals(SystemException.class.getName())) {
			return new SystemException();
		}

		if (className.equals(
					"com.napier.portal.db.NoSuchBedAllocationException")) {
			return new com.napier.portal.db.NoSuchBedAllocationException();
		}

		if (className.equals(
					"com.napier.portal.db.NoSuchBedReservationException")) {
			return new com.napier.portal.db.NoSuchBedReservationException();
		}

		if (className.equals("com.napier.portal.db.NoSuchDepositException")) {
			return new com.napier.portal.db.NoSuchDepositException();
		}

		if (className.equals(
					"com.napier.portal.db.NoSuchDiagnosticReportException")) {
			return new com.napier.portal.db.NoSuchDiagnosticReportException();
		}

		if (className.equals(
					"com.napier.portal.db.NoSuchDischargeSummaryException")) {
			return new com.napier.portal.db.NoSuchDischargeSummaryException();
		}

		if (className.equals(
					"com.napier.portal.db.NoSuchDoctorAppointmentException")) {
			return new com.napier.portal.db.NoSuchDoctorAppointmentException();
		}

		if (className.equals(
					"com.napier.portal.db.NoSuchDoctorInformationException")) {
			return new com.napier.portal.db.NoSuchDoctorInformationException();
		}

		if (className.equals("com.napier.portal.db.NoSuchLabReportException")) {
			return new com.napier.portal.db.NoSuchLabReportException();
		}

		if (className.equals("com.napier.portal.db.NoSuchNapierUserException")) {
			return new com.napier.portal.db.NoSuchNapierUserException();
		}

		if (className.equals("com.napier.portal.db.NoSuchPatientBillException")) {
			return new com.napier.portal.db.NoSuchPatientBillException();
		}

		return throwable;
	}

	public static Object translateOutputBedAllocation(BaseModel<?> oldModel) {
		BedAllocationClp newModel = new BedAllocationClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setBedAllocationRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputBedReservation(BaseModel<?> oldModel) {
		BedReservationClp newModel = new BedReservationClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setBedReservationRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputDeposit(BaseModel<?> oldModel) {
		DepositClp newModel = new DepositClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setDepositRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputDiagnosticReport(BaseModel<?> oldModel) {
		DiagnosticReportClp newModel = new DiagnosticReportClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setDiagnosticReportRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputDischargeSummary(BaseModel<?> oldModel) {
		DischargeSummaryClp newModel = new DischargeSummaryClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setDischargeSummaryRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputDoctorAppointment(BaseModel<?> oldModel) {
		DoctorAppointmentClp newModel = new DoctorAppointmentClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setDoctorAppointmentRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputDoctorInformation(BaseModel<?> oldModel) {
		DoctorInformationClp newModel = new DoctorInformationClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setDoctorInformationRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputLabReport(BaseModel<?> oldModel) {
		LabReportClp newModel = new LabReportClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setLabReportRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputNapierUser(BaseModel<?> oldModel) {
		NapierUserClp newModel = new NapierUserClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setNapierUserRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputPatientBill(BaseModel<?> oldModel) {
		PatientBillClp newModel = new PatientBillClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setPatientBillRemoteModel(oldModel);

		return newModel;
	}

	private static Log _log = LogFactoryUtil.getLog(ClpSerializer.class);
	private static String _servletContextName;
	private static boolean _useReflectionToTranslateThrowable = true;
}