
// callback handler for form submit
$("#updateProfileBtn").click(function(e) {
	
	
	var postData = $("#updateProfileForm").serializeArray();
	var formURL = $("#updateProfileForm").attr("action");
	
	$.ajax({
		url : formURL,
		type : "GET",
		contentType : 'application/json; charset=utf-8',
		data : postData,
		success : function(data) {
			$("#statusMSG").html(data.message);
			if(data.status=='success'){
				$("#statusMSG").css("color","green");
			}else{
				$("#statusMSG").css("color","red");
			}
			
		},
		error : function(jqXHR, textStatus, errorThrown) {
			$("#statusMSG").html("internal server error. please try again after some time");
			$("#statusMSG").css("color","red");
		}
	});
	e.preventDefault(); // STOP default action
	e.unbind(); // unbind. to stop multiple form submit.
});





// callback handler for form submit
$("#changePasswordBtn").click(function(e) {
	
	
	var postData = $("#updatePasswordForm").serializeArray();
	var formURL = $("#updatePasswordForm").attr("action");
	
	$.ajax({
		url : formURL,
		type : "GET",
		contentType : 'application/json; charset=utf-8',
		data : postData,
		success : function(data) {
			$("#statusMSG").html(data.message);
			if(data.status=='success'){
				$("#statusMSG").css("color","green");
			}else{
				$("#statusMSG").css("color","red");
			}
		},
		error : function(jqXHR, textStatus, errorThrown) {
			$("#statusMSG").html("internal server error. please try again after some time");
			$("#statusMSG").css("color","red");
		}
	});
	e.preventDefault(); // STOP default action
	e.unbind(); // unbind. to stop multiple form submit.
});