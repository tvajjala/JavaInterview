package org.jaslok.patient.bill.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PatientBillVO {

	private String billNumber;
	private String company;

	private String ipNumber;
	private String mrNumber;

	private double billAmount;
	private double paidAmount;

	private long patientBillId;

	private Date admissionDate;

	private boolean billGenerated;

	public boolean isBillGenerated() {
		return billGenerated;
	}

	public void setBillGenerated(boolean billGenerated) {
		this.billGenerated = billGenerated;
	}

	public boolean getBillGenerated() {
		return billGenerated;
	}

	private String sponser;

	List<DepositVO> deposits = new ArrayList<DepositVO>();

	public void setAdmissionDate(Date admissionDate) {
		this.admissionDate = admissionDate;
	}

	public Date getAdmissionDate() {
		return admissionDate;
	}

	public List<DepositVO> getDeposits() {
		return deposits;
	}

	public void setDeposits(List<DepositVO> deposits) {
		this.deposits = deposits;
	}

	public String getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getIpNumber() {
		return ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		this.ipNumber = ipNumber;
	}

	public String getMrNumber() {
		return mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		this.mrNumber = mrNumber;
	}

	public double getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}

	public double getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(double paidAmount) {
		this.paidAmount = paidAmount;
	}

	public long getPatientBillId() {
		return patientBillId;
	}

	public void setPatientBillId(long patientBillId) {
		this.patientBillId = patientBillId;
	}

	public String getSponser() {
		return sponser;
	}

	public void setSponser(String sponser) {
		this.sponser = sponser;
	}

}
