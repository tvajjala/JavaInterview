package org.jaslok.patient.bill.vo;

public class DepositVO {

	private double depositAmount;
	private String depositAgainst;
	private String depositNumber;
	private String mrNumber;

	private String ipNumber;

	public void setIpNumber(String ipNumber) {
		this.ipNumber = ipNumber;
	}

	public String getIpNumber() {
		return ipNumber;
	}

	public double getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}

	public String getDepositAgainst() {
		return depositAgainst;
	}

	public void setDepositAgainst(String depositAgainst) {
		this.depositAgainst = depositAgainst;
	}

	public String getDepositNumber() {
		return depositNumber;
	}

	public void setDepositNumber(String depositNumber) {
		this.depositNumber = depositNumber;
	}

	public String getMrNumber() {
		return mrNumber;
	}

	public void setMrNumber(String mrNumber) {
		this.mrNumber = mrNumber;
	}

}
