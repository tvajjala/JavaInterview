package org.jaslok.patient.bill.controller;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.log4j.Logger;
import org.jaslok.patient.bill.service.PatientBillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.napier.portal.db.NoSuchNapierUserException;
import com.napier.portal.db.model.NapierUser;
import com.napier.portal.db.service.NapierUserLocalServiceUtil;

@Controller
public class PatientBillController {

    private static Logger logger = Logger.getLogger(PatientBillController.class.getSimpleName());

    @Autowired
    PatientBillService patientBillService;

    @RenderMapping
    public String defaultView(RenderRequest renderRequest, RenderResponse renderResponse, Model model) {

        logger.info(" rendering defaultView of PatientBill ");

        String mrNumber = "MR0002992392";

        try {

            // use this logic in all the reports to retrieve mrNumber
            // dynamically
            try {
                User user = (User) renderRequest.getAttribute(WebKeys.USER);
                NapierUser napierUser = NapierUserLocalServiceUtil.getByportalUserId(user.getUserId());
                mrNumber = napierUser.getMrNumber();
            } catch (NoSuchNapierUserException e) {
                logger.error(e.getMessage());
            }

            patientBillService.populateDummyData(mrNumber);
            patientBillService.prepareResults(renderRequest, renderResponse, model, mrNumber);

        } catch (SystemException e) {
            logger.error(e.getMessage());
        }

        return "patient/view";

    }

}
