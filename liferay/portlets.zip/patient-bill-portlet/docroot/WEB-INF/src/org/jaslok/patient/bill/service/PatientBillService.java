package org.jaslok.patient.bill.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.jaslok.patient.bill.vo.DepositVO;
import org.jaslok.patient.bill.vo.PatientBillVO;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.napier.portal.db.model.Deposit;
import com.napier.portal.db.model.PatientBill;
import com.napier.portal.db.service.DepositLocalServiceUtil;
import com.napier.portal.db.service.PatientBillLocalServiceUtil;

public class PatientBillService {

    public void populateDummyData(String mrNumber) throws SystemException {

        List<PatientBill> patientBills = PatientBillLocalServiceUtil.getBymrNumber(mrNumber);

        if (patientBills.isEmpty()) {

            for (int i = 0; i < 2; i++) {
                long billId = CounterLocalServiceUtil.increment(PatientBill.class.getSimpleName());

                PatientBill patientBill = PatientBillLocalServiceUtil.createPatientBill(billId);

                patientBill.setAdmissionDate(new Date());
                patientBill.setBillAmount(5330.00);
                patientBill.setBillNumber("AD0393003-200");
                patientBill.setCompany("xxx" + i);
                patientBill.setSponser("yyyy" + i + i);
                patientBill.setIpNumber("IP020020" + i);
                patientBill.setPaidAmount(0.0);
                patientBill.setIsBalanceAmount(true);
                patientBill.setIsBillgenerated(true);
                patientBill.setMrNumber(mrNumber);

                patientBill = PatientBillLocalServiceUtil.updatePatientBill(patientBill);

                for (int j = 0; j < 4; j++) {
                    long depositId = CounterLocalServiceUtil.increment(Deposit.class.getSimpleName());
                    Deposit deposit = DepositLocalServiceUtil.createDeposit(depositId);

                    deposit.setPatientBillId(patientBill.getPatientBillId());
                    deposit.setDepositAgainst("------");
                    deposit.setMrNumber(mrNumber);
                    deposit.setIpNumber("IP0200" + j + (i + 1));
                    deposit.setDepositAmount(100.00 * ((j + 1) * (i + 1)));
                    deposit.setDepositNumber("MR00" + j);
                    DepositLocalServiceUtil.updateDeposit(deposit);

                    patientBill.setPaidAmount(patientBill.getPaidAmount() + deposit.getDepositAmount());

                    patientBill = PatientBillLocalServiceUtil.updatePatientBill(patientBill);

                }

            }

        }
    }

    public List<PatientBillVO> getPatientBills(String mrNumber) throws SystemException {
        List<PatientBill> patientBills = PatientBillLocalServiceUtil.getBymrNumber(mrNumber);

        List<PatientBillVO> billList = new ArrayList<PatientBillVO>();


        if (!patientBills.isEmpty()) {// display most recent bill only

            Collections.reverse(patientBills);
            PatientBill patientBill = patientBills.get(0);
            PatientBillVO billVO = new PatientBillVO();
            billVO.setBillAmount(patientBill.getBillAmount());
            billVO.setBillNumber(patientBill.getBillNumber());
            billVO.setCompany(patientBill.getCompany());
            billVO.setIpNumber(patientBill.getIpNumber());
            billVO.setMrNumber(patientBill.getMrNumber());
            billVO.setPaidAmount(patientBill.getPaidAmount());
            billVO.setSponser(patientBill.getSponser());
            billVO.setAdmissionDate(patientBill.getAdmissionDate());

            List<Deposit> depositList = DepositLocalServiceUtil.getBypatientBillId(patientBill.getPatientBillId());

            for (Deposit deposit : depositList) {
                DepositVO depositVO = new DepositVO();
                depositVO.setDepositAmount(deposit.getDepositAmount());
                depositVO.setDepositAgainst(deposit.getDepositAgainst());
                depositVO.setDepositNumber(deposit.getDepositNumber());
                depositVO.setMrNumber(deposit.getMrNumber());
                billVO.getDeposits().add(depositVO);
            }

            billList.add(billVO);
        }

        return billList;

    }

}
