package org.jaslok.patient.bill.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.log4j.Logger;
import org.jaslok.patient.bill.vo.DepositVO;
import org.jaslok.patient.bill.vo.PatientBillVO;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.napier.portal.db.model.Deposit;
import com.napier.portal.db.model.PatientBill;
import com.napier.portal.db.service.DepositLocalServiceUtil;
import com.napier.portal.db.service.PatientBillLocalServiceUtil;

public class PatientBillService {

    private static Logger logger = Logger.getLogger(PatientBillService.class.getSimpleName());

    public void populateDummyData(String mrNumber) throws SystemException {

        List<PatientBill> patientBills = PatientBillLocalServiceUtil.getBymrNumber(mrNumber);

        if (patientBills.isEmpty()) {

            for (int i = 0; i < 2; i++) {
                long billId = CounterLocalServiceUtil.increment(PatientBill.class.getSimpleName());

                PatientBill patientBill = PatientBillLocalServiceUtil.createPatientBill(billId);

                patientBill.setAdmissionDate(new Date());
                patientBill.setBillAmount(5330.00);
                patientBill.setBillNumber("BI-2014-08-200" + i);
                patientBill.setCompany("xxx" + i);
                patientBill.setSponser("yyyy" + i + i);
                patientBill.setIpNumber("IP-2014-08-567" + i);
                patientBill.setPaidAmount(0.0);
                patientBill.setIsBalanceAmount(true);
                patientBill.setIsBillgenerated(true);
                patientBill.setMrNumber(mrNumber);

                patientBill = PatientBillLocalServiceUtil.updatePatientBill(patientBill);

                for (int j = 0; j < 4; j++) {
                    long depositId = CounterLocalServiceUtil.increment(Deposit.class.getSimpleName());
                    Deposit deposit = DepositLocalServiceUtil.createDeposit(depositId);

                    deposit.setPatientBillId(patientBill.getPatientBillId());
                    deposit.setDepositAgainst("------");
                    deposit.setMrNumber(mrNumber);
                    deposit.setIpNumber("IP-2014-08-" + i);
                    deposit.setDepositAmount(100.00 * ((j + 1) * (i + 1)));
                    deposit.setDepositNumber("DEP-CASH-20120810" + i + j);
                    deposit.setDepositAgainst("Security Deposit");

                    DepositLocalServiceUtil.updateDeposit(deposit);

                    patientBill.setPaidAmount(patientBill.getPaidAmount() + deposit.getDepositAmount());

                    patientBill = PatientBillLocalServiceUtil.updatePatientBill(patientBill);

                }

            }

        }
    }

    public List<PatientBillVO> getPatientBills(String mrNumber) throws SystemException {
        List<PatientBill> patientBills = PatientBillLocalServiceUtil.getBymrNumber(mrNumber);

        List<PatientBillVO> billList = new ArrayList<PatientBillVO>();

        if (!patientBills.isEmpty()) {// display most recent bill only

            Collections.reverse(patientBills);
            PatientBill patientBill = patientBills.get(0);
            PatientBillVO billVO = new PatientBillVO();
            billVO.setBillAmount(patientBill.getBillAmount());
            billVO.setBillNumber(patientBill.getBillNumber());
            billVO.setCompany(patientBill.getCompany());
            billVO.setIpNumber(patientBill.getIpNumber());
            billVO.setMrNumber(patientBill.getMrNumber());
            billVO.setPaidAmount(patientBill.getPaidAmount());
            billVO.setSponser(patientBill.getSponser());
            billVO.setAdmissionDate(patientBill.getAdmissionDate());

            List<Deposit> depositList = DepositLocalServiceUtil.getBypatientBillId(patientBill.getPatientBillId());

            for (Deposit deposit : depositList) {
                DepositVO depositVO = new DepositVO();
                depositVO.setDepositAmount(deposit.getDepositAmount());
                depositVO.setDepositAgainst(deposit.getDepositAgainst());
                depositVO.setDepositNumber(deposit.getDepositNumber());
                depositVO.setMrNumber(deposit.getMrNumber());

                billVO.getDeposits().add(depositVO);
            }

            billList.add(billVO);
        }

        return billList;

    }

    public void prepareResults(RenderRequest renderRequest, RenderResponse renderResponse, Model model, String mrNumber) throws SystemException {
        List<String> headerNames = new ArrayList<String>();

        headerNames.add("MR Number");
        headerNames.add("IP Number");
        headerNames.add("Bill Number");
        headerNames.add("Company/Sponsor");

        headerNames.add("Admission Date");
        headerNames.add("Bill Generated");
        headerNames.add("Bill Amount");
        headerNames.add("Paid Amount");

        PortletURL portletURL = renderResponse.createRenderURL();
        try {
            portletURL.setWindowState(WindowState.MAXIMIZED);
        } catch (WindowStateException e) {
            logger.error(e.getMessage());
        }
        SearchContainer<PatientBill> searchContainer = new SearchContainer<PatientBill>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM, 5,
                portletURL, headerNames, "Patient Bills Not Available");

        portletURL.setParameter(searchContainer.getCurParam(), String.valueOf(searchContainer.getCur()));

        // most recent patient we need to display no need of pagination
        List<PatientBill> patientBillsAll = PatientBillLocalServiceUtil.getBymrNumber(mrNumber, searchContainer.getStart(), searchContainer.getEnd());

        List<PatientBill> patientBills = new ArrayList<PatientBill>();

        if (!patientBillsAll.isEmpty()) {
            Collections.reverse(patientBillsAll);
            patientBills = Collections.singletonList(patientBillsAll.get(0));
        }

        int total = patientBills.size(); // PatientBillLocalServiceUtil.getBymrNumber(mrNumber).size();
        searchContainer.setTotal(total);
        searchContainer.setResults(patientBills);
        searchContainer.setDeltaConfigurable(true);

        List<ResultRow> resultRows = searchContainer.getResultRows();

        int i = 0;
        for (PatientBill report : patientBills) {
            ResultRow row = new ResultRow(report, report.getPatientBillId(), i++);
            row.addText(report.getMrNumber());
            row.addText(report.getIpNumber());
            row.addText(report.getBillNumber());
            row.addText(report.getCompany() + "/" + report.getSponser());

            row.addText((report.getAdmissionDate() == null) ? "" : report.getAdmissionDate().toString());
            row.addText(report.isIsBillgenerated() ? "YES" : "NO");
            row.addText(report.getBillAmount() + " INR ");
            row.addText(report.getPaidAmount() + " INR ");
            // row.addButton("Pay", "payBill('" + report.getPatientBillId() + "','" + (report.getBillAmount() - report.getPaidAmount()) + "')");
            resultRows.add(row);
        }

        logger.info("   patientBills " + patientBills.size());

        model.addAttribute("patientBillsContainer", searchContainer);
        prepateDeposits(renderRequest, renderResponse, model, patientBills);

    }

    public void prepateDeposits(RenderRequest renderRequest, RenderResponse renderResponse, Model model, List<PatientBill> patientBills) throws SystemException {

        if (!patientBills.isEmpty()) {
            model.addAttribute("enableHeader", true);
            PatientBill patientBill = patientBills.get(0);

            List<String> headerNames = new ArrayList<String>();

            headerNames.add("MR Number");
            headerNames.add("IP Number");
            headerNames.add("Deposit Number");
            headerNames.add("Deposit Amount");
            headerNames.add("Deposit Against");

            PortletURL portletURL = renderResponse.createRenderURL();
            try {
                portletURL.setWindowState(WindowState.MAXIMIZED);
            } catch (WindowStateException e) {
                logger.error(e.getMessage());
            }
            SearchContainer<Deposit> searchContainer = new SearchContainer<Deposit>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM, 5,
                    portletURL, headerNames, "you don't have any deposits for the Bill Number '" + patientBill.getBillNumber() + "'");

            portletURL.setParameter(searchContainer.getCurParam(), String.valueOf(searchContainer.getCur()));

            // most recent patient we need to display no need of pagination

            List<Deposit> depositList = DepositLocalServiceUtil.getBypatientBillId(patientBill.getPatientBillId(), searchContainer.getStart(),
                    searchContainer.getEnd());

            int total = DepositLocalServiceUtil.getBypatientBillId(patientBill.getPatientBillId()).size();
            searchContainer.setTotal(total);
            searchContainer.setResults(depositList);
            searchContainer.setDeltaConfigurable(true);

            List<ResultRow> resultRows = searchContainer.getResultRows();

            int i = 0;
            for (Deposit report : depositList) {
                ResultRow row = new ResultRow(report, report.getPatientBillId(), i++);
                row.addText(report.getMrNumber());
                row.addText(report.getIpNumber());
                row.addText(report.getDepositNumber());
                row.addText(report.getDepositAmount() + " INR");
                row.addText(report.getDepositAgainst());
                resultRows.add(row);
            }

            model.addAttribute("depositContainer", searchContainer);

        } else {
            model.addAttribute("enableHeader", false);
        }

    }

}
