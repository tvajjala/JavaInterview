package org.jaslok.doctor.schedule.controller;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

@Controller
public class DoctorScheduleController {
	private static Logger logger = Logger
			.getLogger(DoctorScheduleController.class.getSimpleName());

	@RenderMapping
	public String defaultView(RenderRequest renderRequest,
			RenderResponse renderResponse, Model model) {
		
		logger.info("	DoctorScheduleController ");
		
		
		return "patient/view";
	}

}
