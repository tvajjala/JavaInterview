package org.jaslok.doctor.schedule.service;


public class DoctorScheduleService {
	
}
