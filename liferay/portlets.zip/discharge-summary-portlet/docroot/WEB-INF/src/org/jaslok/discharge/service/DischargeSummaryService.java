package org.jaslok.discharge.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.log4j.Logger;
import org.springframework.ui.Model;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.napier.portal.db.model.DischargeSummary;
import com.napier.portal.db.service.DischargeSummaryLocalServiceUtil;

/**
 * 
 * @author tvajjala
 * 
 */
public class DischargeSummaryService {

    private static Logger logger = Logger.getLogger(DischargeSummaryService.class.getSimpleName());

    public List<DischargeSummary> getDischargeSummaryReports(String mrNumber) throws SystemException {
        return DischargeSummaryLocalServiceUtil.getBymrNumber(mrNumber);
    }

    public void populateDummyData(String mrNumber) throws SystemException {

        logger.debug(" populating dummy data into database for testing ");
        List<DischargeSummary> dischargeSummaries = DischargeSummaryLocalServiceUtil.getBymrNumber(mrNumber);

        if (dischargeSummaries.isEmpty()) {

            for (int i = 0; i < 100; i++) {
                long dischargeSummaryId = CounterLocalServiceUtil.increment(DischargeSummary.class.getSimpleName());

                DischargeSummary dischargeSummary = DischargeSummaryLocalServiceUtil.createDischargeSummary(dischargeSummaryId);
                dischargeSummary.setIpNumber("IP00" + (i * 44));
                dischargeSummary.setBedClass("Class " + i);
                dischargeSummary.setWard("General");
                dischargeSummary.setAdmissionDate(new Date());
                dischargeSummary.setDischargeDate(new Date());

                dischargeSummary.setDischargeDate(new Date());
                dischargeSummary.setPrimaryDoctor("Dr.Ajay");
                dischargeSummary.setMrNumber(mrNumber);
                dischargeSummary.setChiefComplaint("Chest Pain");
                dischargeSummary.setDocPath("ftp://name/name2");
                dischargeSummary.setStatus(i % 3 == 0);

                DischargeSummaryLocalServiceUtil.updateDischargeSummary(dischargeSummary);
            }

        }

    }

    public void prepareResults(RenderRequest renderRequest, RenderResponse renderResponse, Model model, String mrNumber) throws SystemException {
        List<String> headerNames = new ArrayList<String>();

        headerNames.add("IP Number");
        headerNames.add("Ward / Bed");
        headerNames.add("Admission Date");
        headerNames.add("Discharge Date");
        headerNames.add("Primary Doctor");
        headerNames.add("Chief Complaint");
        headerNames.add(" ReportView ");

        PortletURL portletURL = renderResponse.createRenderURL();
        try {
            portletURL.setWindowState(WindowState.MAXIMIZED);
        } catch (WindowStateException e) {
            logger.error(e.getMessage());
        }
        SearchContainer<DischargeSummary> searchContainer = new SearchContainer<DischargeSummary>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM,
                5, portletURL, headerNames, "DischargeSummary Reports not available");

        portletURL.setParameter(searchContainer.getCurParam(), String.valueOf(searchContainer.getCur()));

        List<DischargeSummary> dischargeSummarys = DischargeSummaryLocalServiceUtil.getBymrNumber(mrNumber, searchContainer.getStart(),
                searchContainer.getEnd());

        int total = DischargeSummaryLocalServiceUtil.getBymrNumber(mrNumber).size();
        searchContainer.setTotal(total);
        searchContainer.setResults(dischargeSummarys);
        searchContainer.setDeltaConfigurable(true);

        List<ResultRow> resultRows = searchContainer.getResultRows();

        int i = 0;
        for (DischargeSummary dischargeSummary : dischargeSummarys) {
            ResultRow row = new ResultRow(dischargeSummary, dischargeSummary.getDischargeSummaryId(), i++);
            row.addText(dischargeSummary.getIpNumber());
            row.addText(dischargeSummary.getWard() + " / " + dischargeSummary.getBedClass());

            if (dischargeSummary.getAdmissionDate() != null) {
                row.addText(dischargeSummary.getAdmissionDate().toString());
            } else {
                row.addText("--");
            }

            if (dischargeSummary.getDischargeDate() != null) {
                row.addText(dischargeSummary.getDischargeDate().toString());
            } else {
                row.addText("--");
            }

            row.addText(dischargeSummary.getPrimaryDoctor());
            row.addText(dischargeSummary.getChiefComplaint());
            if (dischargeSummary.getStatus()) {
                row.addText("Viewed", dischargeSummary.getDocPath());
            } else {
                row.addText("View", dischargeSummary.getDocPath());
            }
            resultRows.add(row);
        }

        logger.info("dischargeSummary " + dischargeSummarys.size());

        model.addAttribute("searchContainer", searchContainer);
    }

}
